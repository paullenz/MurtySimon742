"""Discovery: degree-conditioned local incidence distributions.
Every variable is an average of an indicator in an actual selected system.
Only separately checked exact duals count as exclusions.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'dependencies'))
from degree_types import build_types
from common_lp import plus
from check_constraints import partition

STATUS=('typed_sel','typed_res','typed_miss')

def extend(m,s,rho,st,t=1,charge=True):
    a=len(s);b=len(rho);r=sum(rho);L,B=partition(s,rho,st)
    idx={name:j for j,name in enumerate(m.names)}
    # Save the degree/status/option marginal expressions.
    marginal={}; dm={};rm={}; ranges={}
    for k,U in enumerate(B):
        u=U[0]; f=sum(bool(mask>>u&1) for mask in st['forced'])
        ranges[k]=range(f,st['c'][u]+1)
        for q in ranges[k]:
            for g,I in enumerate(L):
                for x,kind in enumerate(STATUS):
                    e={};de={};re={}
                    for o,(dd,rr,zz) in enumerate(st['domains'][I[0]]):
                        key=(kind,k,g,o,q)
                        if key in idx:
                            j=idx[key]; e[j]=1;de[j]=dd;re[j]=rr
                    marginal[k,q,g,x]=e;dm[k,q,g,x]=de;rm[k,q,g,x]=re
    J={}
    def get(k,q,g,h,x,y,e):
        if g>h: g,h,x,y=h,g,y,x
        if g==h and x>y: x,y=y,x
        return J.get((k,q,g,h,x,y,e))
    for k,U in enumerate(B):
        u=U[0]
        for q in ranges[k]:
            counts=(q,rho[u],a-q-rho[u]);w=idx['degree_type',k,q]
            for g,I in enumerate(L):
                for h in range(g,len(L)):
                    if h==g and len(I)<2: continue
                    for x in range(3):
                        for y in range(3):
                            if g==h and x>y:continue
                            if counts[x] < 1 or counts[y] < 1 or (x==y and counts[x]<2):continue
                            if not marginal[k,q,g,x] or not marginal[k,q,h,y]:continue
                            for e in range(2):
                                if e==1 and {x,y}=={0,2}:continue # selected--missing F edges impossible
                                key=(k,q,g,h,x,y,e)
                                J[key]=m.var(('local',)+key)
            # Pair marginals and total number of each other status around a label.
            for g,I in enumerate(L):
                for h,H in enumerate(L):
                    if h==g and len(I)<2:continue
                    for x in range(3):
                        expr={}
                        for y in range(3):
                            for e in range(2):
                                j=get(k,q,g,h,x,y,e)
                                if j is not None:expr[j]=expr.get(j,0)+1
                        plus(expr,marginal[k,q,g,x],-1)
                        m.equal(expr,0)
                for x in range(3):
                    for y in range(3):
                        expr={}
                        for h,H in enumerate(L):
                            n=len(H)-(g==h)
                            if not n:continue
                            for e in range(2):
                                j=get(k,q,g,h,x,y,e)
                                if j is not None:expr[j]=expr.get(j,0)+n
                        plus(expr,marginal[k,q,g,x],-(counts[y]-(x==y)))
                        m.equal(expr,0)
                    # F degree must be the degree of the SAME chosen column option.
                    expr={}
                    for h,H in enumerate(L):
                        n=len(H)-(g==h)
                        if not n:continue
                        for y in range(3):
                            j=get(k,q,g,h,x,y,1)
                            if j is not None:expr[j]=expr.get(j,0)+n
                    plus(expr,dm[k,q,g,x],-1);m.equal(expr,0)
                # Selected-label internal F neighbours require distinct residual edges.
                expr={}
                for h,H in enumerate(L):
                    n=len(H)-(g==h)
                    if not n:continue
                    j=get(k,q,g,h,0,0,1)
                    if j is not None:expr[j]=expr.get(j,0)+n
                plus(expr,rm[k,q,g,0],-1);m.le(expr,0)
            if charge:
                # rho + 2eF(S) + eF(M) - eC(T,M) <= r, conditioned on q.
                expr={w:-(r-rho[u])}
                for g,I in enumerate(L):
                    for h in range(g,len(L)):
                        n=len(I)*len(L[h]) if g!=h else len(I)*(len(I)-1)//2
                        if not n:continue
                        for x,y,e,coef in [(0,0,1,2),(2,2,1,1),(1,2,0,-1),(2,1,0,-1)]:
                            j=get(k,q,g,h,x,y,e)
                            if j is not None:expr[j]=expr.get(j,0)+n*coef
                m.le(expr,0)
        # Each source class sees the SAME F-edge marginals.
        for g,I in enumerate(L):
            for h in range(g,len(L)):
                if g==h and len(I)<2:continue
                expr={idx['F',g,h]:-1}
                for q in ranges[k]:
                    for x in range(3):
                        for y in range(3):
                            j=get(k,q,g,h,x,y,1)
                            if j is not None:expr[j]=expr.get(j,0)+1
                m.equal(expr,0)
    m.bound_start=len(m.ub)
    for j in range(len(m.names)):m.le({j:1},1)
    return m

def build_local(s,rho,st,t=1,charge=True):
    return extend(build_types(s,rho,st,t),s,rho,st,t,charge)

if __name__=='__main__':
    import json,gzip,time
    from common_lp import certificate,verify
    from check_constraints import translate
    root=Path(__file__).resolve().parents[1]
    data=json.loads(gzip.decompress((root/'dependencies/v6_FINAL_SURVIVORS.json.gz').read_bytes()))
    start=time.time();out=[]
    for rec in data[:int(sys.argv[1]) if len(sys.argv)>1 else 5]:
        t0=time.time();m=build_local(rec['s'],rec['row'][2:],rec['state']);res=m.solve();cert=None
        if res.status==2:
            c=certificate(m)
            if c:verify(m,c);cert=translate(m,c)
        row={'position':rec['position'],'index':rec['index'],'status':int(res.status),'certificate':cert,'vars':len(m.names),'seconds':time.time()-t0}
        out.append(row);print(row['position'],row['status'],cert is not None,len(m.names),round(row['seconds'],2),flush=True)
    (root/'evidence/LOCAL_PILOT.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
    print('DONE',len(out),round(time.time()-start,2))
