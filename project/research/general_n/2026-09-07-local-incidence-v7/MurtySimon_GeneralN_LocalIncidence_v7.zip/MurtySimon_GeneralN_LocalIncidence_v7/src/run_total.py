"""Complete scan of the pinned 388-row v6 frontier; exact verification inline."""
from total_degree import build_total as build_local
from check_total import rebuild_total as rebuild_local
from common_lp import certificate,verify
from check_constraints import translate,verify_named,signature
import json,gzip,time,sys
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]

def main():
    data=json.loads(gzip.decompress((ROOT/'dependencies/v6_FINAL_SURVIVORS.json.gz').read_bytes()))
    survivors=set(json.loads((ROOT/'evidence/LEDGER_SURVIVOR_POSITIONS.json').read_text()));data=[r for r in data if r['position'] in survivors]
    stats=Counter();start=time.time();out=[]
    with (ROOT/'evidence/TOTAL_SWEEP.jsonl').open('w') as stream:
        for i,rec in enumerate(data):
            t0=time.time();m=build_local(rec['s'],rec['row'][2:],rec['state']);ans=m.solve();c=None
            item={'position':rec['position'],'index':rec['index'],'status':int(ans.status),'variables':len(m.names),'inequalities':len(m.ub),'equalities':len(m.eq)}
            if ans.status==2:
                c=certificate(m)
                if c:
                    verify(m,c); named=translate(m,c);ind=rebuild_local(rec['s'],rec['row'][2:],rec['state'])
                    assert set(m.names)==ind.variables
                    assert {signature({m.names[j]:v for j,v in e.items()},b) for e,b in m.eq}==set(ind.equalities)
                    assert {signature({m.names[j]:v for j,v in e.items()},b) for e,b in m.ub}==set(ind.inequalities)
                    verify_named(ind,named);item['certificate']=named;item['outcome']='exact_rejection'
                else:item['outcome']='uncertified_numeric_infeasible'
            elif ans.status==0:item['outcome']='fractional_survivor'
            else:item['outcome']='unresolved_solver_status'
            item['seconds']=time.time()-t0;out.append(item);stats[item['outcome']]+=1
            stream.write(json.dumps(item,separators=(',',':'))+'\n');stream.flush()
            if (i+1)%20==0:print(i+1,dict(stats),round(time.time()-start,2),flush=True)
    certs=[x for x in out if x['outcome']=='exact_rejection'];surv=[x['position'] for x in out if x['outcome']!='exact_rejection']
    (ROOT/'evidence/TOTAL_CERTIFICATES.json.gz').write_bytes(gzip.compress((json.dumps(certs,separators=(',',':'))+'\n').encode(),mtime=0))
    (ROOT/'evidence/TOTAL_SURVIVOR_POSITIONS.json').write_text(json.dumps(surv)+'\n')
    report={'rows':len(data),'counts':dict(stats),'seconds':time.time()-start,'exact_crosscheck_each_rejection':True,'scope':{'n':28,'Delta':15,'m':196}}
    (ROOT/'evidence/TOTAL_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print('DONE',report,flush=True)
if __name__=='__main__':main()
