"""A hand obstruction: h+1 possible sources cannot supply 2h+1 demand-h labels
when all other residual degrees are at most h-2. This tests the profile premises;
it does not assert the existence of a critical graph for a numerical profile.
"""
from pathlib import Path
import json,gzip,time
from itertools import combinations
ROOT=Path(__file__).resolve().parents[1]

def verify_profile(s,rho,cert):
    h=cert['h'];Z=cert['high_sources'];I=cert['labels']
    if type(h)!=int or h<2:raise ValueError('h must be an integer >= 2')
    if len(Z)!=h+1 or len(set(Z))!=len(Z) or any(type(u)!=int or not 0<=u<len(rho) for u in Z):raise ValueError('source block')
    if any(rho[u]!=h for u in Z) or any(rho[u]>h-2 for u in range(len(rho)) if u not in Z):raise ValueError('residual gap')
    if len(I)!=2*h+1 or len(set(I))!=len(I) or any(type(i)!=int or not 0<=i<len(s) or s[i]!=h for i in I):raise ValueError('demand block')
    # The proof successively forces all high sources to have sigma<=2h,
    # then at most one exceptional label, then sigma<=2h-1.
    required=h*(2*h+1)
    assert required>h*2*h
    incoming_cap=(h+1)*2*h-required
    assert incoming_cap==h
    ordinary_required=2*h*h
    assert ordinary_required>h*(2*h-1)
    final_capacity=(h+1)*(2*h-1)
    if not required>final_capacity:raise ValueError('no contradiction')
    return {'required':required,'capacity':final_capacity,'gap':required-final_capacity}

def family(h,materialize=False):
    if type(h)!=int or h<4:raise ValueError('h >= 4 required')
    a=h*h+h-6;b=a+3;n=a+b+1;t=2;r=2*h*h+h-4
    m=(a+2)**2+1
    assert n==2*h*h+2*h-8 and m==n*n//4+1 and m-b*(n-b)==t
    s=[0]+[h]*(2*h+1)+[0]*(a-2*h-2)
    rho=[h]*(h+1)+[1]*(h*h-4)
    cert={'h':h,'high_sources':list(range(h+1)),'labels':list(range(1,2*h+2))}
    answer=verify_profile(s,rho,cert)
    d=[2*h-3]+[2*h-1]*(2*h+1)+[0]*(a-2*h-2)
    R=[2*h-3]+[h-1]*(2*h+1)+[0]*(a-2*h-2)
    assert len(s)==len(d)==a and len(rho)==b and sum(R)==sum(rho)==r and sum(d)==2*(r+t)
    assert [max(0,dd-rr) for dd,rr in zip(d,R)]==s
    if materialize:
        # F is the complement on the active labels of two cycles sharing 0.
        C=set()
        for cycle in ([0,1,2],[0]+list(range(3,2*h+2))):
            for u,v in zip(cycle,cycle[1:]+cycle[:1]):C.add(tuple(sorted((u,v))))
        F={pair for pair in combinations(range(2*h+2),2) if pair not in C}
        got=[0]*a
        for u,v in F:got[u]+=1;got[v]+=1
        assert got==d
        residual=set()
        for u in range(h+1):
            for j in range(h):residual.add((u,1+(u*h+j)%(2*h+1)))
        low=h+1
        for _ in range(2*h-3):residual.add((low,0));low+=1
        used=[0]*a
        for u,i in residual:used[i]+=1
        for i in range(1,2*h+2):
            assert used[i]<=R[i]
            for _ in range(R[i]-used[i]):residual.add((low,i));low+=1
        assert low==b
        col=[0]*a;row=[0]*b
        for u,i in residual:row[u]+=1;col[i]+=1
        assert row==rho and col==R
    return {'h':h,'n':n,'Delta':b,'m':m,'a':a,'r':r,'t':t,**answer}

def main():
    start=time.time();rows=json.loads(gzip.decompress((ROOT/'dependencies/v6_FINAL_SURVIVORS.json.gz').read_bytes()));index={x['position']:x for x in rows}
    certs=json.loads((ROOT/'evidence/ONE_SPARE_CERTIFICATES.json').read_text())
    for c in certs:
        rec=index[c['position']];assert rec['index']==c['index'];verify_profile(rec['s'],rec['row'][2:],c)
    first=None
    for h in range(4,101):
        ex=family(h,materialize=True)
        if first is None:first=ex
    for h in range(4,10001):
        a=h*h+h-6;b=a+3;n=2*a+4;r=2*h*h+h-4
        assert (a+2)**2+1-b*(n-b)==2
        assert h*(2*h+1)-(h+1)*(2*h-1)==1
        assert (2*h+1)*(h-1)+(2*h-3)==r
        assert (2*h+1)*(2*h-1)+(2*h-3)==2*(r+2)
        assert (h+1)*h+(h*h-4)==r
        assert h*(h+1)<=(2*h+1)*(h-1)
    bad=[]
    if certs:
        import copy
        c=certs[0];rec=index[c['position']]
        for label,change in [('missing_source',lambda v:v['high_sources'].pop()),('missing_label',lambda v:v['labels'].pop()),('wrong_h',lambda v:v.update(h=v['h']+1))]:
            mutated=copy.deepcopy(c);change(mutated)
            try:verify_profile(rec['s'],rec['row'][2:],mutated)
            except ValueError:bad.append(label)
            else:raise ValueError('Bad premise accepted')
    report={'all_pass':True,'overlapping_frontier_hand_certificates':len(certs),'symbolic_family':'all integers h>=4; finite arithmetic regressions are not the proof','arithmetic_h_range':[4,10000],'separate_graphicality_constructed_h_range':[4,100],'first_family_example':first,'negative_controls':bad,'seconds':time.time()-start,'whole_orders_claimed':False}
    (ROOT/'evidence/ONE_SPARE_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
if __name__=='__main__':main()
