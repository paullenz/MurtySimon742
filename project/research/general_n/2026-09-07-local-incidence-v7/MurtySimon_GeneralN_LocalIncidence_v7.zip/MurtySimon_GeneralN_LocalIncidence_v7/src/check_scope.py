"""Exact numerical scope checks. Published/structural premises remain in PROOF.md."""
from pathlib import Path
from fractions import Fraction
import json

ROOT = Path(__file__).resolve().parents[1]

def main():
    old = json.loads((ROOT/'evidence/N28_SCOPE_ARITHMETIC.json').read_text())
    n = 28
    fan = Fraction(n*n, 4) + (n*n - Fraction(81,5)*n + 56)/320
    if str(fan) != old['fan_bound'] or fan != Fraction(78883,400):
        raise ValueError('Fan arithmetic mismatch')
    maximum_integer = (fan.numerator - 1)//fan.denominator
    if maximum_integer != 197:
        raise ValueError('Strict integrality mismatch')
    for row in old['high_degree_screens']:
        b = row['Delta']; a = 27-b; t = 196-b*(28-b)
        cap = a*max((Fraction(s*(a+1-2*s),a-s) for s in range(a)),default=Fraction(0))
        if (a,t,b+2*t,str(cap)) != (row['a'],row['t'],row['b_plus_2t'],row['a_Ma']):
            raise ValueError('High-degree arithmetic mismatch')
        if b+2*t <= cap:
            raise ValueError('Missing strict contradiction')
    if [v['Delta'] for v in old['high_degree_screens']] != list(range(17,27)):
        raise ValueError('Incomplete degree table')
    result = {'all_pass':True,'fan_exact':str(fan),'strict_integer_upper_bound':197,
              'fixed_target_high_degrees_checked':list(range(17,27)),
              'remaining_upper_bound_case':{'n':28,'Delta':15,'m':197},
              'published_and_graph_theoretic_premises_not_checked_by_this_arithmetic':True,
              'm197_search_executed':False}
    (ROOT/'evidence/SCOPE_CHECK_REPORT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__ == '__main__':
    main()
