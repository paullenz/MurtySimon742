"""Exact incremental v7 certificate/coverage checker; Python standard library only.
Does not import discovery models, numpy, scipy or a solver.
"""
from pathlib import Path
import json,gzip,hashlib,time,sys,copy
from collections import Counter
from check_local import rebuild_local
from check_ledger import rebuild_ledger
from check_total import rebuild_total
from check_constraints import verify_named
from one_spare import verify_profile
ROOT=Path(__file__).resolve().parents[1]
INPUT_SHA='048e855d83d4e6011ddacdb0846088bf4e6da17c145649e7b7b93555c3435ddb'

def need(x,msg):
    if not x:raise ValueError(msg)

def main():
    start=time.time();raw=(ROOT/'dependencies/v6_FINAL_SURVIVORS.json.gz').read_bytes()
    need(hashlib.sha256(raw).hexdigest()==INPUT_SHA,'Frozen input hash mismatch')
    data=json.loads(gzip.decompress(raw));bypos={r['position']:r for r in data}
    need(len(data)==len(bypos)==388,'Invalid complete v6 input');pending=set(bypos);counts={};first=None
    for phase,builder in [('LOCAL',rebuild_local),('LEDGER',rebuild_ledger),('TOTAL',rebuild_total)]:
        certs=json.loads(gzip.decompress((ROOT/f'evidence/{phase}_CERTIFICATES.json.gz').read_bytes()))
        seen=set()
        for rec in certs:
            pos=rec['position'];need(type(pos)==int and pos in pending and pos not in seen,'Uncovered/duplicate certificate row')
            inp=bypos[pos];need(rec['index']==inp['index'],'Mismatched original row')
            need(len(inp['s'])==12 and len(inp['row'][2:])==15 and inp['row'][1]==sum(inp['row'][2:]),'Invalid dimension/sum')
            model=builder(inp['s'],inp['row'][2:],inp['state'],t=1);verify_named(model,rec['certificate']);seen.add(pos)
            if first is None:first=(model,rec['certificate'])
        survivors=json.loads((ROOT/f'evidence/{phase}_SURVIVOR_POSITIONS.json').read_text())
        need(len(survivors)==len(set(survivors)) and all(type(p)==int for p in survivors),'Duplicate/invalid survivors')
        need(set(survivors).isdisjoint(seen) and set(survivors)|seen==pending,'Incomplete phase partition')
        counts[phase]={'input_rows':len(pending),'exact_rejections':len(seen),'survivors':len(survivors)};pending=set(survivors)
        print('checked',phase,counts[phase],round(time.time()-start,2),flush=True)
    for cert in json.loads((ROOT/'evidence/ONE_SPARE_CERTIFICATES.json').read_text()):
        inp=bypos[cert['position']];need(inp['index']==cert['index'],'Bad hand input');verify_profile(inp['s'],inp['row'][2:],cert)
    model,cert=first;controls=[]
    mutations=[]
    mutations.append(('zero_dual',{'ub':[],'eq':[],'rhs':-1}))
    mutations.append(('unknown_constraint',{'ub':[['f'*64,1]],'eq':[],'rhs':-1}))
    bad=copy.deepcopy(cert);bad['rhs']-=1;mutations.append(('wrong_rhs',bad))
    if cert['ub']:
        bad=copy.deepcopy(cert);bad['ub'][0][1]=-abs(bad['ub'][0][1])-1;mutations.append(('negative_inequality_weight',bad))
    for kind in ('ub','eq'):
        if cert[kind]:
            bad=copy.deepcopy(cert);bad[kind].append(copy.deepcopy(bad[kind][0]));mutations.append(('duplicate_multiplier',bad));break
    for label,bad in mutations:
        try:verify_named(model,bad)
        except ValueError:controls.append(label)
        else:raise ValueError('Corrupted evidence accepted: '+label)
    # Test the coverage gate with omission/duplication independently of any solver.
    one=next(iter(bypos));allpos=set(bypos)
    for label,left,right in [('omitted_disposition',allpos-{one},[]),('duplicate_disposition',allpos,[one])]:
        try:need(left.isdisjoint(right) and left|set(right)==allpos,'partition control')
        except ValueError:controls.append(label)
        else:raise ValueError('Corrupted coverage accepted')
    report={'all_pass':True,'input_rows':388,'stages':counts,'total_exact_rejections':388-len(pending),'final_survivors':len(pending),'final_demand_patterns':len({bypos[p]['row'][0] for p in pending}),'scope':{'n':28,'Delta':15,'m':196},'mathematical_status':'candidate; independent external review OPEN','higher_edge_count_coverage':False,'full_order_claimed':False,'new_solver_calls_in_check':0,'negative_controls_rejected':controls,'seconds':time.time()-start}
    (ROOT/'evidence/EXACT_CHECK_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
    final=[bypos[pos] for pos in sorted(pending)]
    (ROOT/'evidence/FINAL_SURVIVORS.json.gz').write_bytes(gzip.compress((json.dumps(final,separators=(',',':'))+'\n').encode(),mtime=0))
    print('DONE',report,flush=True)
if __name__=='__main__':main()
