"""Lift saved actual critical graph selected systems into the new model exactly."""
from pathlib import Path
import sys,json,gzip,time
from fractions import Fraction
from collections import Counter
from itertools import product
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'dependencies'))
import test_lift as old
from check_total import rebuild_total as rebuild_local
from check_constraints import partition
ROOT=Path(__file__).resolve().parents[1]

def run(limit=None):
    records=json.loads(gzip.decompress((ROOT/'dependencies/actual_graph_instances.json.gz').read_bytes()))
    stats=Counter();start=time.time()
    for rec in records[:limit]:
        a,b,d,R,rho,s,q,adj,sel,res,F,triples=old.unpack(rec)
        forced=[sum(1<<u for u in range(b) if rho[u]>=si) if si>0 and sum(rr>=si for rr in rho)==si else 0 for si in s]
        st={'domains':[[[d[i],R[i],R[i]+s[i]-d[i]]] for i in range(a)],'c':[min(a-rr,b-1) for rr in rho],'forced':forced}
        # use demand-class union of actual columns so averaging is genuinely fractional
        st['domains']=[sorted([list(v) for v in {(d[j],R[j],R[j]+s[j]-d[j]) for j in range(a) if s[j]==s[i]}]) for i in range(a)]
        L,B=partition(s,rho,st);model=rebuild_local(s,rho,st,rec['t']);values={}
        cols=[(d[i],R[i],R[i]+s[i]-d[i]) for i in range(a)]
        def status(u,i):return 0 if (u,i) in sel else 1 if (u,i) in res else 2
        for u in range(b):
            S={i for i in range(a) if status(u,i)==0};T={i for i in range(a) if status(u,i)==1};M={i for i in range(a) if status(u,i)==2}
            eS=sum(i in S and j in S for i,j in F); eM=sum(i in M and j in M for i,j in F)
            cTM=sum(tuple(sorted((i,j))) not in F for i in T for j in M)
            assert rho[u]+2*eS+eM-cTM<=sum(rho)
            stats['residual_charge_vertex_checks']+=1
            stats['positive_S_edge_count']+=eS>0;stats['positive_M_edge_count']+=eM>0
        pdeg=[sum(w==u for v,i,w in triples) for u in range(b)]
        xdeg=[sum(ii==i for u,ii in sel) for i in range(a)]
        for name in model.variables:
            typ=name[0]
            if typ=='local':
                _,k,qq,g,h,x,y,e=name
                tuples=[(u,i,j) for u in B[k] for i in L[g] for j in L[h] if i!=j]
                num=sum(q[u]==qq and status(u,i)==x and status(u,j)==y and (tuple(sorted((i,j))) in F)==bool(e) for u,i,j in tuples)
                values[name]=Fraction(num,len(tuples))
            elif typ=='column_x':
                _,g,o,xx=name;op=tuple(st['domains'][L[g][0]][o]);values[name]=Fraction(sum(cols[i]==op and xdeg[i]==xx for i in L[g]),len(L[g]))
            elif typ=='source_qp':
                _,k,qq,pp=name;values[name]=Fraction(sum(q[u]==qq and pdeg[u]==pp for u in B[k]),len(B[k]))
            elif typ=='selected_qpx':
                _,k,g,o,qq,pp,xx=name;op=tuple(st['domains'][L[g][0]][o]);values[name]=Fraction(sum((u,i) in sel and q[u]==qq and pdeg[u]==pp and cols[i]==op and xdeg[i]==xx for u in B[k] for i in L[g]),len(B[k])*len(L[g]))
            elif typ=='y':
                _,g,o=name;op=tuple(st['domains'][L[g][0]][o]);values[name]=Fraction(sum(cols[i]==op for i in L[g]),len(L[g]))
            elif typ in ('sel','res'):
                _,k,g,o=name;op=tuple(st['domains'][L[g][0]][o]);edges=sel if typ=='sel' else res
                values[name]=Fraction(sum((u,i) in edges and cols[i]==op for u in B[k] for i in L[g]),len(B[k])*len(L[g]))
            elif typ in ('F','internalF'):
                if typ=='F':_,g,h=name;us=[None]
                else:_,k,g,h=name;us=B[k]
                pairs=[(i,j) for i in L[g] for j in L[h] if i!=j]
                num=sum(tuple(sorted((i,j))) in F and (u is None or ((u,i) in sel and (u,j) in sel)) for u in us for i,j in pairs)
                values[name]=Fraction(num,len(us)*len(pairs))
            elif typ=='arc':
                _,k,l,g=name;den=len(B[k])*(len(B[l])-(k==l))*len(L[g]);values[name]=Fraction(sum(u in B[k] and w in B[l] and i in L[g] for u,i,w in triples),den)
            elif typ=='degree_type':
                _,k,qq=name;values[name]=Fraction(sum(q[u]==qq for u in B[k]),len(B[k]))
            elif typ in ('typed_sel','typed_res','typed_miss'):
                _,k,g,o,qq=name;op=tuple(st['domains'][L[g][0]][o]);ss=('typed_sel','typed_res','typed_miss').index(typ)
                values[name]=Fraction(sum(q[u]==qq and cols[i]==op and status(u,i)==ss for u in B[k] for i in L[g]),len(B[k])*len(L[g]))
            elif typ=='pair_type':
                _,k,l,qq,vv=name;den=len(B[k])*(len(B[l])-(k==l));values[name]=Fraction(sum(u in B[k] and w in B[l] and q[u]==qq and q[w]==vv for u,i,w in triples),den)
            else:raise ValueError(name)
        for eq,rows in [(True,model.equalities),(False,model.inequalities)]:
            for key,(expr,rhs) in rows.items():
                val=sum(c*values[n] for n,c in expr.items())
                if (val!=rhs if eq else val>rhs):raise ValueError(('lost_actual_graph',rec,expr,rhs,val))
                stats['exact_constraint_evaluations']+=1
        stats['fractional_values']+=sum(v.denominator>1 for v in values.values());stats['selected_systems']+=1
        stats['positive_surplus']+=rec['t']>0
    report={'all_pass':True,'counts':dict(stats),'seconds':time.time()-start,'no_universal_claim_from_finite_tests':True}
    (ROOT/'evidence/ACTUAL_TOTAL_LIFT_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
if __name__=='__main__':run(int(sys.argv[1]) if len(sys.argv)>1 else None)
