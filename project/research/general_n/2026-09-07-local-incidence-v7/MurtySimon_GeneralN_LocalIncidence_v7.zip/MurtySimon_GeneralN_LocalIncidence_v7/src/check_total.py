"""Separate named-variable builder for actual selected-column and total source types."""
from check_ledger import rebuild_ledger
from check_constraints import partition,variable,add
from collections import defaultdict


def rebuild_total(s,rho,state,t=1,local=False):
    system=rebuild_ledger(s,rho,state,t,local=local)
    old=set(system.variables);A,Bsize=len(s),len(rho);L,B=partition(s,rho,state)
    labels={};sources={};E={}
    for g,G in enumerate(L):
        i=G[0];mandatory=sum((state['forced'][i]>>u)&1 for u in range(Bsize))
        for o,option in enumerate(state['domains'][i]):
            required=max(s[i],mandatory);upper=Bsize-option[1]
            keys=[('column_x',g,o,x) for x in range(required,upper+1)]
            for key in keys:system.register(variable(*key));labels[key[1:]]=key
            system.row(add(*[(1,variable(*key)) for key in keys],(-1,variable('y',g,o))),0,True)
    for name in sorted(old):
        if name[0]!='degree_type':continue
        _,k,q=name;u=B[k][0]
        limit=min(Bsize-1-q,rho[u]+Bsize-A-1)
        keys=[('source_qp',k,q,p) for p in range(limit+1)]
        for key in keys:system.register(variable(*key));sources[key[1:]]=key
        system.row(add(*[(1,variable(*key)) for key in keys],(-1,variable(*name))),0,True)
        terms=[(-key[-1],variable(*key)) for key in keys]
        for key in old:
            if key[0]=='pair_type' and (key[2],key[4])==(k,q):terms.append((len(B[key[1]])-(key[1]==k),variable(*key)))
        system.row(add(*terms),0,True)
    # Every selected event simultaneously knows both its actual endpoint types.
    source_at=defaultdict(list);label_at=defaultdict(list)
    for (k,q,p),key in sources.items():source_at[k,q].append(p)
    for (g,o,x),key in labels.items():label_at[g,o].append(x)
    for name in sorted(old):
        if name[0]!='typed_sel':continue
        _,k,g,o,q=name;R=state['domains'][L[g][0]][o][1];terms=[(-1,variable(*name))]
        for p in source_at[k,q]:
            for x in label_at[g,o]:
                if not x or R+x<q+p:continue
                key=('selected_qpx',k,g,o,q,p,x);system.register(variable(*key));E[key]=1;terms.append((1,variable(*key)))
        system.row(add(*terms),0,True)
    by_source_label=defaultdict(dict);by_label_source=defaultdict(dict)
    for key in E:
        _,k,g,o,q,p,x=key
        by_source_label[k,q,p,g][key]=1;by_label_source[g,o,x,k][key]=1
    for (k,q,p),key in sources.items():
        terms=[(-q,variable(*key))]
        for g,G in enumerate(L):
            expr=by_source_label[k,q,p,g]
            system.row(add((1,expr),(-1,variable(*key))),0)
            terms.append((len(G),expr))
        system.row(add(*terms),0,True)
    for (g,o,x),key in labels.items():
        terms=[(-x,variable(*key))]
        for k,U in enumerate(B):
            expr=by_label_source[g,o,x,k]
            system.row(add((1,expr),(-1,variable(*key))),0)
            terms.append((len(U),expr))
        system.row(add(*terms),0,True)
    for key in tuple(system.variables):system.row(variable(*key),1)
    return system

if __name__=='__main__':
    from pathlib import Path
    import json,gzip,time
    from check_constraints import verify_named
    root=Path(__file__).resolve().parents[1];rows=json.loads(gzip.decompress((root/'dependencies/v6_FINAL_SURVIVORS.json.gz').read_bytes()));bypos={r['position']:r for r in rows}
    tests=json.loads((root/'evidence/TOTAL_DEGREE_PILOT.json').read_text());n=0;start=time.time()
    for result in tests:
        if result['certificate'] is None:continue
        rec=bypos[result['position']];model=rebuild_total(rec['s'],rec['row'][2:],rec['state']);verify_named(model,result['certificate']);n+=1
    print('exact pilot checks',n,'seconds',time.time()-start)
