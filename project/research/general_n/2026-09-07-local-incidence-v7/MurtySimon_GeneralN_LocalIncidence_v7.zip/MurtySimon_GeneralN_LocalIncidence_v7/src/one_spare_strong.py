"""Exactly h+1 maximum-residual sources can support at most 2h demand-h labels.
The proof is symbolic in PROOF.md; this program checks input premises, its
integer case arithmetic, and the saved overlap certificates.
"""
from pathlib import Path
import json,gzip,time,copy
ROOT=Path(__file__).resolve().parents[1]

def verify(s,rho,c):
    h=c['h'];Z=c['high_sources'];I=c['labels']
    if type(h)!=int or h<1:raise ValueError('positive integer h')
    if any(type(v)!=int or v<0 for v in list(s)+list(rho)):raise ValueError('integer nonnegative degrees/demands')
    if len(set(Z))!=len(Z) or len(Z)!=h+1 or any(type(u)!=int or not 0<=u<len(rho) for u in Z):raise ValueError('high source block')
    if any(rho[u]!=h for u in Z) or any(rho[u]>=h for u in range(len(rho)) if u not in Z):raise ValueError('maximum residual class')
    if len(set(I))!=len(I) or len(I)!=2*h+1 or any(type(i)!=int or not 0<=i<len(s) or s[i]!=h for i in I):raise ValueError('heavy label block')
    # k = number of chosen heavy labels selected at every high source.
    # k>h is impossible from the total high pair-degree budget. At k=0,
    # at most one heavy label can have d_i=2h. At k>=1, none can.
    if h*(2*h+1)<=2*h*h:raise ValueError('all high sources not forced active')
    gaps=[]
    for k in range(h+1):
        normal=2*h if k==0 else 2*h+1-k
        need=h*normal
        upper=(h-k)*(2*h-1)
        if need<=upper:raise ValueError('unclosed k case')
        gaps.append(need-upper)
    return gaps

def main():
    st=time.time();rows=json.loads(gzip.decompress((ROOT/'dependencies/v6_FINAL_SURVIVORS.json.gz').read_bytes()));at={r['position']:r for r in rows}
    certs=json.loads((ROOT/'evidence/ONE_SPARE_STRONG_CERTIFICATES.json').read_text())
    for c in certs:
        r=at[c['position']]
        if c['index']!=r['index']:raise ValueError('wrong original input')
        verify(r['s'],r['row'][2:],c)
    actual=json.loads(gzip.decompress((ROOT/'dependencies/actual_graph_instances.json.gz').read_bytes()));eligible=0
    for rec in actual:
        h=max(rec['rho'])
        if h>0 and rec['rho'].count(h)==h+1:
            eligible+=1
            if rec['s'].count(h)>2*h:raise ValueError('actual selected-system counterexample')
    for h in range(1,10001):
        if h*(2*h)-h*(2*h-1)!=h:raise ValueError('k zero identity')
        for k in {1,h}:
            if h*(2*h+1-k)-(h-k)*(2*h-1)!=2*h+(h-1)*k:raise ValueError('positive k identity')
    negative=[]
    c=certs[0];r=at[c['position']]
    for label,fn in [('strong_missing_source',lambda v:v['high_sources'].pop()),('strong_missing_label',lambda v:v['labels'].pop()),('strong_wrong_h',lambda v:v.update(h=v['h']+1))]:
        bad=copy.deepcopy(c);fn(bad)
        try:verify(r['s'],r['row'][2:],bad)
        except ValueError:negative.append(label)
        else:raise ValueError('invalid premise accepted')
    result={'all_pass':True,'overlapping_frontier_certificates':len(certs),'actual_selected_systems':len(actual),'matching_actual_maximum_classes':eligible,'distinct_labelled_graphs':len({tuple(r['g']) for r in actual}),'symbolic_arithmetic_h_range':[1,10000],'negative_controls':negative,'additional_exclusions_beyond_full_certificate_partition':0,'seconds':time.time()-st,'positive_surplus_actual_graphs':sum(r['t']>0 for r in actual),'universal_validity_not_inferred_from_finite_tests':True}
    (ROOT/'evidence/ONE_SPARE_STRONG_REPORT.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
if __name__=='__main__':main()
