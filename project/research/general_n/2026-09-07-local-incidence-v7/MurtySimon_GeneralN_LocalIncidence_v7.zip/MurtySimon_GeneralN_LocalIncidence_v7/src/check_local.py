"""Separate, standard-library reconstruction of local-incidence constraints.
Imports only the frozen v6 named-variable checker, not discovery or SciPy.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'dependencies'))
from check_constraints import rebuild_types,partition,add,variable,signature
KINDS=('typed_sel','typed_res','typed_miss')

def rebuild_local(s,rho,state,t=1,charge=True):
    out=rebuild_types(s,rho,state,t)
    nA=len(s);total=sum(rho);labels,sources=partition(s,rho,state)
    source_types={k: sorted(name[2] for name in out.variables if name[0]=='degree_type' and name[1]==k) for k in range(len(sources))}
    marg={};deg={};rescol={}
    for name in tuple(out.variables):
        if name[0] not in KINDS:continue
        kind,k,g,o,q=name;status=KINDS.index(kind);key=(k,q,g,status)
        marg.setdefault(key,{})[name]=1
        dd,rr,_=state['domains'][labels[g][0]][o]
        deg.setdefault(key,{})[name]=dd;rescol.setdefault(key,{})[name]=rr
    locals=set()
    for k,U in enumerate(sources):
        for q in source_types[k]:
            sizes=(q,rho[U[0]],nA-q-rho[U[0]])
            for g in range(len(labels)):
                for h in range(g,len(labels)):
                    if g==h and len(labels[g])==1:continue
                    for x in range(3):
                        for y in range(x if g==h else 0,3):
                            if sizes[x] < 1+(x==y) or sizes[y]<1:continue
                            if not marg.get((k,q,g,x)) or not marg.get((k,q,h,y)):continue
                            for edge in (0,1):
                                if edge and ((x==0 and y==2) or (x==2 and y==0)):continue
                                key=('local',k,q,g,h,x,y,edge);out.register(variable(*key));locals.add(key)
    def indicator(k,q,g,h,x,y,edge):
        if g>h:g,h,x,y=h,g,y,x
        if g==h:x,y=min(x,y),max(x,y)
        key=('local',k,q,g,h,x,y,edge)
        return variable(*key) if key in locals else {}
    def marginal(k,q,g,x):return marg.get((k,q,g,x),{})
    for k,U in enumerate(sources):
        rr=rho[U[0]]
        for q in source_types[k]:
            sizes=(q,rr,nA-q-rr)
            for g,G in enumerate(labels):
                for h,H in enumerate(labels):
                    if g==h and len(G)==1:continue
                    for x in range(3):
                        terms=[(1,indicator(k,q,g,h,x,y,edge)) for edge in (0,1) for y in range(3)]
                        out.row(add(*terms,(-1,marginal(k,q,g,x))),0,True)
                for x in range(3):
                    for y in range(3):
                        terms=[(len(H)-(g==h),indicator(k,q,g,h,x,y,edge)) for h,H in enumerate(labels) for edge in (0,1) if len(H)-(g==h)>0]
                        terms.append((-(sizes[y]-(x==y)),marginal(k,q,g,x)))
                        out.row(add(*terms),0,True)
                    terms=[(len(H)-(g==h),indicator(k,q,g,h,x,y,1)) for y in range(3) for h,H in enumerate(labels) if len(H)-(g==h)>0]
                    terms.append((-1,deg.get((k,q,g,x),{})))
                    out.row(add(*terms),0,True)
                parts=[(len(H)-(g==h),indicator(k,q,g,h,0,0,1)) for h,H in enumerate(labels) if len(H)-(g==h)>0]
                out.row(add(*parts,(-1,rescol.get((k,q,g,0),{}))),0)
            if charge:
                parts=[(-(total-rr),variable('degree_type',k,q))]
                for g,G in enumerate(labels):
                    for h in range(g,len(labels)):
                        pairs=len(G)*len(labels[h]) if g!=h else len(G)*(len(G)-1)//2
                        if pairs==0:continue
                        parts.extend([(2*pairs,indicator(k,q,g,h,0,0,1)),(pairs,indicator(k,q,g,h,2,2,1)),(-pairs,indicator(k,q,g,h,1,2,0)),(-pairs,indicator(k,q,g,h,2,1,0))])
                out.row(add(*parts),0)
        for g,G in enumerate(labels):
            for h in range(g,len(labels)):
                if g==h and len(G)==1:continue
                terms=[(1,indicator(k,q,g,h,x,y,1)) for q in source_types[k] for x in range(3) for y in range(3)]
                out.row(add(*terms,(-1,variable('F',g,h))),0,True)
    for name in tuple(out.variables):out.row(variable(*name),1)
    return out

if __name__=='__main__':
    import json,gzip,time
    from check_constraints import verify_named
    root=Path(__file__).resolve().parents[1]
    data=json.loads(gzip.decompress((root/'dependencies/v6_FINAL_SURVIVORS.json.gz').read_bytes()))
    at={rec['position']:rec for rec in data}
    results=json.loads((root/'evidence/LOCAL_PILOT.json').read_text());checked=0
    for rec in results:
        if rec['certificate'] is None:continue
        inp=at[rec['position']];model=rebuild_local(inp['s'],inp['row'][2:],inp['state']);verify_named(model,rec['certificate']);checked+=1
    print('CHECKED',checked)
