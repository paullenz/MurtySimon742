"""Condition the fixed ledgers and residual charges on an actual source degree."""
from local_incidence import build_local
from degree_types import build_types
from check_constraints import partition


def extend_ledger(m,s,rho,state,t=1,extra=True):
    a=len(s);b=len(rho);r=sum(rho);L,B=partition(s,rho,state)
    ix={name:j for j,name in enumerate(m.names)}
    for key,w in ix.items():
        if key[0]!='degree_type':continue
        _,k,q=key;u=B[k][0]
        rd={w:-r};dd={w:-2*(r+t)};rs={w:-(r-rho[u])};ds={w:-(rho[u]*(2*a-rho[u]-3+q)-2*t)}
        for name,j in ix.items():
            if name[0] not in ('typed_sel','typed_res','typed_miss'):continue
            kind,kk,g,o,qq=name
            if (kk,qq)!=(k,q):continue
            d,R,z=state['domains'][L[g][0]][o];N=len(L[g]);rd[j]=N*R;dd[j]=N*d
            if kind=='typed_sel':rs[j]=N*R;ds[j]=N*d
        m.equal(rd,0);m.equal(dd,0)
        if extra:m.le(rs,0);m.le(ds,0)
    m.bound_start=len(m.ub)
    for j in range(len(m.names)):m.le({j:1},1)
    return m

def build_ledger(s,rho,state,t=1,local=True):
    m=(build_local if local else build_types)(s,rho,state,t)
    return extend_ledger(m,s,rho,state,t)
