# Proposed repository status section — not remotely applied

Use this only when the complete v6/v7 checkpoints have been committed and their archive/manifest hashes checked. Do not link to files that have not been published. Retain the existing frozen n25/n27 entry points and review labels.

## Order-28 continuation through v7

**Candidate mathematics; new exact arithmetic internally reproduced; independent review OPEN.** At n=28, maximum degree 15 and exactly 196 edges, the v5 frontier of 6918 numerical rows reduced to 388 in v6. The v7 local-incidence, conditional-ledger and endpoint-degree models exclude all remaining 388, with a complete exact integer certificate partition and zero survivors.

Together with the inherited degree reductions this closes the candidate **196-edge equality branch**: any diameter-two edge-critical graph with 28 vertices and exactly 196 edges is K14,14. It does not prove the order-28 upper bound. Fan's strict bound at n=28 gives m<197.2075; the remaining upper-bound case is **maximum degree 15 with 197 edges**. Its t=2 domains have not been searched in v7, and the new t=1 exact-column tests are not assumed monotone in edge count.

V7 also derives a source-relative residual injection and a general one-spare-source lemma: exactly h+1 sources of maximum residual degree h cannot supply 2h+1 demand-h labels. Nineteen hand applications overlap the finite certificates. A specified infinite above-target family starts at (32,17,257); these are profile exclusions, not full-order results. The general coefficient `(10-sqrt(2))/14` remains unchanged.

The exact v7 checking route needs only Python's standard library and no optimiser or compiler. It is incremental on the pinned v6 frontier, not a new replay of every upstream computation. No positive-surplus actual graph occurs in the saved tests. The frozen proofs, governed ledger, external-review status and novelty/priority qualifications are unchanged.
