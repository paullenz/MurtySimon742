# Review and handoff — v7

7 September 2026. Candidate mathematics; exact new finite arithmetic reproduced; independent review OPEN.

## Current position

The 388 v6 survivors at (n,Delta,m)=(28,15,196) are all excluded by exact certificates. The complete partition is 22 local-incidence exclusions, then 19 conditional-ledger exclusions, then 347 endpoint-degree exclusions. Nineteen short one-spare-source hand certificates overlap this partition. They are not another 19 rows.

The candidate equality-only chain at n=28 is now complete under its stated inherited inputs: any 196-edge graph is K14,14. The full order-28 conjecture is still OPEN. Fan's bound and the inherited degree screens leave exactly maximum degree 15 with 197 edges. The full conjecture, other complete new orders, the uniform high-degree coefficient, external review status and governed theorem ledger are unchanged.

## What was actually recovered and checked

The source v6 ZIP was tested for CRCs and all 88 payload hashes; its own integrity wrapper passed. The 388 expanded input rows were matched against the original v5 states and demand data pinned inside that package. Required v6 model/checker libraries were copied byte-for-byte and identified in `dependencies/SOURCES.json`.

This continuation did not rerun all 6530 earlier v6 exclusions, the v5 13196-row pass, the v4 17669896-row expansion, or the older demand screens. It relies on their saved, versioned proof/coverage chains. The new standalone checker independently reconstructs and verifies every one of the 388 NEW exclusions and each complete phase partition.

Both full model builders were compared on every new rejection during discovery. The portable check imports no discovery model or solver. The shared names/partition helper and immutable input are disclosed dependencies; agreement is not independent mathematical authorship. The main check is a small exact integer certificate verifier plus model generation, not a formal proof kernel for the graph arguments.

## Main mathematical review obligations

The most important new points to attack are:

1. The disjointness of the selected-endpoint, missing-endpoint and source-residual families in Lemma 3.1, including the T–M auxiliary count and unique-exception injectivity.
2. The normalization of ordered versus unordered label pairs in the local incidence model; especially equal label classes, off-diagonal statuses, and empty degree events.
3. Conditioning fixed global ledgers on source degree: coefficients must multiply the event weight, not silently assume conditional probability one.
4. The actual endpoint-type coupling R_i+x_i>=q_u+p_u, its selected-incidence marginals, and the bounds that omit impossible x,p types. All real graph assignments must lift to the relaxation.
5. The one-spare-source lemma's separate k=0 and k>=1 cases, including the limit on exceptional labels and the shared incoming-degree budget.

Inherited review obligations include the quasi-edge correspondence, activity and residual charging lemmas, safe column pruning and forced-source masks, and completeness of all upstream domains. A negative certificate does not by itself prove that its model describes every graph.

## Falsification and negative controls

All 916 saved actual selected systems are unpacked and their graph criticality, root and quasi-edge choices rechecked. The three model lifts perform 115632, 123214 and 219158 exact constraint evaluations. These are multiple tests of the same sample, not 458004 distinct graphs. Fractional symmetry values occur. The source-relative residual inequality is tested at 3532 B-vertex occurrences, including positive selected-internal and missing-internal F-edge counts. No positive-surplus actual graph exists in this sample.

The exact checker rejects seven damaged certificate/coverage objects. Each of the two hand-lemma premise checkers rejects three altered premise certificates. The strong hand lemma has 19 frontier applications and is tested on 71 actual residual classes meeting its source-cardinality premise. The infinite family has symbolic proofs of exclusion and separate graphicality; finite arithmetic tests through h=10000 and explicit separate graph constructions through h=100 are regressions, not the all-order proof.

## Exploratory and operational material

The local and endpoint ten-row pilots overlap later full scans. `LEAN_MODEL_PILOT.json` contains a numerical-only ten-row experiment on a smaller model; no certificates were exported for it and it contributes no exclusion. Its role is to suggest a possible future simplification of the dependency chain. `TOTAL_DEGREE_PILOT_BUILDER.py` preserves the slower pre-indexing source. The optimized production model was compared against the separate builder's entire constraint set.

The first attempt to test the infinite-family construction at every large h spent too much work materialising graphs; it was interrupted without producing a proof result. The finished test uses exact symbolic identities through h=10000 and constructs only h=4,...,100. The archived final reports identify these completed scopes. No timeout or solver status is counted as an exclusion. Separate graph-lift report filenames were assigned before packaging so that running one model test no longer overwrites another model's report; the earlier last-written report is preserved as `ACTUAL_TOTAL_LIFT_INITIAL_REPORT.json`.

## Next mathematical task: (28,15,197)

For the one remaining upper-bound case, a=12,b=15,t=2. Regenerate the demand and residual/slack domains at t=2, then apply safe column propagation and the strongest exact endpoint model. Reuse the proved universal inequalities, not a bare assumption that the t=1 survivors form the correct t=2 input.

A suitable success criterion is a complete, independently reconstructed necessary-domain partition with exact certificates for every final row, or a new hand implication covering every t=2 possibility. A surviving relaxation is not a counterexample graph. A solver timeout is not an exclusion. Final assembly must separately state the upper bound and the already covered equality characterization.

After that, the most useful general-order direction is to quantify the source-class obstruction when more than one spare source is available. The v7 theorem handles exactly h+1 maximum-residual sources. Nothing in this package claims the analogous bound for an arbitrary larger class.

## Preservation state

The source v6 and new v7 artifacts are preserved locally with complete manifests. GitHub was read at `00ad1a511971397fcd8a4341b021493c2383252e`. The available action schemas in this turn expose repository reads, not a callable write action; write-tool discovery and installed-plugin search were attempted. A direct CLI route was not available (no GitHub CLI/token, and container DNS lookup failed). These facts do not diagnose a loss of the user's GitHub permission. No new remote commit, branch update, or README update is claimed. Publication remains separate from the mathematics.
