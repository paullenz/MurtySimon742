# Local incidence and endpoint-degree consistency — general-order continuation v7

7 September 2026. Research directed by Paul Lenz; derivations, programs and internal checking by ChatGPT/Geeps.

**Status: candidate mathematics; complete new finite arithmetic reproduced by a separately written exact checker; independent mathematical review OPEN.** No complete order-28 upper bound, new uniform maximum-degree coefficient, priority, external endorsement, or formal-kernel verification is claimed.

## 1. Result, scope and dependency boundary

This continuation closes the preserved v6 frontier of **388 numerical rows in 167 demand patterns**, specifically at

\[
(n,\Delta,m)=(28,15,196),\qquad a=12,\quad b=15,\quad t=1.
\]

The local-incidence model excludes 22 rows; conditional ledger constraints exclude 19 of the remaining rows; endpoint-degree consistency excludes all remaining 347. Every exclusion has an exact integer certificate, reconstructed and verified separately. There are zero surviving numerical rows. The three models are necessary-condition relaxations, not graph construction algorithms. No integrality assumption is imposed on a symmetry-averaged probability.

Combined with the inherited project reductions and upstream numerical coverage, this gives a **complete candidate chain for the equality-only statement**: a diameter-two edge-critical graph on 28 vertices with exactly 196 edges is K14,14. It does **not** establish that no such graph has 197 edges. Section 10 gives the precise remaining upper-bound case.

The input is `dependencies/v6_FINAL_SURVIVORS.json.gz`, SHA-256 `048e855d83d4e6011ddacdb0846088bf4e6da17c145649e7b7b93555c3435ddb`. It is copied without change from the v6 archive, whose SHA-256 is `d00a9627e9ed4d8a6f22ae1f2b194791412ee2d16d502b1968be16e02aa30496`. This session verified all 88 v6 payload hashes and cross-checked the 388 expanded states against the v5 source data pinned inside v6. It did not rerun the entire previous v6 arithmetic route or the upstream v3/v4/v5 enumerations. Their coverage arguments, domains and graph-theoretic necessity remain explicit dependencies.

The last verified repository baseline is `00ad1a511971397fcd8a4341b021493c2383252e` of `paullenz/MurtySimon25`, containing the completed v5 publication and receipt. This document does not claim that v6 or v7 has been committed there.

## 2. Residual framework and inherited facts

Let G be a simple diameter-two edge-critical graph. Stars and complete bipartite graphs are handled separately. For the other cases, the published complement correspondence makes H=the complement of G a 3-total-domination-edge-critical graph [1,2]. Choose a vertex v of minimum H-degree and write

\[
A=N_H(v),\quad B=V(H)\setminus N_H[v],\quad a=|A|,\quad b=|B|=\Delta(G),\quad n=a+b+1.
\]

Write C=H[A] and F=the complement of C on A, with degrees d_i in F. For a missing B-pair choose exactly one existing cross quasi-edge ui whose endpoints totally dominate every vertex of H except its unique exception w in B; write `ui -> w`. The auxiliary i lies in A because the edge must dominate v. Orient the missing B-pair from u to w.

Different missing pairs use different selected cross-edges: the B-endpoint and the unique exception identify the missing pair. At a source, selected labels and supplements are distinct. Call all other existing A–B edges residual. Define

\[
\begin{split}
&\rho_u=\text{residual degree at }u\in B,\qquad R_i=\text{residual degree at }i\in A,\qquad r=\sum_u\rho_u=\sum_iR_i,\\
&q_u=\text{outdegree of the selected-pair orientation},\qquad p_u=\text{indegree},\qquad \sigma_u=q_u+p_u,\\
&x_i=\text{actual selected degree at label }i,\qquad Q=\sum q_u=\sum p_u=\sum x_i,\\
&t=m-b(n-b),\qquad \ell=b-a-1=2b-n,\qquad s_i=\max(0,d_i-R_i).
\end{split}
\]

The inherited residual identities and inequalities [3–6] are

\[
e(F)=r+t,\quad \sum_i d_i=2(r+t),\quad x_i\ge s_i,\quad q_u+\rho_u\le a,\quad p_u\le\rho_u+\ell,\quad q_u+p_u\le b-1.\tag{2.1}
\]

The bound on p_u follows directly from minimum H-degree: the degree of u in H is

\[
(b-1-q_u-p_u)+(\rho_u+q_u)=b-1+\rho_u-p_u\ge a.
\]

For every selected `ui -> w`, the previous project injections give

\[
d_i\le\rho_u+R_i,\quad d_i\le\rho_u+\rho_w,\quad d_i\le\rho_u+q_u-1,\quad \rho_w+q_w\ge q_u-1.\tag{2.2}
\]

A further inherited restriction [5] is

\[
\boxed{R_i+x_i\ge q_u+p_u=\sigma_u.}\tag{2.3}
\]

Indeed i must be adjacent to u and to every selected-pair neighbour of u other than w: u misses every such neighbour, and `ui` has only w as its exception. These are sigma_u distinct B-neighbours of i. The equality R_i+x_i=d_H(i,B) gives (2.3).

The new work does not reclassify these inputs as independently reviewed. In particular, positive surplus implies every residual B-degree is positive by an earlier injection; the numerical domains in v3–v6 use that premise. Some new lemmas below do not themselves require positive surplus.

## 3. A source-relative residual injection

Fix u in B. Partition A into the labels S selected at u, the residual neighbours T of u, and the non-neighbours M of u. Thus

\[
|S|=q_u,\quad |T|=\rho_u,\quad |M|=a-q_u-\rho_u.
\]

No F-edge joins S and M. Otherwise a selected edge ui with i in S would miss a vertex of M in addition to its B-exception.

**Lemma 3.1.** For every source u,

\[
\boxed{\rho_u+2e_F(S)+e_F(M)-e_C(T,M)\le r.}\tag{3.1}
\]

**Proof.** For each i in S let w_i be the distinct supplement of ui. If ij is an F-edge within S, selected uj must dominate w_i, forcing jw_i; similarly iw_j exists. The edge iw_j misses j, since ij and jw_j are absent. It therefore cannot be a selected cross-edge whose unique exception is in B, and is residual. The same applies to jw_i. Distinct F-edges yield 2e_F(S) distinct residual cross-edges, by their A-endpoints and the distinct supplement labels. Their A-endpoints lie in S.

An F-edge ij within M is a missing H-pair whose endpoints both miss u. Criticality supplies an existing quasi-edge using i or j. Its auxiliary must be adjacent to u. It cannot be v, u, or a vertex of M. It cannot lie in S either, because every S–M pair is an edge of C and it would then dominate the proposed exceptional endpoint. Therefore the auxiliary lies in T or B.

Quasi-edges using T are distinct C-edges between T and M, so at most e_C(T,M) missing M-pairs can be handled this way. Each remaining pair supplies a residual cross-edge with A-endpoint in M: its exception lies in A, ruling out selection for a B-pair. Different missing M-pairs supply distinct edges, because an A-endpoint and the unique exception identify that pair.

Finally, u itself has rho_u residual cross-edges with A-endpoints in T. The S-, M-, and T-endpoint families are disjoint. Hence

\[
r\ge\rho_u+2e_F(S)+\max(0,e_F(M)-e_C(T,M)),
\]

which implies (3.1). This includes empty S, T or M. No complement-diameter-two assumption is used. □

### 3.2 A degree-only consequence

Using e(F)=r+t, no F-edge S–M, and e_C(T,M)=rho_u|M|-e_F(T,M), (3.1) becomes

\[
t+\rho_u+e_F(S)\le e_F(T)+e_F(S,T)+\rho_u|M|.
\]

Therefore

\[
\begin{split}
\sum_{i\in S}d_i
&=2e_F(S)+e_F(S,T)\\
&\le2e_F(T)+3e_F(S,T)+2\rho_u|M|-2t-2\rho_u\\
&\le\boxed{\rho_u(2a-\rho_u-3+q_u)-2t.}\tag{3.2}
\end{split}
\]

The last line uses 2e_F(T)<=rho_u(rho_u-1), e_F(S,T)<=q_u rho_u and |M|=a-q_u-rho_u. The source's own residual edges have endpoints outside S, so also

\[
\boxed{\sum_{i\in S}R_i\le r-\rho_u.}\tag{3.3}
\]

These are universal consequences in the stated selected system. The source-relative bound is not justified by a numerical experiment.

## 4. Symmetry reduction and degree-conditioned local incidences

Labels are grouped only when their demands, permitted individual column options (d,R,z), and forced-source masks agree. B-vertices are grouped only when their residual degrees, safe outgoing caps and forced-label incidence patterns agree. Let label class g have size N_g and source class k have size M_k.

Take a uniformly random permutation within these interchangeable classes. This is averaging relabelled copies of one actual graph; it does not assert that the original graph has those automorphisms. Each model variable is the average of an indicator, so lies in [0,1]. Such an average need not be integral even when the graph is integral.

The inherited v6 model has column-option variables y_go, source degree-type variables w_kq and degree-conditioned status variables A^X_kg oq, for status X in {S,T,M}. For a fixed source in k and label in g, A^X is the probability of the joint event: q_u=q, column option o, and that status. Summing all options and statuses gives w_kq; summing degrees over that partition gives the column marginal y_go.

The local model adds J_kqghXYe for two distinct labels, where e indicates their F-adjacency. The variables are probabilities for the joint degree/status/edge event. Within the same class the roles may be swapped, but the two labels remain distinct. Terms with impossible status counts are omitted. In particular J with e=1 and statuses S,M is identically zero.

The following are exact event identities for any actual graph, hence valid linear constraints after averaging.

* For each partner class h, summing J over the partner status and e yields the degree-conditioned first-label status marginal.
* For c_S=q, c_T=rho_k and c_M=a-q-rho_k, the number of other labels of status Y around a label of status X is c_Y-[X=Y]. Thus

\[
\sum_h(N_h-[g=h])\sum_e J_{kqghXYe}
=(c_Y-[X=Y])\sum_o A^X_{kgoq}.\tag{4.1}
\]

* The F-degree belongs to the same column option as that first label:

\[
\sum_h(N_h-[g=h])\sum_Y J_{kqghXY1}
=\sum_o d(o)A^X_{kgoq}.\tag{4.2}
\]

* A selected label's F-neighbours that are also selected at the source force distinct residual edges at that label. Consequently

\[
\sum_h(N_h-[g=h])J_{kqghSS1}
\le\sum_o R(o)A^S_{kgoq}.\tag{4.3}
\]

Averaging (3.1) conditional on q_u=q supplies one more row. Unordered label-pair multiplicities are N_gN_h for g<h and choose(N_g,2) for g=h. Off-diagonal statuses in a same-class pair are counted in both orientations, exactly as required. Finally, summing J over q and statuses returns the same F-edge marginal F_gh for every source class k.

`src/local_incidence.py` constructs this model; `src/check_local.py` reconstructs the same constraints using named variables. The two complete row sets and variable sets were compared for every saved rejection, not only the constraints appearing in its sparse certificate.

## 5. Condition the fixed global totals on each source degree

A fixed total does not stop being fixed when one conditions on q_u=q. For each source class k and degree q, the model therefore enforces

\[
\sum_{g,o,X}N_gR(o)A^X_{kgoq}=r\,w_{kq},\qquad
\sum_{g,o,X}N_gd(o)A^X_{kgoq}=2(r+t)\,w_{kq}.\tag{5.1}
\]

The earlier unconditioned totals alone need not enforce these identities in a fractional relaxation. Similarly, (3.2)–(3.3) give

\[
\begin{split}
\sum_{g,o}N_gR(o)A^S_{kgoq}&\le(r-\rho_k)w_{kq},\\
\sum_{g,o}N_gd(o)A^S_{kgoq}&\le[\rho_k(2a-\rho_k-3+q)-2t]w_{kq}.\tag{5.2}
\end{split}
\]

`src/conditional_ledger.py` implements these; `src/check_ledger.py` separately rebuilds them. All coefficients are integers.

## 6. Keep both endpoints' actual degree types

The final stage records the actual selected column degree x_i and the actual source incoming degree p_u simultaneously with the already retained q_u. This is a refinement of event marginals, not a branching assumption about their integrality.

For label class g and column option o add

\[
V_{gox}=\Pr[(d_i,R_i,z_i)=o,\ x_i=x],\qquad
\max(s_i,f_i)\le x\le b-R(o),\tag{6.1}
\]

where f_i is its number of forced sources. Require sum_x V_gox=y_go.

For source class k add

\[
W_{kqp}=\Pr[q_u=q,p_u=p],\qquad
0\le p\le\min(\rho_k+\ell,b-1-q),\tag{6.2}
\]

and sum_p W_kqp=w_kq. Using the inherited typed oriented-pair marginals P_lkvq, require the exact conditional incoming degree

\[
\sum_p pW_{kqp}=\sum_{l,v}(M_l-[l=k])P_{lkvq}.\tag{6.3}
\]

Finally add the selected source–label incidence probability

\[
Z_{kgoqpx}=\Pr[ui\text{ selected},\ o_i=o,\ q_u=q,\ p_u=p,\ x_i=x].
\]

Allow it only where the previous selected status was allowed, x>=1, and

\[
\boxed{R(o)+x\ge q+p.}\tag{6.4}
\]

This is (2.3) on the actual endpoint types, not merely on averaged degrees. Require

\[
\begin{split}
\sum_{p,x}Z_{kgoqpx}&=A^S_{kgoq},\\
\sum_{o,x}Z_{kgoqpx}&\le W_{kqp}\quad\text{for each }g,\\
\sum_{g,o,x}N_gZ_{kgoqpx}&=qW_{kqp},\\
\sum_{q,p}Z_{kgoqpx}&\le V_{gox}\quad\text{for each }k,\\
\sum_{k,q,p}M_kZ_{kgoqpx}&=xV_{gox}.\tag{6.5}
\end{split}
\]

Every equality counts the same actual incidences at one endpoint; the inequalities express that a fixed source–label pair has at most one selected edge. The normalizations N_g and M_k arise from class sizes, not from an assumed regular graph.

The final production model is **v6 degree types + (5.1)–(5.2) + (6.1)–(6.5)**. It omits the larger J-variable extension of Section 4 to keep the model smaller. Therefore the final stage is an alternative necessary strengthening on the remaining fixed input, not a claim that every intermediate model is nested inside every later model. The first two stages retain their own exact certificates.

`src/total_degree.py` constructs the final model; `src/check_total.py` reconstructs it separately. Every actual graph lifts to these equations by class averaging. Rejection of even this fractional relaxation suffices; no complete integral graph search or new branch-and-bound proof tree was needed in v7.

## 7. A general hand obstruction with one spare source

**Theorem 7.1 (candidate one-spare-source lemma).** In the residual framework above, let h>=1 be the maximum residual B-degree. If exactly h+1 B-vertices have residual degree h, then at most 2h A-labels can have demand h.

The theorem does not require positive surplus, a particular order, the incoming bound p_u<=rho_u+ell, or a numerical solver. It uses the selected-edge inequalities in Section 2, distinct source incidences, and the fact that a supplement misses its label.

**Proof.** Suppose I consists of 2h+1 demand-h labels, and Z is the set of h+1 residual-h sources. No source outside Z can select a label in I. Each i in I therefore has x_i=h or h+1. Write D_i=R_i+x_i.

If x_i=h, then R_i=d_i-h and D_i=d_i<=2h by (2.2). If x_i=h+1, every source in Z selects i, so its supplements must lie outside Z. Their residual degrees are at most h-1. Hence d_i<=2h-1 and D_i=d_i+1<=2h. Thus every source selecting a label in I has sigma_u<=2h by (2.3).

All h+1 sources in Z must select some label of I: at most h sources would supply at most 2h² incidences, less than h(2h+1). Let k be the number of labels in I with x_i=h+1. The outgoing degree of Z is at least h(2h+1)+k, while the sum of its total pair degrees is at most 2h(h+1). Its total incoming degree is consequently at most h-k. In particular k<=h.

An exceptional label with d_i=2h must have x_i=h, and every one of its at least h selected incidences has its supplement in Z, because outside residual degrees are below h. Thus there is at most one exceptional label when k=0, and none when k>=1.

Call a label ordinary when x_i=h and d_i<=2h-1. There are at least 2h ordinary labels if k=0, and exactly 2h+1-k ordinary labels if k>=1. Each source selecting an ordinary label has sigma_u<=2h-1. Let z be the number of such sources. The total pair-degree budget of Z is now at most 2h(h+1)-z. Comparing with its mandatory outgoing degree gives z<=h-k.

If k=0, ordinary labels require at least 2h² incidences, but the sources supplying them offer at most h(2h-1)<2h². If 1<=k<=h, the demand minus the greatest possible supply is

\[
h(2h+1-k)-(h-k)(2h-1)=2h+(h-1)k>0.
\]

Every case is impossible. □

The file `ONE_SPARE_STRONG_CERTIFICATES.json` identifies 19 applications within the original 388 rows. They overlap the complete numerical certificate partition and contribute **zero additional rows** to its count. `src/one_spare_strong.py` checks their premises and the integer case arithmetic. It is not a formal proof assistant.

### 7.2 A short order-28 example: 21 > 20

One v6 survivor has

\[
s=(0,1,1,1,1,3,3,3,3,3,3,3),\qquad \rho=(1^{11},3^4),\quad a=12,b=15,r=23,t=1.
\]

Let Z be the four residual-3 sources and I the seven demand-3 labels. At least 21 selected incidences from Z are mandatory. Every label in I has actual B-degree D_i<=6: if x_i=3 use d_i<=6; if x_i=4, all four sources select i, so supplements lie among the residual-1 vertices and d_i<=4, whence D_i<=5.

All four sources must participate in I, and each then has sigma<=6. Their total incoming degree is at most 24-21=3. A label in I with d_i>=5 requires at least three incoming incidences to Z, since no residual-1 supplement meets d_i<=3+rho_w. At most one such label exists. At least six labels of I therefore have D_i<=5, including any fully selected label.

Those six labels require at least 18 incidences. Three sources of total pair-degree at most five could supply only 15, so all four sources must select one of those labels. Every source in Z now has sigma<=5. Their total outgoing capacity is at most 20, contradicting the required 21.

This excludes every compatible individual-column assignment, not just the particular columns eventually considered by the numerical model.

## 8. An explicit infinite family above the target

For every integer h>=4 set

\[
\begin{split}
a&=h^2+h-6,& b&=a+3,& n&=2a+4=2h^2+2h-8,\\
m&=(a+2)^2+1=\lfloor n^2/4\rfloor+1,& t&=2,& r&=2h^2+h-4.
\end{split}
\]

Specify the demand and residual sequences

\[
\rho=(h^{h+1},1^{h^2-4}),\qquad
s=(0,h^{2h+1},0^{a-2h-2}).\tag{8.1}
\]

Theorem 7.1 excludes every selected system with these sequences: there are h+1 maximum-residual sources and 2h+1 labels of demand h. This is an infinite family of **profiles**, not a resolution of every graph at these orders. The first member is (n,Delta,m)=(32,17,257).

For clarity, the basic ledger and separate graphicality tests are not the obstruction. Compatible individual columns are

\[
d=(2h-3,(2h-1)^{2h+1},0^{a-2h-2}),\qquad
R=(2h-3,(h-1)^{2h+1},0^{a-2h-2}).\tag{8.2}
\]

They satisfy the exact demands, sum R=sum rho=r and sum d=2(r+2). The necessary lengths are nonnegative because h>=4.

An explicit graph F realising d is obtained on labels 0,...,2h+1 by deleting from the complete graph the edges of the two cycles `(0,1,2)` and `(0,3,4,...,2h+1)`, which share only vertex 0. Isolate all remaining labels. Label 0 has degree 2h-3 and every other active label has degree 2h-1.

An explicit bipartite residual graph realising (rho,R) is obtained as follows. For high source u=0,...,h and j=0,...,h-1, place a residual edge at heavy label `1+(uh+j) mod (2h+1)`. Within each source these labels are distinct. Each heavy label receives at most ceil(h(h+1)/(2h+1))<=h-1 such edges. Assign 2h-3 different low sources to label 0, then use the remaining low sources, once each, to fill every heavy label's residual deficit to h-1. The counts agree because the remaining capacity equals the number of unused residual-1 sources.

These are separate realisations of two degree conditions, not a construction of a critical graph or a proof of simultaneous compatibility. The one-spare-source obstruction rules out the required selected incidences. We do not assert that this family passes every earlier project inequality or that the family was previously unknown in the literature.

`src/one_spare.py` retains a slightly weaker sufficient lemma with outside residual degrees at most h-2 and an explicit one-unit final capacity gap. It also checks (8.1)–(8.2) arithmetically through h=10000 and constructs the separate graphs through h=100. The symbolic argument above, not this finite regression, proves the all-h assertion.

## 9. Complete exact finite certificates and coverage

| Stage | Complete input | Exact exclusions | Retained rows |
|---|---:|---:|---:|
| Local incidence, Section 4 | 388 | 22 | 366 |
| Conditional ledgers, Section 5 | 366 | 19 | 347 |
| Endpoint degrees, Section 6 | 347 | 347 | 0 |

The discovery programs use numerical linear optimisation only to propose a certificate. Each published certificate is an integer combination of integer constraints. In the convention A_j v<=b_j, E_k v=f_k and v>=0, the checker verifies nonnegative integer inequality multipliers alpha_j and unrestricted integer equality multipliers beta_k. Their combined left-side coefficients must all be nonnegative and their combined right side strictly negative:

\[
\sum_j\alpha_jA_j+\sum_k\beta_kE_k\ge0\quad\text{coordinatewise},\qquad
\sum_j\alpha_jb_j+\sum_k\beta_kf_k<0.\tag{9.1}
\]

This gives 0<=a nonnegative expression<0. Numerical infeasibility without such a certificate would remain unresolved. No such unresolved solver status occurred in the completed three scans.

The separate checker imports neither a discovery model nor NumPy, SciPy, or an optimisation solver. It reconstructs all constraints using named integer expressions. Each canonical row is identified by the SHA-256 of its name/coefficient/right-side representation. Unknown rows, duplicate multipliers, negative inequality weights and a forged final sum are rejected. The naming/partition helper and frozen input are shared with discovery; this is separate constraint construction, not a claim of wholly unrelated software or independent authorship.

At each stage the checker requires that the rejected and retained positions be unique, disjoint and exactly exhaust that stage's input. It verifies original row identifiers and the pinned input bytes. The final survivor file is the empty list. The new standalone exact pass completed all 388 certificate checks in about 58 seconds in the recorded environment; this is a measured local run, not a hardware-independent performance promise.

The small pilots overlap the complete production runs. The lean-model pilot reports ten numerical infeasibilities for an even smaller model without exported certificates; it contributes no theorem or exclusion and is preserved as exploration only. Source-indexing performance changes to the endpoint builder did not change the mathematical model; a pilot-era source is preserved separately. The complete production run compared both builders' full constraint sets for every rejection.

## 10. Order 28: equality branch versus upper bound

**Candidate equality-only corollary.** Subject to the inherited project lemmas and upstream coverage, a diameter-two edge-critical graph on 28 vertices with exactly 196 edges is K14,14.

Here is the entire degree split, so that the incremental computation is not mistaken for a new unrestricted graph enumeration.

* Maximum degree at most 13 gives at most 28*13/2=182 edges.
* Maximum degree 14 at 196 edges forces every degree to equal 14. No nonadjacent pair can have exactly one common neighbour: both neighbourhoods have size 14 and are contained in the other 26 vertices, forcing intersection size at least two. Every critical edge must therefore have endpoints with no common neighbour, since the other possible witness is the unique two-edge path between a nonadjacent pair. Thus G is triangle-free. For any edge uv, N(u) and N(v) are disjoint independent 14-sets covering the graph; regularity forces all cross-edges, giving K14,14. This is a direct witness argument, not an imported assertion about deleting redundant edges.
* Maximum degree 15 is excluded by the upstream v3–v6 necessary-domain route followed by the complete 388-row v7 check.
* Maximum degree 16 is the inherited demand-support-v3 exclusion at all m>=196 [4]. This session did not rerun it.
* Degrees 17 through 26 are excluded by the inherited finite charging inequality [3]

\[
b+2t\le aM_a,\qquad
M_a=\max_{s\in\{0,\ldots,a-1\}}\frac{s(a+1-2s)}{a-s}.
\]

At m=196 their exact right sides aM_a are, respectively, 150/7, 18, 72/5, 56/5, 9, 20/3, 4, 3, 2 and 0. The corresponding left sides b+2t are 35, 50, 69, 92, 119, 150, 185, 224, 267 and 314. The a=1 endpoint uses its separate zero-demand observation. Every inequality is strictly violated. Larger m increases only the left side for fixed n,b.
* A universal vertex, degree 27, forces G to be a star: an edge among other vertices would be redundant. Such a graph has 27 edges.

The bound and its equality characterization are different obligations. Fan's strict estimate, reported on page 2 of Tao Wang's primary manuscript [2], is

\[
m<\frac{n^2}{4}+\frac{n^2-(81/5)n+56}{320}\qquad(n\ge25).
\]

For n=28 this is

\[
m<\frac{78883}{400}=197.2075,
\]

so m<=197. The same inherited high-degree exclusions and the degree sum for Delta<=14 leave exactly

\[
\boxed{n=28,\quad \Delta=15,\quad m=197}
\]

as the unfinished upper-bound case. For this case t=2, not t=1. Its demand/slack and individual-column domains must be regenerated or covered by a new proved implication. The v7 certificates concern the 196-edge input only and are not automatically valid at 197 edges. Removing an edge from a critical graph does not justify such a reduction. Fan's original full proof was not re-audited here.

Accordingly, **order 28 remains OPEN as a full conjecture case**. No claim about a complete order above 27, every order through 1000, or the global conjecture is made. The candidate uniform coefficient (10-sqrt(2))/14 remains unchanged.

## 11. Falsification tests, checking independence and limitations

Three new exact graph-to-model lift tests recheck the saved 916 selected systems from 639 distinct labelled critical graphs. They recalculate the graph/complement, root, quasi-edge selections, residual degrees and ledger, then lift the systems into the respective new constraints. Column domains are broadened by demand class to exercise genuinely fractional symmetry averages. The three models perform 115632, 123214 and 219158 exact constraint evaluations, respectively; these are repeated evaluations on the same sample, not distinct graphs or independent trials.

The source-relative residual injection is also checked at all 3532 B-vertex occurrences: 51 have a positive selected-internal F-edge count and 232 a positive missing-internal F-edge count. No failure occurs. The strong one-spare-source test has 71 actual maximum-residual classes meeting its source-cardinality premise, with no violation. The sample contains **no positive-surplus actual graph**. These tests therefore do not empirically establish the universal dense-case contradiction, and they are not searches over all hypothetical order-28 graphs.

The exact-certificate checker rejects seven deliberate corruptions: zero dual weights, an unknown constraint, forged final sum, negative inequality weight, duplicate multiplier, an omitted disposition and a duplicated disposition. The two hand-lemma premise checkers each reject three altered source/label/threshold certificates. These are finite negative controls, not a formal proof of checker correctness.

All programs and arguments were written by the same assistant under Paul Lenz's direction. Separate implementations are internal software cross-checks, not independent researcher reproduction, journal acceptance, or formal verification. The strongest review targets are the residual injections, the exact marginal normalizations, omitted endpoint types, and the inherited necessity of the upstream domains.

## 12. Sources and provenance

[1] T. W. Haynes, M. A. Henning, L. C. van der Merwe and A. Yeo, *A maximum degree theorem for diameter-2-critical graphs* (2014), Theorems 3.1–3.2 and the quasi-edge correspondence. Primary text: https://d-nb.info/1372516379/34 . Published input, not re-proved by this checkpoint.

[2] Tao Wang, *On Murty-Simon Conjecture*, arXiv:1205.4397, especially page 2 for Fan's estimate and the complement correspondence, and page 3 for the 4-supercritical exception. https://arxiv.org/pdf/1205.4397 . The estimate was read in the text and checked on the rendered page in this continuation. Fan's original full proof remains an external dependency.

[3] Project coupled-resource-v2, `project/research/general_n/2026-09-07-coupled-resource-v2/PROOF.md`, Git blob `3d3b4ab5b2da8207f17a3a2afcce49e7119d78e2`, read at commit `00ad1a511971397fcd8a4341b021493c2383252e`. Source of the general and finite charging inequalities and activity argument.

[4] Project demand-support-v3, dated directory under `project/research/general_n/`, originally published at commit `85e04173d5a2b29641bad1a71867cdf7fa15cfd6`. Source of the fixed-degree n28/Delta16 exclusion and upstream demand screen.

[5] Project pair-budgets-v2 and label-tail-v4. Source of the total source pair-degree inequality (2.3), retained residual framework, and v4 numerical expansion. These checkpoints are not separate independent confirmations of every inherited lemma.

[6] Project column-propagation-v5, original ZIP SHA-256 `79bdbdf02b23b9eef38e964b54eb300921b24d539014f07b476655d1575e63b6`; publication commit `d346ec6d01c49de9a082866ceda6a65efe180b05`, verified receipt commit `00ad1a511971397fcd8a4341b021493c2383252e`. Source of individual column domains, source caps, forced labels, and the one-source missing-neighbour bound.

[7] Project shared-adjacency-v6, original ZIP and hash in Section 1, complete proof and 6530 exact exclusions leaving the pinned 388 rows. Three unchanged model/checker library files, the actual-graph unpack helper, and the exact numerical/graph inputs are included in `dependencies/`, with their provenance in `SOURCES.json`. The new check is incremental on this frozen frontier.

The previous frozen theorem editions and governed ledger are not altered. “New” denotes development in this project session, not a verified novelty or priority determination.
