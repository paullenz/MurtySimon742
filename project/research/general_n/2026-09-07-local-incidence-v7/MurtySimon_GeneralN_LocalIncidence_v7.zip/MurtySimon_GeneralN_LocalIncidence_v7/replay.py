#!/usr/bin/env python3
"""Verify the v7 package, or replay its exact checks in a fresh working copy.

Default/--verify-only verifies every manifested file and exact file-list coverage;
  it does not run the numerical certificates.
--check --output NEW runs all new exact certificates and mathematical regressions;
  it does not call an optimisation solver, rerun the older v6 full computation,
  or test the 197-edge case.
--rediscover --output NEW additionally reruns the three discovery scans, requiring
  NumPy/SciPy, then checks their newly generated certificates exactly.
No preserved source/evidence file is overwritten by --check or --rediscover.
"""
from __future__ import annotations
import argparse
import hashlib
import gzip
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
IGNORED_DIRS = {'__pycache__','.git'}

def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)

def files_at(root: Path) -> dict[str, Path]:
    return {p.relative_to(root).as_posix():p for p in root.rglob('*')
            if p.is_file() and not any(part in IGNORED_DIRS for part in p.relative_to(root).parts)
            and p.suffix != '.pyc' and p.relative_to(root).as_posix() != 'MANIFEST.json'}

def verify(root: Path) -> dict:
    data = json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
    expected = data['files']; actual = files_at(root)
    require(set(actual)==set(expected),'Unexpected or missing manifested files')
    for name,meta in expected.items():
        raw=actual[name].read_bytes()
        require(len(raw)==meta['bytes'],'File length mismatch: '+name)
        require(hashlib.sha256(raw).hexdigest()==meta['sha256'],'File hash mismatch: '+name)
    return {'all_pass':True,'payload_files_verified':len(expected),
            'manifest_sha256':hashlib.sha256((root/'MANIFEST.json').read_bytes()).hexdigest()}

def run_script(root: Path, relative: str, log: Path) -> dict:
    # Isolated Python does not put the script directory on sys.path. Add the
    # trusted package's own src explicitly, never an arbitrary current directory.
    code=('import sys,runpy;sys.path.insert(0,sys.argv[1]);'
          'p=sys.argv[2];sys.argv=[p];runpy.run_path(p,run_name="__main__")')
    command=[sys.executable,'-I','-B','-c',code,str(root/'src'),str(root/relative)]
    started=time.monotonic()
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    with log.open('w',encoding='utf-8') as stream:
        proc=subprocess.run(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
    require(proc.returncode==0,f'Check failed: {relative}; inspect {log}')
    return {'script':relative,'exit_code':proc.returncode,'seconds':time.monotonic()-started,
            'log':log.name}

def stable(value):
    if isinstance(value,dict):return {k:stable(v) for k,v in value.items() if k not in ('seconds',)}
    if isinstance(value,list):return [stable(v) for v in value]
    return value

def main() -> None:
    require(__debug__,'Do not disable assertions with -O')
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--verify-only',action='store_true')
    mode.add_argument('--check',action='store_true')
    mode.add_argument('--rediscover',action='store_true')
    parser.add_argument('--output',type=Path,help='New directory, outside the preserved package')
    args=parser.parse_args()
    initial=verify(ROOT)
    if not (args.check or args.rediscover):
        require(args.output is None,'--output requires --check or --rediscover')
        print(json.dumps(initial,indent=2));return
    require(args.output is not None,'Specify --output NEW_DIRECTORY')
    output=args.output.resolve()
    require(not output.exists(),'Output directory must not already exist')
    require(output!=ROOT and ROOT not in output.parents,'Output must be outside the preserved package')
    output.mkdir(parents=True)
    work=output/'working_copy'
    shutil.copytree(ROOT,work,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
    verify(work)
    reports=[]
    scripts=[]
    if args.rediscover:
        scripts.extend(['src/run_local.py','src/run_ledger.py','src/run_total.py'])
    scripts.extend(['src/check.py','src/test_local.py','src/test_ledger_lift.py',
                    'src/test_total_lift.py','src/one_spare.py',
                    'src/one_spare_strong.py','src/check_scope.py'])
    started=time.monotonic()
    for k,script in enumerate(scripts):
        print('Running',script,flush=True)
        reports.append(run_script(work,script,output/f'{k+1:02d}_{Path(script).stem}.log'))
    comparisons=[]
    for name in ['EXACT_CHECK_REPORT.json','ACTUAL_LOCAL_LIFT_REPORT.json',
                 'ACTUAL_LEDGER_LIFT_REPORT.json','ACTUAL_TOTAL_LIFT_REPORT.json',
                 'ONE_SPARE_REPORT.json','ONE_SPARE_STRONG_REPORT.json','SCOPE_CHECK_REPORT.json']:
        saved=json.loads((ROOT/'evidence'/name).read_text())
        fresh=json.loads((work/'evidence'/name).read_text())
        require(stable(saved)==stable(fresh),'Fresh result differs from saved report: '+name)
        comparisons.append(name)
    original_survivors=(ROOT/'evidence/FINAL_SURVIVORS.json.gz').read_bytes()
    fresh_survivors=(work/'evidence/FINAL_SURVIVORS.json.gz').read_bytes()
    require(gzip.decompress(original_survivors)==gzip.decompress(fresh_survivors),
            'Final survivor content differs')
    final=verify(ROOT)
    require(initial==final,'Preserved package changed during replay')
    result={'all_pass':True,'mode':'rediscover_and_check' if args.rediscover else 'check',
            'input_integrity':initial,'scripts':reports,'stable_reports_match':comparisons,
            'only_timing_fields_ignored_in_report_comparisons':True,
            'preserved_source_package_unchanged':True,'final_survivor_content_identical':True,
            'final_survivor_compressed_bytes_identical':original_survivors==fresh_survivors,
            'new_exact_exclusions':388,'final_survivors':0,
            'scope':{'n':28,'Delta':15,'m':196},'m197_covered':False,
            'upstream_full_arithmetic_replayed':False,
            'optimisation_solver_used':bool(args.rediscover),
            'independent_external_review':False,'seconds':time.monotonic()-started}
    (output/'FULL_REPLAY_REPORT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
