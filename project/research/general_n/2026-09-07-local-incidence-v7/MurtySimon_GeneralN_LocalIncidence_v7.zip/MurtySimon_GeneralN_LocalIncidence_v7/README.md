# Local incidence and endpoint-degree consistency — v7

**Candidate mathematics; new exact arithmetic REPRODUCED; independent mathematical review OPEN.**

The complete v6 frontier at **n=28, maximum degree 15, m=196** is now excluded: **388 input rows, 388 exact rejection certificates, zero survivors**. This closes that fixed-edge-count branch, conditional on the inherited graph-theoretic and upstream coverage arguments. It does **not** settle order 28: the remaining upper-bound case is **maximum degree 15 at 197 edges**.

Start with [PROOF.md](PROOF.md), [RESULTS.json](RESULTS.json), and [REVIEW_AND_HANDOFF.md](REVIEW_AND_HANDOFF.md). The final survivor file is the empty list in `evidence/FINAL_SURVIVORS.json.gz`. Original input positions and certificates are preserved, not replaced by solver statuses.

## New results

| Necessary-condition test | Input rows | Exactly excluded | Retained |
|---|---:|---:|---:|
| Source-local F-adjacency and residual injection | 388 | 22 | 366 |
| Fixed ledgers conditioned on actual source degree | 366 | 19 | 347 |
| Actual label degree coupled to incoming-plus-outgoing source degree | 347 | 347 | **0** |

The final model is the v6 typed model plus conditional ledgers and endpoint-degree consistency, without the larger local pair-variable extension. These are separately necessary models, not an assertion of nested constraints or a complete integral graph-realisation search. Every counted exclusion is verified with exact integer arithmetic. No new branching proof trees are required in v7.

A new general hand lemma shows that if exactly h+1 sources attain the maximum residual degree h, then at most 2h labels can demand h selections. It applies to 19 of the original rows; those applications overlap the main count. One row has the short contradiction **21 required > 20 available**. A specified infinite family at one edge above the conjectured bound starts with **(n,Delta,m)=(32,17,257)**. These are profile exclusions, not completed orders. The uniform coefficient `(10-sqrt(2))/14` is unchanged.

## Integrity and replay

Python 3.10 or later and its standard library suffice for integrity verification and the complete new checking route. No optimisation solver, C++ compiler or network is required. Keep assertions enabled; never run with `-O`.

```sh
python3 -I -B replay.py --verify-only
python3 -I -B replay.py --check --output /absolute/path/to/new-v7-check
```

The first command checks every manifested file and exact file-list coverage; it does not run numerical certificates. The second copies the package into a NEW directory, reconstructs all three necessary models, checks all 388 certificates and complete/disjoint phase coverage, reruns the actual-graph lifts and hand-lemma controls, verifies the scope arithmetic, and compares fresh result fields with preserved reports, ignoring only run times. The original directory and its historical evidence are left unchanged.

To repeat discovery as well as verification, install the NumPy and SciPy versions recorded in [ENVIRONMENT.json](ENVIRONMENT.json), then run:

```sh
python3 -I -B replay.py --rediscover --output /absolute/path/to/new-v7-discovery
```

Discovery may be slower or propose different dual weights on another software/platform combination. Only a separately checked exact certificate is accepted. The stable result/coverage reports, rather than identical newly discovered dual coefficients, are compared. The saved production discovery runs completed all stages and compared both builders' complete variable and constraint sets for each rejection.

`dependencies/` contains unchanged copies of the required v6 library files and exact numerical/graph inputs. Their original standalone mains may refer to the v6 directory layout; use the v7 wrapper above, not those old entry points. The wrapper handles isolated Python's import path explicitly.

## Scope and trust boundaries

The new exact checker is incremental on v6's final 388 rows. This session verified all 88 payload hashes of the source v6 ZIP and checked the expanded states against v5 data pinned inside v6, but did not rerun the entire earlier v3–v6 search or n25/n27 proofs. Upstream necessity, coverage, and published inputs remain dependencies.

Combining the stated degree cases yields the candidate equality-only conclusion: a diameter-two-critical graph on 28 vertices **with exactly 196 edges** is K14,14. Fan's strict bound, as reported in Wang's primary manuscript, gives fewer than 197.2075 edges at n=28, hence at most 197. The inherited reductions leave precisely **(28,15,197)** open. No monotonicity of the new exact-column domains or deletion-preserves-criticality argument is assumed.

The three graph lifts recheck 916 selected systems on 639 distinct labelled critical graphs and include genuinely fractional symmetry averages. The sample has **no positive-surplus graph**. Agreement of the programs and those finite tests does not prove the universal graph-theoretic premises. Both implementations were written by the same assistant, not independent external reviewers. There is no formal-kernel verification or novelty determination.

## Preservation

All code, inputs, exact certificates, original search logs, intermediate survivors, pilot limitations, test results and replay instructions are included. No frozen n25/n27 edition, earlier checkpoint or governed theorem-ledger entry is modified. [PUBLICATION_STATUS.json](PUBLICATION_STATUS.json) records what was actually preserved locally and the last verified GitHub baseline; it does not claim a remote v7 commit. The uncommitted old v5 multipart fragments are not dependencies.
