"""Discovery: couple actual column selected degree x to source total pair degree q+p."""
from conditional_ledger import build_ledger
from check_constraints import partition
from common_lp import plus


def extend_total(m,s,rho,state,t=1):
    a=len(s);b=len(rho);L,B=partition(s,rho,state);idx={n:i for i,n in enumerate(m.names)}
    V={};W={};Z={}
    for g,I in enumerate(L):
        forced=state['forced'][I[0]].bit_count()
        for o,(d,R,z) in enumerate(state['domains'][I[0]]):
            expr={idx['y',g,o]:-1}
            for x in range(max(s[I[0]],forced),b-R+1):
                V[g,o,x]=m.var(('column_x',g,o,x));expr[V[g,o,x]]=1
            m.equal(expr,0)
    for name,j in idx.items():
        if name[0]!='degree_type':continue
        _,k,q=name;P=min(rho[B[k][0]]+b-a-1,b-1-q);expr={j:-1}
        for p in range(P+1):
            W[k,q,p]=m.var(('source_qp',k,q,p));expr[W[k,q,p]]=1
        m.equal(expr,0)
        inc={}
        for (kk,qq,p),v in W.items():
            if (kk,qq)==(k,q):inc[v]=-p
        for pair,v in idx.items():
            if pair[0]=='pair_type' and pair[2]==k and pair[4]==q:
                inc[v]=len(B[pair[1]])-(pair[1]==k)
        m.equal(inc,0)
    for name,j in idx.items():
        if name[0]!='typed_sel':continue
        _,k,g,o,q=name;R=state['domains'][L[g][0]][o][1];expr={j:-1}
        for kk,qq,p in W:
            if (kk,qq)!=(k,q):continue
            for gg,oo,x in V:
                if (gg,oo)!=(g,o) or x<1 or R+x<q+p:continue
                key=(k,g,o,q,p,x);Z[key]=m.var(('selected_qpx',)+key);expr[Z[key]]=1
        m.equal(expr,0)
    # one selected incidence per actual source-label pair, after fixing one endpoint type
    for (k,q,p),w in W.items():
        count={w:-q}
        for g,I in enumerate(L):
            cap={w:-1}
            for (kk,gg,o,qq,pp,x),v in Z.items():
                if (kk,gg,qq,pp)==(k,g,q,p):cap[v]=1;count[v]=len(I)
            m.le(cap,0)
        m.equal(count,0)
    for (g,o,x),v in V.items():
        total={v:-x}
        for k,U in enumerate(B):
            cap={v:-1}
            for (kk,gg,oo,q,p,xx),z in Z.items():
                if (kk,gg,oo,xx)==(k,g,o,x):cap[z]=1;total[z]=len(U)
            m.le(cap,0)
        m.equal(total,0)
    m.bound_start=len(m.ub)
    for j in range(len(m.names)):m.le({j:1},1)
    return m

def build_total(s,rho,state,t=1,local=False):
    return extend_total(build_ledger(s,rho,state,t,local=local),s,rho,state,t)

if __name__=='__main__':
    from pathlib import Path
    import time,gzip,json,sys
    from common_lp import certificate,verify
    from check_constraints import translate
    root=Path(__file__).resolve().parents[1];rows=json.loads(gzip.decompress((root/'dependencies/v6_FINAL_SURVIVORS.json.gz').read_bytes()));out=[]
    for rec in rows[:int(sys.argv[1]) if len(sys.argv)>1 else 10]:
        t0=time.time();m=build_total(rec['s'],rec['row'][2:],rec['state']);res=m.solve();cert=None
        if res.status==2:
            c=certificate(m)
            if c:verify(m,c);cert=translate(m,c)
        row={'position':rec['position'],'index':rec['index'],'status':int(res.status),'certificate':cert,'variables':len(m.names),'seconds':time.time()-t0};out.append(row)
        print(rec['position'],res.status,cert is not None,len(m.names),round(time.time()-t0,2),flush=True)
    (root/'evidence/TOTAL_DEGREE_PILOT.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
