#!/usr/bin/env python3
"""Common columns coupled to integral source-degree types, then degree-type pair flow.
This remains a fractional relaxation; every rejection needs an exact dual.
"""
from common_lp import build,plus
from check_constraints import partition

def extend(m,s,rho,st,pairflow=True):
    a=len(s);b=len(rho);L,B=partition(s,rho,st);idx={v:j for j,v in enumerate(m.names)}
    w={};xs={};xr={};xn={};ranges={}
    for k,grp in enumerate(B):
        u=grp[0];f=sum(bool(mask>>u&1) for mask in st['forced']);ranges[k]=list(range(f,st['c'][u]+1))
        for q in ranges[k]:w[k,q]=m.var(('degree_type',k,q))
        m.equal({w[k,q]:1 for q in ranges[k]},1)
        for g,ls in enumerate(L):
            i=ls[0];force=bool(st['forced'][i]>>u&1)
            for q in ranges[k]:
                e={w[k,q]:-1}
                for o,(dd,rr,zz) in enumerate(st['domains'][i]):
                    supp=any(v!=u and not(st['forced'][i]>>v&1) and dd<=rho[u]+rho[v] and rho[v]+st['c'][v]>=q-1 for v in range(b))
                    sel=q>0 and s[i]<=rho[u] and dd<=rho[u]+q-1 and supp and rr+max(1,s[i])<=b
                    red=not force and rr>=1
                    mis=not force and dd<=a-q-1 and rr+s[i]<=b-1
                    for allow,kind,vars in [(sel,'typed_sel',xs),(red,'typed_res',xr),(mis,'typed_miss',xn)]:
                        if allow:
                            v=m.var((kind,k,g,o,q));vars[k,g,o,q]=v;e[v]=1
                m.equal(e,0)
            for o,op in enumerate(st['domains'][i]):
                e={idx['y',g,o]:-1}
                for vars in [xs,xr,xn]:
                    for q in ranges[k]:
                        if (k,g,o,q) in vars:e[vars[k,g,o,q]]=1
                m.equal(e,0)
                for kind,vars in [('sel',xs),('res',xr)]:
                    e={}
                    if (kind,k,g,o) in idx:e[idx[kind,k,g,o]]=-1
                    for q in ranges[k]:
                        if (k,g,o,q) in vars:e[vars[k,g,o,q]]=1
                    m.equal(e,0)
        for q in ranges[k]:
            for vars,total in [(xs,q),(xr,rho[u])]:
                e={w[k,q]:-total}
                for g,ls in enumerate(L):
                    for o in range(len(st['domains'][ls[0]])):
                        if (k,g,o,q) in vars:e[vars[k,g,o,q]]=len(ls)
                m.equal(e,0)
    if pairflow:
        pair={}
        for k,us in enumerate(B):
            for l,vs in enumerate(B):
                if k==l and len(us)<2:continue
                for q in ranges[k]:
                    if q==0:continue
                    for v in ranges[l]:
                        if v+rho[vs[0]]>=q-1:pair[k,l,q,v]=m.var(('pair_type',k,l,q,v))
        for k,us in enumerate(B):
            for l,vs in enumerate(B):
                if k==l and len(us)<2:continue
                e={pair[key]:1 for key in pair if key[:2]==(k,l)}
                for g,ls in enumerate(L):
                    if ('arc',k,l,g) in idx:e[idx['arc',k,l,g]]=-len(ls)
                m.equal(e,0)
            for q in ranges[k]:
                e={w[k,q]:-q}
                for (kk,l,qq,v),j in pair.items():
                    if k==kk and qq==q:e[j]=len(B[l])-(k==l)
                m.equal(e,0)
                e={w[k,q]:-(rho[us[0]]+b-a-1)}
                for (l,kk,v,qq),j in pair.items():
                    if k==kk and qq==q:e[j]=len(B[l])-(k==l)
                m.le(e,0)
    m.bound_start=len(m.ub)
    for j in range(len(m.names)):m.le({j:1},1)
    return m

def build_types(s,rho,st,t=1):return extend(build(s,rho,st,t),s,rho,st)

if __name__=='__main__':
    import json,sys,time
    from pathlib import Path
    import gzip
    from collections import Counter
    from common_lp import certificate,verify
    root=Path(__file__).resolve().parents[1];p=Path(__file__).resolve().parents[1]
    data=json.loads(gzip.decompress((p/'dependencies/v5_FINAL_SURVIVORS.json.gz').read_bytes()));D=json.loads(gzip.decompress((p/'dependencies/n28_demands.json.gz').read_bytes()));poss=json.loads((root/'evidence/LP_SURVIVOR_POSITIONS.json').read_text())
    limit=int(sys.argv[1]) if len(sys.argv)>1 else 100;offset=int(sys.argv[2]) if len(sys.argv)>2 else 0
    out=[];C=Counter();start=time.time()
    stream=(root/'evidence'/f'types_{offset}_{limit}.jsonl').open('w')
    for pos in poss[offset:offset+limit]:
        rec=data[pos];s=D[rec['row'][0]]['s'];m=build_types(s,rec['row'][2:],rec['state']);res=m.solve();obj={'position':pos,'index':rec['index'],'status':res.status,'vars':len(m.names)}
        if res.status==2:
            cert=certificate(m)
            if cert:verify(m,cert);obj['certificate']=cert;obj['outcome']='exact_rejection'
            else:obj['outcome']='unresolved_uncertified_numeric'
        else:obj['outcome']='unresolved'
        C[obj['outcome']]+=1;out.append(obj);stream.write(json.dumps(obj,separators=(',',':'))+'\n');stream.flush()
        if len(out)%50==0:print(len(out),dict(C),round(time.time()-start,2),'vars',len(m.names),flush=True)
    (root/'evidence'/f'types_{offset}_{len(out)}.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
    stream.close()
    report={'offset':offset,'rows':len(out),'counts':dict(C),'seconds':time.time()-start}
    (root/'evidence'/f'TYPE_REPORT_{offset}.json').write_text(json.dumps(report,indent=2)+'\n')
    print('DONE',dict(C),time.time()-start)
