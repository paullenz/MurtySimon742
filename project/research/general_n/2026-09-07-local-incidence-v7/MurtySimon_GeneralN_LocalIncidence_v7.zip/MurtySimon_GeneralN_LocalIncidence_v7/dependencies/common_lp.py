"""Shared column and F-adjacency LP discovery. No solver status is a certificate."""
from __future__ import annotations
import gzip
from collections import defaultdict
from fractions import Fraction
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog

class Model:
    def __init__(self):
        self.names=[]; self.eq=[];self.ub=[]
    def var(self,name):
        self.names.append(name);return len(self.names)-1
    def le(self,items,b):self.ub.append((dict((i,v) for i,v in items.items() if v),b))
    def equal(self,items,b):self.eq.append((dict((i,v) for i,v in items.items() if v),b))
    def arrays(self):
        def mat(rows):
            ri=[];ci=[];val=[]
            for k,(terms,rhs) in enumerate(rows):
                for j,v in terms.items():ri.append(k);ci.append(j);val.append(v)
            return coo_matrix((val,(ri,ci)),shape=(len(rows),len(self.names))).tocsr(),np.array([rhs for terms,rhs in rows],dtype=float)
        A,b=mat(self.ub);E,f=mat(self.eq);return A,b,E,f
    def solve(self):
        A,b,E,f=self.arrays();res=linprog(np.zeros(len(self.names)),A_ub=A,b_ub=b,A_eq=E,b_eq=f,bounds=(0,None),method='highs')
        return res

def plus(target,terms,mul=1):
    for j,v in terms.items():target[j]=target.get(j,0)+mul*v
    return target

def build(s,rho,st,t=1,level=4):
    """Symmetrize interchangeable labels and sources, preserving every actual system."""
    a=len(s); b=len(rho);r=sum(rho); dom=st['domains'];caps=st['c'];force=st['forced']
    lg=defaultdict(list)
    for i in range(a):lg[(s[i],tuple(map(tuple,dom[i])),force[i])].append(i)
    labels=[(v[0],len(v)) for v in lg.values()]
    rg=defaultdict(list)
    for u in range(b):rg[(rho[u],caps[u],tuple(int(bool(x&(1<<u))) for x in force))].append(u)
    sources=[(v[0],len(v)) for v in rg.values()]
    m=Model();d=[];R=[];S=[];F={};Y={};Ys={};Yr={}
    for g,(i,ng) in enumerate(labels):
        d.append({});R.append({})
        for o,(dd,rr,zz) in enumerate(dom[i]):
            y=m.var(('y',g,o));Y[g,o]=y;d[g][y]=dd;R[g][y]=rr
        m.equal({Y[g,o]:1 for o in range(len(dom[i]))},1)
    ee={}
    for g,(i,ng) in enumerate(labels):plus(ee,R[g],ng)
    m.equal(ee,r)
    ee={}
    for g,(i,ng) in enumerate(labels):plus(ee,d[g],ng)
    m.equal(ee,2*(r+t))
    for g,(i,ng) in enumerate(labels):
        for h,(j,nh) in enumerate(labels):
            if h<g or (g==h and ng==1):continue
            ff=m.var(('F',g,h));F[g,h]=ff;m.le({ff:1},1)
    for g,(i,ng) in enumerate(labels):
        e={}
        for h,(j,nh) in enumerate(labels):
            if h==g and ng==1:continue
            e[F[min(g,h),max(g,h)]]=nh-int(g==h)
        plus(e,d[g],-1);m.equal(e,0)
    sv={};rv={}
    for k,(u,nu) in enumerate(sources):
        for g,(i,ng) in enumerate(labels):
            sv[k,g]={};rv[k,g]={}
            f_u=sum(bool(x&(1<<u)) for x in force)
            for o,(dd,rr,zz) in enumerate(dom[i]):
                qmin=max(1,f_u,dd-rho[u]+1)
                available=[w for w in range(b) if w!=u and not force[i]&(1<<w) and dd<=rho[u]+rho[w] and rho[w]+caps[w]>=qmin-1]
                sel=(s[i]<=rho[u] and qmin<=caps[u] and bool(available) and rr+max(1,s[i])<=b)
                res=(not force[i]&(1<<u) and rr>=1)
                # Basic missing test uses only forced selected count, a safe lower bound.
                mis=(not force[i]&(1<<u) and dd<=a-f_u-1 and rr+s[i]<=b-1)
                terms={Y[g,o]:-1}
                if sel:
                    v=m.var(('sel',k,g,o));Ys[k,g,o]=v;sv[k,g][v]=1;terms[v]=1
                if res:
                    v=m.var(('res',k,g,o));Yr[k,g,o]=v;rv[k,g][v]=1;terms[v]=1
                if mis:m.le(terms,0)
                else:m.equal(terms,0)
            if force[i]&(1<<u):m.equal(dict(sv[k,g]),1)
        e={}
        for g,(i,ng) in enumerate(labels):plus(e,rv[k,g],ng)
        m.equal(e,rho[u]);e={}
        for g,(i,ng) in enumerate(labels):plus(e,sv[k,g],ng)
        m.le(e,caps[u])
    for g,(i,ng) in enumerate(labels):
        er=dict(R[g]);es={}
        for k,(u,nu) in enumerate(sources):plus(er,rv[k,g],-nu);plus(es,sv[k,g],-nu)
        m.equal(er,0);m.le(es,-s[i])
    if level>=1:
        # For an F-edge ij and a selected ui, uj must be an H-edge.
        for (g,h),ff in F.items():
            for k,(u,nu) in enumerate(sources):
                e={ff:1};plus(e,sv[k,g]);plus(e,sv[k,h],-1);plus(e,rv[k,h],-1);m.le(e,1)
                if g!=h:
                    e={ff:1};plus(e,sv[k,h]);plus(e,sv[k,g],-1);plus(e,rv[k,g],-1);m.le(e,1)
    if level>=2:
        # Necessity of selected/missing degree threshold through big-M.
        for k,(u,nu) in enumerate(sources):
            q={}
            for g,(i,ng) in enumerate(labels):plus(q,sv[k,g],ng)
            for g,(i,ng) in enumerate(labels):
                dmax=max(o[0] for o in dom[i]);M=max(0,dmax-rho[u]+1)
                e=dict(d[g]);plus(e,q,-1);plus(e,sv[k,g],M);m.le(e,rho[u]-1+M)
                # missing means total adjacency zero; d_i+q_u <=a-1 then.
                M=max(0,dmax+caps[u]-(a-1))
                e=dict(d[g]);plus(e,q);plus(e,sv[k,g],-M);plus(e,rv[k,g],-M);m.le(e,a-1)
    totalQ={}
    for k,(u,nu) in enumerate(sources):
        for g,(i,ng) in enumerate(labels):plus(totalQ,sv[k,g],nu*ng)
    m.le(totalQ,r+(b-a-1)*b)
    if level>=3:
        # An F-edge between two selected labels forces residual edges at their supplements.
        V={}
        for k,(u,nu) in enumerate(sources):
            for (g,h),ff in F.items():
                v=m.var(('internalF',k,g,h));V[k,g,h]=v
                e={ff:1,v:-1};plus(e,sv[k,g]);plus(e,sv[k,h]);m.le(e,2)
            for g,(i,ng) in enumerate(labels):
                e={}
                for h,(j,nh) in enumerate(labels):
                    if h==g and ng==1:continue
                    e[V[k,min(g,h),max(g,h)]]=nh-int(g==h)
                plus(e,R[g],-1);m.le(e,0)
    if level>=4:
        arc={}
        for k,(u,nu) in enumerate(sources):
            for l,(w,nw) in enumerate(sources):
                if k==l and nu<2:continue
                for g,(i,ng) in enumerate(labels):
                    dd=min(o[0] for o in dom[i]);fu=sum(bool(x&(1<<u)) for x in force)
                    if (s[i]>rho[u] or dd>rho[u]+rho[w] or
                        (force[i]&(1<<w)) or max(1,fu,dd-rho[u]+1)>caps[u] or
                        rho[w]+caps[w]<max(1,fu,dd-rho[u]+1)-1):continue
                    arc[k,l,g]=m.var(('arc',k,l,g))
        for k,(u,nu) in enumerate(sources):
            for g,(i,ng) in enumerate(labels):
                e={}
                for l,(w,nw) in enumerate(sources):
                    if (k,l,g) in arc:e[arc[k,l,g]]=nw-int(k==l)
                plus(e,sv[k,g],-1);m.equal(e,0)
        inc=[]
        for k,(u,nu) in enumerate(sources):
            e={}
            for l,(w,nw) in enumerate(sources):
                for g,(i,ng) in enumerate(labels):
                    if (l,k,g) in arc:e[arc[l,k,g]]=(nw-int(k==l))*ng
            inc.append(e);m.le(e,rho[u]+b-a-1)
        for k,(u,nu) in enumerate(sources):
            for l,(w,nw) in enumerate(sources):
                if l<k or (k==l and nu<2):continue
                e={}
                for g,(i,ng) in enumerate(labels):
                    for pair in [(k,l,g),(l,k,g)]:
                        if pair in arc:e[arc[pair]]=e.get(arc[pair],0)+ng
                m.le(e,1)
        for (k,l,g),v in arc.items():
            # The exceptional supplement misses its arc's label.
            e={v:1};plus(e,sv[l,g]);plus(e,rv[l,g]);m.le(e,1)
            for h,(j,nh) in enumerate(labels):
                if h==g and nh==1:continue
                # Every other selected label at the source must neighbor this supplement.
                e={v:1};plus(e,sv[k,h]);plus(e,sv[l,h],-1);plus(e,rv[l,h],-1);m.le(e,1)
                # If it is an F-neighbor, the resulting supplement edge is residual.
                ff=F[min(g,h),max(g,h)];e={v:1,ff:1};plus(e,sv[k,h]);plus(e,rv[l,h],-1);m.le(e,2)
        for k,(u,nu) in enumerate(sources):
            q={}
            for g,(i,ng) in enumerate(labels):plus(q,sv[k,g],ng)
            for g,(i,ng) in enumerate(labels):
                e=dict(q);plus(e,inc[k]);plus(e,sv[k,g],b-1)
                # actual D_i=R_i+x_i
                plus(e,R[g],-1)
                for l,(w,nw) in enumerate(sources):plus(e,sv[l,g],-nw)
                m.le(e,b-1)
    m.bound_start=len(m.ub)
    for j in range(len(m.names)):m.le({j:1},1)
    return m


def certificate(m):
    from scipy.sparse import hstack,vstack,csr_matrix
    A,b,E,f=m.arrays();N=len(m.names);n=len(m.ub);k=len(m.eq)
    # Farkas: A^T lambda + E^T mu >=0, lambda >=0, b lambda + f mu <0.
    D=hstack([-A.T,-E.T,E.T],format='csr')
    rhs=np.r_[np.zeros(N),-1.0]
    D=vstack([D,csr_matrix(np.r_[b,f,-f].reshape(1,-1))],format='csr')
    res=linprog(np.ones(n+2*k),A_ub=D,b_ub=rhs,bounds=(0,None),method='highs')
    if not res.success:return None
    for scale in [1000,1000000,1000000000]:
        lam=[max(0,round(float(x)*scale)) for x in res.x[:n]]
        mu=[round(float(x-y)*scale) for x,y in zip(res.x[n:n+k],res.x[n+k:])]
        coef=[0]*N;rhsval=0
        for rows,ww in [(m.ub,lam),(m.eq,mu)]:
            for (row,v),w in zip(rows,ww):
                if w:
                    rhsval+=w*v
                    for j,a in row.items():coef[j]+=w*a
        for j,c in enumerate(coef):
            if c<0:
                lam[m.bound_start+j]-=c;rhsval-=c;coef[j]=0
        if rhsval<0:
            from functools import reduce
            from math import gcd
            factor=reduce(gcd,lam+list(map(abs,mu))) or 1
            return {'ub':[[i,w//factor] for i,w in enumerate(lam) if w],
                    'eq':[[i,w//factor] for i,w in enumerate(mu) if w],
                    'rhs':rhsval//factor,'variables':N,'inequalities':n,'equalities':k}
    return None

def verify(m,c):
    assert c['variables']==len(m.names) and c['inequalities']==len(m.ub) and c['equalities']==len(m.eq)
    coef=[0]*len(m.names);value=0
    for rows,ww,positive in [(m.ub,c['ub'],True),(m.eq,c['eq'],False)]:
        seen=set()
        for i,w in ww:
            assert i not in seen and 0<=i<len(rows) and isinstance(w,int) and (w>=0 or not positive)
            seen.add(i);row,rhs=rows[i];value+=w*rhs
            for j,a in row.items():coef[j]+=w*a
    assert min(coef)>=0 and value==c['rhs'] and value<0
    return value

if __name__=='__main__':
    import sys,json,time,pathlib
    p=pathlib.Path(__file__).resolve().parents[1];data=json.loads(gzip.decompress((p/'dependencies/v5_FINAL_SURVIVORS.json.gz').read_bytes()));D=json.loads(gzip.decompress((p/'dependencies/n28_demands.json.gz').read_bytes()));
    counts=defaultdict(int);start=time.time()
    for i,rec in enumerate(data[:int(sys.argv[1]) if len(sys.argv)>1 else 100]):
        s=D[rec['row'][0]]['s'];rho=rec['row'][2:];m=build(s,rho,rec['state']);res=m.solve();counts[res.status]+=1
        if res.status==2:
            c=certificate(m);assert c is not None;verify(m,c)
        if i%20==0:print(i,dict(counts),'vars',len(m.names),'eq/ub',len(m.eq),len(m.ub),'sec',time.time()-start,flush=True)
    print('DONE',dict(counts),time.time()-start)
