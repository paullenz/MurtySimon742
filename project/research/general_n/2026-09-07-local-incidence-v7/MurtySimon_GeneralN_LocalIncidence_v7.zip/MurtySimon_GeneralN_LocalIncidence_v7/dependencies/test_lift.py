#!/usr/bin/env python3
"""Actual selected-system lifts and union/residual lemma falsification tests.
Standard-library checker; no optimiser called. The sample has no positive surplus.
"""
import json,gzip,random,time
from pathlib import Path
from itertools import combinations
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from check_constraints import rebuild,partition,rebuild_types
import os
TYPED=bool(int(os.environ.get("TEST_TYPED", "0")))
ROOT=Path(__file__).resolve().parents[1]

@lru_cache(None)
def critical(g):
    n=len(g);full=(1<<n)-1
    def d2(h):
        for u in range(n):
            reach=h[u]|(1<<u)
            for w in range(n):
                if h[u]>>w&1:reach|=h[w]
            if reach!=full:return False
        return True
    assert any(x.bit_count()<n-1 for x in g) and d2(g)
    for u,v in combinations(range(n),2):
        if g[u]>>v&1:
            h=list(g);h[u]^=1<<v;h[v]^=1<<u;assert not d2(h)
    return True

def unpack(rec):
    g=rec['g'];critical(tuple(g));n=len(g);full=(1<<n)-1;v=rec['root'];H=[full^g[u]^(1<<u) for u in range(n)]
    assert H[v].bit_count()==min(x.bit_count() for x in H)
    A=[u for u in range(n) if H[v]>>u&1];B=[u for u in range(n) if u!=v and not H[v]>>u&1];a=len(A);b=len(B)
    adj={(u,i) for u in range(b) for i in range(a) if H[B[u]]>>A[i]&1}
    triples=set(map(tuple,rec['triples']));sel={(u,i) for u,i,w in triples};res=adj-sel
    assert len(sel)==len(triples)
    pairs=set()
    for u,i,w in triples:
        assert (u,i) in adj and H[B[u]]|H[A[i]]==full^(1<<B[w])
        key=tuple(sorted((u,w)));assert key not in pairs;pairs.add(key)
    assert pairs=={(u,w) for u,w in combinations(range(b),2) if not H[B[u]]>>B[w]&1}
    F={(i,j) for i,j in combinations(range(a),2) if g[A[i]]>>A[j]&1}
    d=[sum(i in e for e in F) for i in range(a)];R=[sum(j==i for u,j in res) for i in range(a)];rho=[sum(v==u for v,i in res) for u in range(b)];s=[max(0,x-y) for x,y in zip(d,R)];q=[sum(v==u for v,i in sel) for u in range(b)]
    assert rho==rec['rho'] and s==rec['s'] and q==rec['q']
    assert sum(d)==2*(sum(rho)+rec['t'])
    return a,b,d,R,rho,s,q,adj,sel,res,F,triples

def lift(a,b,d,R,rho,s,q,adj,sel,res,F,triples,st):
    L,B=partition(s,rho,st);sys=(rebuild_types if TYPED else rebuild)(s,rho,st,T_CURRENT)
    values={};cols=[(d[i],R[i],R[i]+s[i]-d[i]) for i in range(a)]
    for name in sys.variables:
        typ=name[0]
        if typ=='y':
            _,g,o=name;op=tuple(st['domains'][L[g][0]][o]);values[name]=Fraction(sum(cols[i]==op for i in L[g]),len(L[g]))
        elif typ in ('sel','res'):
            _,k,g,o=name;op=tuple(st['domains'][L[g][0]][o]);edges=sel if typ=='sel' else res
            values[name]=Fraction(sum((u,i) in edges and cols[i]==op for u in B[k] for i in L[g]),len(B[k])*len(L[g]))
        elif typ in ('F','internalF'):
            if typ=='F':_,g,h=name;us=[None]
            else:_,k,g,h=name;us=B[k]
            pairs=list(combinations(L[g],2)) if g==h else [(i,j) for i in L[g] for j in L[h]]
            count=sum(tuple(sorted((i,j))) in F and (u is None or ((u,i) in sel and (u,j) in sel)) for u in us for i,j in pairs)
            values[name]=Fraction(count,len(us)*len(pairs))
        elif typ=='arc':
            _,k,l,g=name;den=len(B[k])*(len(B[l])-(k==l))*len(L[g])
            values[name]=Fraction(sum(u in B[k] and w in B[l] and i in L[g] for u,i,w in triples),den)
        elif typ=='degree_type':
            _,k,qq=name;values[name]=Fraction(sum(q[u]==qq for u in B[k]),len(B[k]))
        elif typ in ('typed_sel','typed_res','typed_miss'):
            _,k,g,o,qq=name;op=tuple(st['domains'][L[g][0]][o])
            def event(u,i):
                return (u,i) in sel if typ=='typed_sel' else ((u,i) in res if typ=='typed_res' else (u,i) not in adj)
            values[name]=Fraction(sum(q[u]==qq and cols[i]==op and event(u,i) for u in B[k] for i in L[g]),len(B[k])*len(L[g]))
        elif typ=='pair_type':
            _,k,l,qq,vv=name;den=len(B[k])*(len(B[l])-(k==l))
            values[name]=Fraction(sum(u in B[k] and w in B[l] and q[u]==qq and q[w]==vv for u,i,w in triples),den)
        else:raise ValueError(name)
    checks=0
    for eq,rows in [(True,sys.equalities),(False,sys.inequalities)]:
        for key,(expr,rhs) in rows.items():
            val=sum(Fraction(c)*values[name] for name,c in expr.items());checks+=1
            if (val!=rhs if eq else val>rhs):raise ValueError(('lost_graph',key,expr,rhs,val,st))
    return checks,sum(v.denominator>1 for v in values.values())

def main():
    global T_CURRENT
    rng=random.Random(2026090706);data=json.loads(gzip.decompress((ROOT/'dependencies/actual_graph_instances.json.gz').read_bytes()));counts=Counter();saved=[];start=time.time()
    for z,rec in enumerate(data):
        a,b,d,R,rho,s,q,adj,sel,res,F,triples=unpack(rec);T_CURRENT=rec['t']
        for j in range(a):
            missed=[u for u in range(b) if (u,j) not in adj];union={i for u,i in sel if u in missed}
            assert j not in union and d[j]<=a-1-len(union);counts['union_checks']+=1
            counts['nonempty_union_checks']+=bool(union)
            single=max([0]+[q[u] for u in missed]);counts['union_strictly_larger_than_each_source']+=len(union)>single
        for u in range(b):
            for i in range(a):
                if (u,i) in sel:
                    inside=[j for j in range(a) if (u,j) in sel and tuple(sorted((i,j))) in F]
                    assert len(inside)<=R[i];counts['selected_internal_F_checks']+=1;counts['nonzero_selected_internal_F_checks']+=bool(inside)
        force=[sum(1<<u for u in range(b) if rho[u]>=si) if si>0 and sum(rr>=si for rr in rho)==si else 0 for si in s]
        for i,f in enumerate(force):assert all((u,i) in sel for u in range(b) if f>>u&1)
        st={'domains':[[[d[i],R[i],R[i]+s[i]-d[i]]] for i in range(a)],'c':[min(a-rr,b-1) for rr in rho],'forced':force}
        tests,frac=lift(a,b,d,R,rho,s,q,adj,sel,res,F,triples,st);counts['singleton_lifts']+=1;counts['exact_model_inequalities']+=tests;counts['fractional_lift_values']+=frac
        # Broaden by demand class; known actual columns are contained; grouping may mix degrees.
        broad=[]
        for i in range(a):
            ops=set((d[j],R[j],R[j]+s[j]-d[j]) for j in range(a) if s[j]==s[i])
            for _ in range(2):
                dd=rng.randrange(a);rr=rng.randrange(b+1)
                if max(0,dd-rr)==s[i]:ops.add((dd,rr,rr+s[i]-dd))
            broad.append([list(op) for op in sorted(ops)])
        st2={**st,'domains':broad};tests,frac=lift(a,b,d,R,rho,s,q,adj,sel,res,F,triples,st2)
        counts['broadened_lifts']+=1;counts['exact_model_inequalities']+=tests;counts['fractional_lift_values']+=frac
        counts['positive_surplus_systems']+=rec['t']>0;saved.append({'record':z,'broadened_domains':broad})
    report={'seed':2026090706,'counts':dict(counts),'all_pass':True,'seconds':time.time()-start,'limit':'Actual examples contain no positive-surplus graph; finite falsification tests are not a proof of universal graph lemmas.'}
    (ROOT/'evidence'/('TYPED_LIFT_TEST_REPORT.json' if TYPED else 'LIFT_TEST_REPORT.json')).write_text(json.dumps(report,indent=2)+'\n')
    (ROOT/'evidence'/('typed_broad_lift_domains.json.gz' if TYPED else 'broad_lift_domains.json.gz')).write_bytes(gzip.compress((json.dumps(saved,separators=(',',':'))+'\n').encode(),mtime=0));print(report)
if __name__=='__main__':main()
