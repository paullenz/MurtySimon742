#!/usr/bin/env python3
"""Separate, named-variable reconstruction of the shared model; standard library only.
Does not import discovery, SciPy, its matrix builder, or an optimisation solver.
All variables stand for averages of 0/1 graph indicators; see PROOF.md.
"""
from __future__ import annotations
import hashlib,json
from collections import defaultdict

def add(*parts):
    ans={}
    for multiplier,expr in parts:
        for key,value in expr.items():ans[key]=ans.get(key,0)+multiplier*value
    return {key:value for key,value in ans.items() if value}

def variable(*name):return {tuple(name):1}

def signature(coeff,rhs):
    obj=[[[list(name),v] for name,v in sorted(coeff.items()) if v],rhs]
    return hashlib.sha256(json.dumps(obj,separators=(',',':')).encode()).hexdigest()

class System:
    def __init__(self):self.inequalities={};self.equalities={};self.variables=set()
    def row(self,expr,rhs,equality=False):
        expr={k:v for k,v in expr.items() if v};self.variables.update(expr)
        (self.equalities if equality else self.inequalities)[signature(expr,rhs)]=(expr,rhs)
    def register(self,expr):self.variables.update(expr);return expr

def partition(s,rho,st):
    def collect(keys):
        groups=[]
        for i,k in enumerate(keys):
            for old,ids in groups:
                if old==k:ids.append(i);break
            else:groups.append((k,[i]))
        return [ids for k,ids in groups]
    L=collect([(s[i],st['domains'][i],st['forced'][i]) for i in range(len(s))])
    B=collect([(rho[u],st['c'][u],[(m>>u)&1 for m in st['forced']]) for u in range(len(rho))])
    return L,B

def rebuild(s,rho,st,t=1):
    a=len(s);b=len(rho);r=sum(rho);L,B=partition(s,rho,st);sys=System();row=sys.row
    d={};R={};Y={};selected={};residual={};arc={};edge={};S={};T={}
    for g,group in enumerate(L):
        i=group[0];d[g]={};R[g]={};norm={}
        for o,(dd,rr,zz) in enumerate(st['domains'][i]):
            key=('y',g,o);Y[g,o]=sys.register(variable(*key));d[g][key]=dd;R[g][key]=rr;norm[key]=1
        row(norm,1,True)
    row(add(*[(len(L[g]),R[g]) for g in range(len(L))]),r,True)
    row(add(*[(len(L[g]),d[g]) for g in range(len(L))]),2*(r+t),True)
    for g in range(len(L)):
        for h in range(g,len(L)):
            if g==h and len(L[g])<2:continue
            edge[g,h]=sys.register(variable('F',g,h));row(edge[g,h],1)
    for g in range(len(L)):
        parts=[(-1,d[g])]
        for h in range(len(L)):
            if g==h and len(L[g])<2:continue
            parts.append((len(L[h])-(g==h),edge[min(g,h),max(g,h)]))
        row(add(*parts),0,True)
    for k,group in enumerate(B):
        u=group[0];minimum=sum(bool(mask>>u&1) for mask in st['forced'])
        for g,labels in enumerate(L):
            i=labels[0];S[k,g]={};T[k,g]={}
            mandatory=bool(st['forced'][i]>>u&1)
            for o,(dd,rr,zz) in enumerate(st['domains'][i]):
                qneed=max(1,minimum,dd-rho[u]+1)
                supp=False
                for w in range(b):
                    if w==u or st['forced'][i]>>w&1:continue
                    if rho[u]+rho[w]<dd or rho[w]+st['c'][w]<qneed-1:continue
                    supp=True
                possibleS=(rho[u]>=s[i] and st['c'][u]>=qneed and supp and rr+max(1,s[i])<=b)
                possibleR=(not mandatory and rr>0)
                possibleN=(not mandatory and dd+minimum<=a-1 and rr+s[i]<=b-1)
                parts=[(-1,Y[g,o])]
                if possibleS:
                    x=sys.register(variable('sel',k,g,o));S[k,g].update(x);selected[k,g,o]=x;parts.append((1,x))
                if possibleR:
                    x=sys.register(variable('res',k,g,o));T[k,g].update(x);residual[k,g,o]=x;parts.append((1,x))
                row(add(*parts),0,not possibleN)
            if mandatory:row(S[k,g],1,True)
        row(add(*[(len(L[g]),T[k,g]) for g in range(len(L))]),rho[u],True)
        row(add(*[(len(L[g]),S[k,g]) for g in range(len(L))]),st['c'][u])
    for g,labels in enumerate(L):
        i=labels[0]
        row(add((1,R[g]),*[(-len(B[k]),T[k,g]) for k in range(len(B))]),0,True)
        row(add(*[(-len(B[k]),S[k,g]) for k in range(len(B))]),-s[i])
    for (g,h),ff in edge.items():
        for k in range(len(B)):
            row(add((1,ff),(1,S[k,g]),(-1,S[k,h]),(-1,T[k,h])),1)
            if g!=h:row(add((1,ff),(1,S[k,h]),(-1,S[k,g]),(-1,T[k,g])),1)
    for k,group in enumerate(B):
        u=group[0];q=add(*[(len(L[g]),S[k,g]) for g in range(len(L))])
        for g,labels in enumerate(L):
            i=labels[0];maxd=max(op[0] for op in st['domains'][i]);M=max(0,maxd-rho[u]+1)
            row(add((1,d[g]),(-1,q),(M,S[k,g])),rho[u]-1+M)
            M=max(0,maxd+st['c'][u]-a+1)
            row(add((1,d[g]),(1,q),(-M,S[k,g]),(-M,T[k,g])),a-1)
    row(add(*[(len(B[k])*len(L[g]),S[k,g]) for k in range(len(B)) for g in range(len(L))]),r+(b-a-1)*b)
    for k in range(len(B)):
        v={}
        for (g,h),ff in edge.items():
            v[g,h]=sys.register(variable('internalF',k,g,h))
            row(add((1,ff),(-1,v[g,h]),(1,S[k,g]),(1,S[k,h])),2)
        for g in range(len(L)):
            parts=[(-1,R[g])]
            for h in range(len(L)):
                if g==h and len(L[g])<2:continue
                parts.append((len(L[h])-(g==h),v[min(g,h),max(g,h)]))
            row(add(*parts),0)
    for k,ugroup in enumerate(B):
        u=ugroup[0];f=sum(bool(mask>>u&1) for mask in st['forced'])
        for l,wgroup in enumerate(B):
            w=wgroup[0]
            if k==l and len(ugroup)<2:continue
            for g,labels in enumerate(L):
                i=labels[0];dmin=min(op[0] for op in st['domains'][i]);qneed=max(1,f,dmin-rho[u]+1)
                if s[i]>rho[u] or dmin>rho[u]+rho[w] or st['forced'][i]>>w&1:continue
                if qneed>st['c'][u] or qneed-1>rho[w]+st['c'][w]:continue
                arc[k,l,g]=sys.register(variable('arc',k,l,g))
    for k in range(len(B)):
        for g in range(len(L)):
            row(add((-1,S[k,g]),*[(len(B[l])-(k==l),arc[k,l,g]) for l in range(len(B)) if (k,l,g) in arc]),0,True)
    incoming={}
    for k,ugroup in enumerate(B):
        u=ugroup[0];parts=[]
        for l in range(len(B)):
            for g in range(len(L)):
                if (l,k,g) in arc:parts.append(((len(B[l])-(k==l))*len(L[g]),arc[l,k,g]))
        incoming[k]=add(*parts);row(incoming[k],rho[u]+b-a-1)
    for k in range(len(B)):
        for l in range(k,len(B)):
            if k==l and len(B[k])<2:continue
            parts=[]
            for g in range(len(L)):
                if (k,l,g) in arc:parts.append((len(L[g]),arc[k,l,g]))
                if (l,k,g) in arc:parts.append((len(L[g]),arc[l,k,g]))
            row(add(*parts),1)
    for (k,l,g),v in arc.items():
        row(add((1,v),(1,S[l,g]),(1,T[l,g])),1)
        for h in range(len(L)):
            if g==h and len(L[h])<2:continue
            row(add((1,v),(1,S[k,h]),(-1,S[l,h]),(-1,T[l,h])),1)
            row(add((1,v),(1,edge[min(g,h),max(g,h)]),(1,S[k,h]),(-1,T[l,h])),2)
    for k in range(len(B)):
        q=add(*[(len(L[g]),S[k,g]) for g in range(len(L))])
        for g in range(len(L)):
            row(add((1,q),(1,incoming[k]),(b-1,S[k,g]),(-1,R[g]),*[(-len(B[l]),S[l,g]) for l in range(len(B))]),b-1)
    for key in list(sys.variables):row(variable(*key),1)
    return sys

def verify_named(system,certificate):
    weights={};total=0
    for kind,rows in [('ub',system.inequalities),('eq',system.equalities)]:
        seen=set()
        for name,w in certificate[kind]:
            if name in seen or name not in rows or type(w)!=int or (kind=='ub' and w<0):raise ValueError('Invalid multiplier or constraint')
            seen.add(name);coeff,rhs=rows[name];total+=w*rhs
            for key,val in coeff.items():weights[key]=weights.get(key,0)+val*w
    if any(x<0 for x in weights.values()) or total>=0 or total!=certificate['rhs']:raise ValueError('No exact contradiction')
    return total

def translate(discovery,cert):
    out={'rhs':cert['rhs']}
    for kind,rows in [('ub',discovery.ub),('eq',discovery.eq)]:
        d={}
        for i,w in cert[kind]:
            coefficients,rhs=rows[i];key=signature({discovery.names[j]:v for j,v in coefficients.items()},rhs);d[key]=d.get(key,0)+w
        out[kind]=[[key,w] for key,w in sorted(d.items()) if w]
    return out

def rebuild_types(s,rho,st,t=1):
    """Second derivation of the degree-type marginals and typed pair transportation."""
    system=rebuild(s,rho,st,t);row=system.row;a=len(s);b=len(rho);L,B=partition(s,rho,st)
    types={};states={};degree={};pairs={}
    for k,us in enumerate(B):
        u=us[0];lower=sum(1 for f in st['forced'] if f>>u&1)
        types[k]=tuple(range(lower,st['c'][u]+1))
        for q in types[k]:degree[k,q]=system.register(variable('degree_type',k,q))
        row(add(*[(1,degree[k,q]) for q in types[k]]),1,True)
        for g,labels in enumerate(L):
            i=labels[0];mandated=bool(st['forced'][i]>>u&1)
            for q in types[k]:
                choose=[(-1,degree[k,q])]
                for o,(dd,rr,zz) in enumerate(st['domains'][i]):
                    supplier=0
                    for w in range(b):
                        if w==u or (st['forced'][i]>>w)&1:continue
                        if dd>rho[u]+rho[w] or q>rho[w]+st['c'][w]+1:continue
                        supplier+=1
                    allowed={'typed_sel':q>=1 and s[i]<=rho[u] and dd+1<=rho[u]+q and supplier>0 and rr+max(1,s[i])<=b,
                             'typed_res':not mandated and rr>=1,
                             'typed_miss':not mandated and dd+q<=a-1 and rr+s[i]<=b-1}
                    for status in ['typed_sel','typed_res','typed_miss']:
                        if allowed[status]:
                            expr=system.register(variable(status,k,g,o,q));states[status,k,g,o,q]=expr;choose.append((1,expr))
                row(add(*choose),0,True)
            for o,op in enumerate(st['domains'][i]):
                parts=[(-1,variable('y',g,o))]
                parts.extend((1,expr) for (status,kk,gg,oo,q),expr in states.items() if kk==k and gg==g and oo==o)
                row(add(*parts),0,True)
                for status,oldkind in [('typed_sel','sel'),('typed_res','res')]:
                    parts=[]
                    old=(oldkind,k,g,o)
                    if old in system.variables:parts.append((-1,variable(*old)))
                    for q in types[k]:
                        if (status,k,g,o,q) in states:parts.append((1,states[status,k,g,o,q]))
                    row(add(*parts),0,True)
        for q in types[k]:
            for status,target in [('typed_sel',q),('typed_res',rho[u])]:
                parts=[(-target,degree[k,q])]
                for (stt,kk,g,o,qq),expr in states.items():
                    if status==stt and k==kk and q==qq:parts.append((len(L[g]),expr))
                row(add(*parts),0,True)
    for k,us in enumerate(B):
        for l,vs in enumerate(B):
            if k==l and len(us)==1:continue
            for q in types[k]:
                if not q:continue
                for v in types[l]:
                    if q-1<=rho[vs[0]]+v:pairs[k,l,q,v]=system.register(variable('pair_type',k,l,q,v))
    for k,us in enumerate(B):
        for l,vs in enumerate(B):
            if k==l and len(us)==1:continue
            parts=[(1,expr) for (kk,ll,q,v),expr in pairs.items() if (kk,ll)==(k,l)]
            for g in range(len(L)):
                key=('arc',k,l,g)
                if key in system.variables:parts.append((-len(L[g]),variable(*key)))
            row(add(*parts),0,True)
        for q in types[k]:
            parts=[(-q,degree[k,q])]
            parts.extend((len(B[l])-(k==l),expr) for (kk,l,qq,v),expr in pairs.items() if kk==k and qq==q)
            row(add(*parts),0,True)
            parts=[(-(rho[us[0]]+b-a-1),degree[k,q])]
            parts.extend((len(B[l])-(k==l),expr) for (l,kk,v,qq),expr in pairs.items() if kk==k and qq==q)
            row(add(*parts),0)
    for key in list(system.variables):row(variable(*key),1)
    return system
