#!/usr/bin/env python3
"""Saved-v5 frontier scan. Accept exclusions only after integer dual check."""
import sys,json,time
from pathlib import Path
import gzip
from collections import Counter
from common_lp import build,certificate,verify
ROOT=Path(__file__).resolve().parents[1]
P=Path(__file__).resolve().parents[1]
def main(limit=0,offset=0):
    data=json.loads(gzip.decompress((P/'dependencies/v5_FINAL_SURVIVORS.json.gz').read_bytes()));D=json.loads(gzip.decompress((P/'dependencies/n28_demands.json.gz').read_bytes()))
    data=data[offset:offset+limit] if limit else data[offset:]
    counts=Counter();start=time.perf_counter();outpath=ROOT/'evidence'/f'lp_scan_{offset}_{len(data)}.jsonl'
    with outpath.open('w') as f:
        for pos,rec in enumerate(data):
            s=D[rec['row'][0]]['s'];rho=rec['row'][2:];m=build(s,rho,rec['state']);res=m.solve()
            obj={'position':pos+offset,'index':rec['index'],'status':int(res.status),'message':res.message,'vars':len(m.names),'ub':len(m.ub),'eq':len(m.eq)}
            if res.status==2:
                cert=certificate(m)
                if cert is not None:
                    verify(m,cert);obj['certificate']=cert;obj['outcome']='exact_rejection'
                else:obj['outcome']='unresolved_no_exact_certificate'
            else:obj['outcome']='unresolved'
            counts[obj['outcome']]+=1;f.write(json.dumps(obj,separators=(',',':'))+'\n')
            if pos%250==0:f.flush();print(pos,dict(counts),round(time.perf_counter()-start,2),flush=True)
    report={'offset':offset,'input_rows':len(data),'counts':dict(counts),'seconds':time.perf_counter()-start,'numeric_profile_not_graph':True,'solver_status_alone_is_never_rejection':True,'scope':{'n':28,'Delta':15,'m':196}}
    (ROOT/'evidence'/f'LP_SCAN_REPORT_{offset}.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
if __name__=='__main__':main(int(sys.argv[1]) if len(sys.argv)>1 else 0,int(sys.argv[2]) if len(sys.argv)>2 else 0)
