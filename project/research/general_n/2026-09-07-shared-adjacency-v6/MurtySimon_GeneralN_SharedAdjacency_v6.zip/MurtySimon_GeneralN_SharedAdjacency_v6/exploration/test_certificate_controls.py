#!/usr/bin/env python3
"""Adversarial tests for branch coverage, integral-count syntax and dual integrity."""
from pathlib import Path
import gzip,json,copy,time
from check_all import check_tree
from check_constraints import rebuild_types,verify_named
ROOT=Path(__file__).resolve().parents[1]
def main():
    start=time.time()
    inp=json.loads(gzip.decompress((ROOT/'dependencies/v5_FINAL_SURVIVORS.json.gz').read_bytes()))
    dem=json.loads(gzip.decompress((ROOT/'dependencies/n28_demands.json.gz').read_bytes()))
    certs=json.loads(gzip.decompress((ROOT/'evidence/EXACT_BRANCH_CERTIFICATES.json.gz').read_bytes()))
    cert=next(x for x in certs if 'split' in x['tree']);rec=inp[cert['position']]
    s=dem[rec['row'][0]]['s'];rho=rec['row'][2:];st=rec['state'];model=rebuild_types(s,rho,st)
    leaves=check_tree(model,cert['tree'],s,rho,st);rejected=[]
    tests=[]
    bad=copy.deepcopy(cert['tree']);del bad['right'];tests.append(('missing_branch_child',bad))
    bad=copy.deepcopy(cert['tree']);bad['split']=['raw_probability',0,0];tests.append(('nonintegral_average_as_count',bad))
    bad=copy.deepcopy(cert['tree']);bad['at']=0.5;tests.append(('noninteger_split_threshold',bad))
    bad=copy.deepcopy(cert['tree']);p=bad
    while 'leaf' not in p:p=p['left']
    p['leaf']={'rhs':-1,'ub':[],'eq':[]};tests.append(('forged_branch_leaf',bad))
    bad=copy.deepcopy(cert['tree']);bad['right']=copy.deepcopy(bad['left']);tests.append(('duplicate_left_proof_in_right_branch',bad))
    for label,bad in tests:
        try:check_tree(model,bad,s,rho,st)
        except (ValueError,KeyError,TypeError):rejected.append(label)
        else:raise ValueError('Corruption accepted: '+label)
    # Whole-domain accounting is independent of any recorded total.
    A=json.loads(gzip.decompress((ROOT/'evidence/EXACT_BASE_CERTIFICATES.json.gz').read_bytes()))
    B=json.loads(gzip.decompress((ROOT/'evidence/EXACT_TYPED_CERTIFICATES.json.gz').read_bytes()))
    S=json.loads((ROOT/'evidence/FINAL_SURVIVOR_POSITIONS.json').read_text())
    full=[x['position'] for x in A+B+certs]+S
    def covered(vals):return len(vals)==len(inp) and len(set(vals))==len(inp) and set(vals)==set(range(len(inp)))
    if not covered(full):raise ValueError('Original partition is not complete')
    if covered(full[:-1]) or covered(full+[full[0]]):raise ValueError('Coverage corruption accepted')
    rejected+=['omitted_input_disposition','duplicated_input_disposition']
    out=dict(all_pass=True,negative_controls_rejected=rejected,positive_tree_leaves=leaves,
             branch_position=cert['position'],branch_original_index=cert['index'],seconds=time.time()-start)
    (ROOT/'evidence/CERTIFICATE_CONTROLS_REPORT.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
