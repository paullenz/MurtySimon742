#!/usr/bin/env python3
"""General threshold activation from a forced block; integer-only discovery."""
from __future__ import annotations
import gzip
from pathlib import Path
import json,itertools
ROOT=Path(__file__).resolve().parents[1]
def ceildiv(x,y):return (x+y-1)//y

def evaluate(s,rho,st,Z):
    a=len(s);b=len(rho);ell=b-a-1;r=sum(rho);caps=st['c'];force=st['forced']
    inside=[u for u in range(b) if Z>>u&1];outside=[u for u in range(b) if not(Z>>u&1)]
    p=sum((f&Z)==Z for f in force)
    if not inside or not p:return None
    D=0;additional_label_load=0
    for i in range(a):
        # Basic safe superset for selected sources; omits additional restrictions.
        ext=sum(rho[w]>=s[i] and caps[w]>0 for w in outside)
        demand_here=max((force[i]&Z).bit_count(),s[i]-ext,0)
        D+=demand_here
        if (force[i]&Z)!=Z:additional_label_load=max(additional_label_load,demand_here)
    U=min(r+ell*b,sum(caps))
    if not outside:return {'Z':Z,'p':p,'D':D,'U':U,'reason':'no_external_supplement'}
    c=max(rho[w] for w in outside);C=c+ell
    if C<=0:return {'Z':Z,'p':p,'D':D,'U':U,'reason':'no_incoming_capacity'}
    if D>sum(caps[u] for u in inside):return {'Z':Z,'p':p,'D':D,'U':U,'reason':'source_capacity'}
    degreeMax=max(caps[u] for u in inside);total=D;tails=[]
    for j in range(1,max(0,degreeMax-1-c)+1):
        k=j+1+c
        if k<=p:h=len(inside)
        else:
            deficit=D-sum(min(caps[u],k-1) for u in inside)
            h=0
            for gain in sorted((max(0,caps[u]-k+1) for u in inside),reverse=True):
                if deficit<=0:break
                deficit-=gain;h+=1
            if deficit>0:raise ValueError('Inconsistent source load')
            if k==p+1:h=max(h,additional_label_load)
        required=ceildiv(p*h,C);total+=required;tails.append([j,k,h,required])
        if required>len(outside):return {'Z':Z,'p':p,'D':D,'U':U,'c':c,'C':C,'tails':tails,'reason':'too_few_supplements'}
    if total>U:return {'Z':Z,'p':p,'D':D,'U':U,'c':c,'C':C,'tails':tails,'lower_Q':total,'reason':'threshold_total'}
    return None

def find(s,rho,st):
    groups=set(f for f in st['forced'] if f)
    while True:
        more={u&v for u in groups for v in groups if u&v};new=groups|more
        if new==groups:break
        groups=new
    for Z in sorted(groups,key=lambda z:(-z.bit_count(),z)):
        c=evaluate(s,rho,st,Z)
        if c:return c
    return None
if __name__=='__main__':
    P=Path(__file__).resolve().parents[1];data=json.loads(gzip.decompress((P/'dependencies/v5_FINAL_SURVIVORS.json.gz').read_bytes()));D=json.loads(gzip.decompress((P/'dependencies/n28_demands.json.gz').read_bytes()));certs=[]
    for pos,row in enumerate(data):
        c=find(D[row['row'][0]]['s'],row['row'][2:],row['state'])
        if c:certs.append({'position':pos,'index':row['index'],'certificate':c})
    (ROOT/'evidence'/'THRESHOLD_CERTIFICATES.json').write_text(json.dumps(certs,separators=(',',':'))+'\n')
    old={x['position'] for x in json.loads((ROOT/'evidence'/'LP_CERTIFICATES.json').read_text())}
    print('threshold',len(certs),'new',len([c for c in certs if c['position'] not in old]));print(certs[:3])
