#!/usr/bin/env python3
"""Bounded integer-count search over every typed-LP survivor. Unfinished trees stay open."""
import json,gzip,time
from pathlib import Path
from collections import Counter
from branch_counts import search
ROOT=Path(__file__).resolve().parents[1]
def main():
    data=json.loads(gzip.decompress((ROOT/'dependencies/v5_FINAL_SURVIVORS.json.gz').read_bytes()));D=json.loads(gzip.decompress((ROOT/'dependencies/n28_demands.json.gz').read_bytes()))
    pending=[row['position'] for row in json.loads((ROOT/'evidence/types_0_4617.json').read_text()) if row['outcome']!='exact_rejection']
    stats=Counter();out=[];start=time.time()
    with (ROOT/'evidence/BRANCH_SWEEP.jsonl').open('w') as stream:
        for pos in pending:
            rec=data[pos];ans=search(D[rec['row'][0]]['s'],rec['row'][2:],rec['state'],depth=6,node_limit=127,typed=True)
            record={'position':pos,'index':rec['index'],**ans};out.append(record);stream.write(json.dumps(record,separators=(',',':'))+'\n');stream.flush();stats[ans['reason']]+=1
            if len(out)%25==0:print(len(out),dict(stats),round(time.time()-start,2),flush=True)
    (ROOT/'evidence/EXACT_BRANCH_CERTIFICATES.json.gz').write_bytes(gzip.compress((json.dumps([{'position':r['position'],'index':r['index'],'tree':r['tree']} for r in out if r['tree'] is not None],separators=(',',':'))+'\n').encode(),mtime=0))
    (ROOT/'evidence/FINAL_SURVIVOR_POSITIONS.json').write_text(json.dumps([r['position'] for r in out if r['tree'] is None])+'\n')
    report={'rows':len(out),'depth_limit':6,'node_limit':127,'counts':dict(stats),'seconds':time.time()-start,'surviving_relaxations_not_graphs':True}
    (ROOT/'evidence/BRANCH_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print('DONE',report,flush=True)
if __name__=='__main__':main()
