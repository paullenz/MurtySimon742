#!/usr/bin/env python3
"""Exact threshold-layer checks and explicit separately graphical profile family.
No solver or discovery module is imported. The constructions below are NOT
critical graphs: the F graph and residual bipartite graph are separate tests.
"""
from __future__ import annotations
from pathlib import Path
import gzip,json,random,time
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[1]
def require(test,message):
    if not test:raise ValueError(message)
def ceildiv(x,y):return -(-x//y)
def parameters(p:int):
    require(type(p)==int and p>=18,'p must be an integer at least 18')
    scalar=4*p+(p-2)*ceildiv(4*p,3)
    L=ceildiv(scalar-3*p-24,3);a=p+L+1;b=a+3
    return dict(p=p,L=L,a=a,b=b,n=a+b+1,m=(a+2)**2+1,t=2,
                r=p+L+16,K=L-2*p+34,old_lower=scalar,
                new_lower=scalar+p+3,upper=3*p+3*L+24)
def separate_constructions(p:int):
    z=parameters(p);L=z['L'];a=z['a'];b=z['b'];K=z['K']
    # Labels: zero, L-1 demand-one, extra demand-three, p demand-four.
    s=[0]+[1]*(L-1)+[3]+[4]*p
    R=[3*p-18]+[1]*K+[0]*(L-1-K)+[0]+[0]*p
    d=[0]+[2]*K+[1]*(L-1-K)+[3]+[4]*p
    high=list(range(L+1,a));twos=list(range(1,K+1));leaves=list(range(K+1,L));extra=L
    order=[]
    for u,v in zip(high,twos[:p]):order.extend([u,v])
    order.extend([extra]+twos[p:]);edges=set()
    def edge(u,v):
        require(u!=v,'Loop');key=tuple(sorted((u,v)));require(key not in edges,'Repeated F edge');edges.add(key)
    for j,u in enumerate(order):edge(u,order[(j+1)%len(order)])
    for j,u in enumerate(high[:18]):edge(u,high[(j+1)%18])
    it=iter(leaves)
    for u in high[18:]:edge(u,next(it));edge(u,next(it))
    edge(extra,next(it));require(list(it)==[],'Unused leaves')
    degrees=[0]*a
    for u,v in edges:degrees[u]+=1;degrees[v]+=1
    require(degrees==d,'F degree mismatch')
    rho=[1]*(b-4)+[4]*4;red=set()
    for k,u in enumerate(range(b-4,b)):
        for v in range(1+4*k,5+4*k):red.add((u,v))
    targets=[0]*R[0]+list(range(17,K+1))
    require(len(targets)==b-4,'Wrong residual fill size')
    for u,v in enumerate(targets):red.add((u,v))
    rdeg=[0]*b;cdeg=[0]*a
    for u,v in red:rdeg[u]+=1;cdeg[v]+=1
    require(rdeg==rho and cdeg==R,'Residual degree mismatch')
    require([max(0,x-y) for x,y in zip(d,R)]==s,'Demand mismatch')
    require(sum(d)==2*(sum(rho)+2) and sum(R)==sum(rho)==z['r'],'Ledger mismatch')
    require(max(d)<a and max(R)<=b and max(rho)<=a,'Local range failure')
    return dict(parameters=z,s=s,d=d,R=R,rho=rho,F_edges=sorted(edges),residual_edges=sorted(red),
                graph_realizability_or_criticality_claimed=False)
def main():
    start=time.time();scalar_checks=0;examples=[]
    for p in range(18,10001):
        z=parameters(p);L=z['L'];a=z['a'];b=z['b']
        require(L>=3*p-34 and p<=z['K']<=L-1,'Family size conditions')
        require(z['old_lower']<=z['upper']<=z['old_lower']+2,'Old scalar test should pass')
        require(z['new_lower']>z['upper'],'New threshold failure')
        require(z['m']==z['n']**2//4+1 and z['m']-b*(z['n']-b)==2,'Edge-count conversion')
        require(z['upper']==z['r']+2*b,'Total incoming cap')
        require(L>=Fraction(4*p*p-5*p-72,9),'Ceiling lower bound')
        scalar_checks+=1
    for p in range(18,151):
        ex=separate_constructions(p)
        if p<=20:examples.append(ex)
    # Random bipartite arc systems. Z sources each have p mandatory outgoing
    # arcs to distinct supplements W; C is a per-supplement incoming bound.
    # qW is set large enough to respect qZ-1-c on every such arc. Check each
    # layer and their sum; no graph density or criticality is assumed.
    rng=random.Random(20260907061);accepted=0;positive=0;layers=0;saved=[]
    for attempt in range(12000):
        z=rng.randrange(1,9);w=rng.randrange(2,14);p=rng.randrange(1,min(w,7)+1)
        c=rng.randrange(0,5);C=rng.randrange(1,8)
        qZ=[rng.randrange(p,p+8) for _ in range(z)]
        arcs=[(u,v) for u in range(z) for v in rng.sample(range(w),p)]
        incoming=[sum(v==j for u,v in arcs) for j in range(w)]
        if max(incoming)>C:continue
        qW=[max([0]+[qZ[u]-1-c for u,v in arcs if v==j])+rng.randrange(0,3) for j in range(w)]
        bound=0;positive+=any(qZ[u]>c+1 for u in range(z))
        for j in range(1,max(qZ)+1):
            h=sum(q>=j+c+1 for q in qZ);need=ceildiv(p*h,C)
            require(sum(q>=j for q in qW)>=need,'Layer inequality failed');bound+=need;layers+=1
        require(sum(qW)>=bound,'Sum of threshold layers failed');accepted+=1
        saved.append(dict(z=z,w=w,p=p,c=c,C=C,qZ=qZ,qW=qW,arcs=arcs))
    payload=dict(seed=20260907061,attempts=12000,accepted_abstract_systems=saved,separately_graphical_family_examples=examples)
    (ROOT/'evidence/THRESHOLD_TEST_INPUTS.json.gz').write_bytes(gzip.compress((json.dumps(payload,separators=(',',':'))+'\n').encode(),mtime=0))
    report=dict(all_pass=True,family_integer_parameters_checked=scalar_checks,
                separate_F_and_residual_constructions_checked=133,examples_saved=3,
                abstract_attempts=12000,abstract_accepted=accepted,positive_activation_cases=positive,
                threshold_layer_checks=layers,seconds=time.time()-start,
                family_all_p_ge_18_proof_is_symbolic_not_extrapolation=True,
                simultaneous_graph_or_criticality_claimed=False)
    (ROOT/'evidence/THRESHOLD_FAMILY_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
if __name__=='__main__':main()
