#!/usr/bin/env python3
"""Exact v6 checker. No discovery module, SciPy or external solver is imported."""
import json,gzip,time,sys,copy,hashlib
from pathlib import Path
from collections import Counter
from check_constraints import rebuild,rebuild_types,verify_named,partition,variable,add,signature,System
ROOT=Path(__file__).resolve().parents[1]
def need(x,msg):
    if not x:raise ValueError(msg)

def count_form(name,s,rho,st,model):
    L,B=partition(s,rho,st);kind=name[0]
    if kind=='degree_type' and len(name)==3:
        _,k,q=name;need(0<=k<len(B),'Source class');e=variable('degree_type',k,q);factor=len(B[k])
    elif kind=='column' and len(name)==3:
        _,g,o=name;need(0<=g<len(L),'Label class');e=variable('y',g,o);factor=len(L[g])
    elif kind=='F' and len(name)==3:
        _,g,h=name;need(0<=g<=h<len(L),'F pair');e=variable('F',g,h);factor=len(L[g])*len(L[h]) if g!=h else len(L[g])*(len(L[g])-1)//2
    elif kind in ('sel','res') and len(name)==3:
        _,k,g=name;need(0<=k<len(B) and 0<=g<len(L),'Incidence block')
        e={key:1 for key in model.variables if key[:3]==(kind,k,g)};factor=len(B[k])*len(L[g])
    else:raise ValueError('Unknown integral count')
    need(e and all(key in model.variables for key in e) and factor>0,'Invalid integral expression')
    return {key:value*factor for key,value in e.items()}

def check_tree(model,tree,s,rho,st,branches=(),depth=0):
    need(isinstance(tree,dict) and depth<=100,'Invalid proof tree')
    if 'leaf' in tree:
        need(set(tree)=={'leaf'},'Invalid leaf')
        obj=System();obj.variables=set(model.variables);obj.equalities=dict(model.equalities);obj.inequalities=dict(model.inequalities)
        for e,b in branches:obj.inequalities[signature(e,b)]=(e,b)
        verify_named(obj,tree['leaf']);return 1
    need(set(tree)=={'split','at','left','right'} and type(tree['at'])==int,'Invalid split')
    e=count_form(tree['split'],s,rho,st,model);k=tree['at']
    # The graph count is integral: these two halfspaces cover every possible count.
    return check_tree(model,tree['left'],s,rho,st,branches+((e,k),),depth+1)+check_tree(model,tree['right'],s,rho,st,branches+(({j:-v for j,v in e.items()},-k-1),),depth+1)

def check_threshold(s,rho,st,cert):
    # Independent cardinality calculation: use subset choices of high sources
    # to bound how much degree load can fit with at most h above a threshold.
    from itertools import combinations
    a=len(s);b=len(rho);Z=cert['Z'];need(type(Z)==int and 0<Z<(1<<b),'Invalid block')
    high=[u for u in range(b) if Z>>u&1];low=[u for u in range(b) if not Z>>u&1]
    I=[i for i,f in enumerate(st['forced']) if all(f>>u&1 for u in high)];p=len(I);need(p>0,'No forced block')
    loads=[]
    for i in range(a):
        external=sum(st['c'][w]>0 and s[i]<=rho[w] for w in low)
        loads.append(max(0,s[i]-external,sum(st['forced'][i]>>u&1 for u in high)))
    D=sum(loads);U=min(sum(st['c']),sum(rho)+(b-a-1)*b)
    need(cert['p']==p and cert['D']==D and cert['U']==U,'Incorrect block accounting')
    if not low:need(cert['reason']=='no_external_supplement','Wrong reason');return
    c=max(rho[w] for w in low);C=c+b-a-1
    if C<=0:need(cert['reason']=='no_incoming_capacity','Wrong reason');return
    if D>sum(st['c'][u] for u in high):need(cert['reason']=='source_capacity','Wrong reason');return
    need(cert['c']==c and cert['C']==C,'Wrong incoming cap')
    total=D;tails=[]
    for j in range(1,max(0,max(st['c'][u] for u in high)-1-c)+1):
        k=j+c+1
        if k<=p:h=len(high)
        else:
            for h in range(len(high)+1):
                upper=max(sum(st['c'][u] if u in subset else min(st['c'][u],k-1) for u in high) for subset in combinations(high,h))
                if upper>=D:break
            if k==p+1:h=max(h,max([0]+[loads[i] for i in range(a) if i not in I]))
        n=(p*h+C-1)//C;total+=n;tails.append([j,k,h,n])
        if n>len(low):need(cert['reason']=='too_few_supplements' and cert['tails']==tails,'Wrong tail cut');return
    need(total>U and cert['reason']=='threshold_total' and cert['tails']==tails and cert['lower_Q']==total,'No threshold contradiction')

def main():
    start=time.time()
    raw=gzip.decompress((ROOT/'dependencies/v5_FINAL_SURVIVORS.json.gz').read_bytes())
    demands=gzip.decompress((ROOT/'dependencies/n28_demands.json.gz').read_bytes())
    need(hashlib.sha256(raw).hexdigest()=='72d511eeb75c40262649cbc2d08c94c40862bba0a2790d24185f5e54ea320f4b','Wrong frozen v5 frontier bytes')
    need(hashlib.sha256(demands).hexdigest()=='c1e5e0f0ab48c0970abe0502081465d2032ba340015335fb80a5660580e5b9f9','Wrong frozen demand bytes')
    data=json.loads(raw);D=json.loads(demands);need(len(data)==6918,'Wrong input size')
    seen=set();cnt=Counter();neg=[]
    def parts(rec):
        pos=rec['position'];need(type(pos)==int and 0<=pos<len(data),'Invalid input index');r=data[pos];need(r['index']==rec['index'],'Wrong original row')
        return D[r['row'][0]]['s'],r['row'][2:],r['state']
    first=None
    for phase,builder in [('base',rebuild),('typed',rebuild_types)]:
        path=ROOT/'evidence'/f'EXACT_{phase.upper()}_CERTIFICATES.json.gz'
        records=json.loads(gzip.decompress(path.read_bytes()))
        for rec in records:
            need(rec['position'] not in seen and rec['phase']==phase,'Duplicate or wrong phase');s,rho,st=parts(rec);model=builder(s,rho,st);verify_named(model,rec['certificate']);seen.add(rec['position']);cnt[phase+'_rejections']+=1
            if first is None:first=(model,rec['certificate'])
        print('checked',phase,cnt[phase+'_rejections'],round(time.time()-start,2),flush=True)
    branchpath=ROOT/'evidence/EXACT_BRANCH_CERTIFICATES.json.gz'
    if branchpath.exists():
        for rec in json.loads(gzip.decompress(branchpath.read_bytes())):
            need(rec['position'] not in seen,'Repeated branch root');s,rho,st=parts(rec);model=rebuild_types(s,rho,st)
            cnt['branch_leaves']+=check_tree(model,rec['tree'],s,rho,st);seen.add(rec['position']);cnt['branch_rejections']+=1
    for rec in json.loads((ROOT/'evidence/THRESHOLD_CERTIFICATES.json').read_text()):
        s,rho,st=parts(rec);check_threshold(s,rho,st,rec['certificate']);cnt['overlapping_threshold_checks']+=1
    survivors=json.loads((ROOT/'evidence/FINAL_SURVIVOR_POSITIONS.json').read_text());need(len(set(survivors))==len(survivors),'Duplicate survivor')
    need(set(survivors).isdisjoint(seen) and set(survivors)|seen==set(range(len(data))),'Coverage or partition failure')
    cnt['final_survivors']=len(survivors);cnt['final_demand_patterns']=len({data[i]['row'][0] for i in survivors})
    expanded=json.loads(gzip.decompress((ROOT/'evidence/FINAL_SURVIVORS.json.gz').read_bytes()))
    expected=[{'position':i,'index':data[i]['index'],'s':D[data[i]['row'][0]]['s'],'row':data[i]['row'],'state':data[i]['state']} for i in survivors]
    need(expanded==expected,'Expanded survivor file disagrees with frozen input')
    model,cert=first
    for label,bad in [('zero_dual',{'ub':[],'eq':[],'rhs':-1}),('unknown_constraint',{'ub':[['f'*64,1]],'eq':[],'rhs':-1}),('wrong_rhs',{**cert,'rhs':cert['rhs']-1})]:
        try:verify_named(model,bad)
        except ValueError:neg.append(label)
        else:raise ValueError('Corrupted certificate accepted')
    report={'all_pass':True,'counts':dict(cnt),'negative_controls_rejected':neg,'seconds':time.time()-start,'checker_imports_discovery_or_solver':False,'mathematical_status':'candidate; independent external review OPEN','scope':{'n':28,'Delta':15,'m':196},'higher_edge_count_coverage':False,'frozen_input_sha256_checked':True,'expanded_survivors_checked':True}
    (ROOT/'evidence/EXACT_CHECK_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
if __name__=='__main__':main()
