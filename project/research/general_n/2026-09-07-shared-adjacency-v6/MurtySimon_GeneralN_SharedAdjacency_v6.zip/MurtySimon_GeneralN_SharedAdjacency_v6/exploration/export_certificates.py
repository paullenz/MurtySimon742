#!/usr/bin/env python3
"""Export solver-independent named constraints; cross-check both complete models."""
import json,gzip,sys,time
from pathlib import Path
from common_lp import build
from degree_types import build_types
from check_constraints import rebuild,rebuild_types,signature,translate,verify_named
ROOT=Path(__file__).resolve().parents[1]
def main(phase):
    data=json.loads(gzip.decompress((ROOT/'dependencies/v5_FINAL_SURVIVORS.json.gz').read_bytes()));D=json.loads(gzip.decompress((ROOT/'dependencies/n28_demands.json.gz').read_bytes()))
    raw=json.loads((ROOT/'evidence'/('LP_CERTIFICATES.json' if phase=='base' else 'types_0_4617.json')).read_text());out=[];start=time.time()
    for rec in raw:
        if 'certificate' not in rec:continue
        row=data[rec['position']];s=D[row['row'][0]]['s'];rho=row['row'][2:];st=row['state']
        m=(build if phase=='base' else build_types)(s,rho,st);ref=(rebuild if phase=='base' else rebuild_types)(s,rho,st)
        assert set(m.names)==ref.variables
        for rows,saved in [(m.ub,ref.inequalities),(m.eq,ref.equalities)]:
            expected={signature({m.names[j]:c for j,c in e.items()},r) for e,r in rows}
            assert expected==set(saved),'Different model constraint sets'
        named=translate(m,rec['certificate']);verify_named(ref,named)
        out.append({'position':rec['position'],'index':rec['index'],'phase':phase,'certificate':named})
        if len(out)%250==0:print(phase,len(out),round(time.time()-start,2),flush=True)
    target=ROOT/'evidence'/f'EXACT_{phase.upper()}_CERTIFICATES.json.gz';target.write_bytes(gzip.compress((json.dumps(out,separators=(',',':'))+'\n').encode(),mtime=0))
    report={'phase':phase,'certificates':len(out),'separate_model_and_integer_checks_pass':True,'seconds':time.time()-start}
    (ROOT/'evidence'/f'EXPORT_{phase.upper()}_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
if __name__=='__main__':main(sys.argv[1])
