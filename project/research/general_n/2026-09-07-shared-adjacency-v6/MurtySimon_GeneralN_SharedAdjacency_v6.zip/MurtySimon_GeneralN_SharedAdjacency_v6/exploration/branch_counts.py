#!/usr/bin/env python3
"""Bounded exact-proof branching on integer graph counts, not symmetry averages."""
import math,time
from common_lp import build,certificate,verify
from check_constraints import partition,translate

def integer_forms(m,s,rho,st):
    L,B=partition(s,rho,st);index={v:j for j,v in enumerate(m.names)};forms=[]
    for j,name in enumerate(m.names):
        if name[0]=='y':
            _,g,o=name;forms.append((('column',g,o),{j:len(L[g])},0))
        elif name[0]=='F':
            _,g,h=name;factor=len(L[g])*len(L[h]) if g!=h else len(L[g])*(len(L[g])-1)//2
            forms.append((('F',g,h),{j:factor},1))
    for k,us in enumerate(B):
        for g,ls in enumerate(L):
            for kind in ['sel','res']:
                expr={j:len(us)*len(ls) for name,j in index.items() if name[:3]==(kind,k,g)}
                if expr:forms.append(((kind,k,g),expr,2))
    return forms

def search(s,rho,st,depth=4,node_limit=31,t=1,typed=False):
    from degree_types import build_types
    m=(build_types if typed else build)(s,rho,st,t);forms=integer_forms(m,s,rho,st);
    if typed:
        L,B=partition(s,rho,st)
        forms=[(name,expr,priority+1) for name,expr,priority in forms]
        forms += [(name,{j:len(B[name[1]])},0) for j,name in enumerate(m.names) if name[0]=='degree_type']
    nodes=0;start=time.perf_counter()
    def visit(level):
        nonlocal nodes
        if nodes>=node_limit:return None,'node_limit'
        nodes+=1;res=m.solve()
        if res.status==2:
            c=certificate(m)
            if c is None:return None,'uncertified_numeric_infeasible'
            verify(m,c);return {'leaf':translate(m,c)},'closed'
        if res.status!=0:return None,'solver_status_'+str(res.status)
        if level==depth:return None,'depth_limit'
        choices=[]
        for name,expr,priority in forms:
            value=sum(res.x[j]*c for j,c in expr.items());fraction=value-math.floor(value)
            if min(fraction,1-fraction)>1e-7:choices.append((priority,-min(fraction,1-fraction),name,expr,math.floor(value)))
        if not choices:return None,'integral_basic_counts_relaxation'
        _,_,name,expr,k=min(choices,key=lambda x:x[:3])
        m.le(expr,k);left,reason=visit(level+1);m.ub.pop()
        if left is None:return None,reason
        m.le({j:-c for j,c in expr.items()},-k-1);right,reason=visit(level+1);m.ub.pop()
        if right is None:return None,reason
        return {'split':list(name),'at':k,'left':left,'right':right},'closed'
    proof,reason=visit(0)
    return {'tree':proof,'reason':reason,'nodes':nodes,'seconds':time.perf_counter()-start}

if __name__=='__main__':
    import json,sys
    from pathlib import Path
    import gzip
    from collections import Counter
    p=Path(__file__).resolve().parents[1];root=Path(__file__).resolve().parents[1]
    data=json.loads(gzip.decompress((p/'dependencies/v5_FINAL_SURVIVORS.json.gz').read_bytes()));D=json.loads(gzip.decompress((p/'dependencies/n28_demands.json.gz').read_bytes()));poss=json.loads((root/'evidence/LP_SURVIVOR_POSITIONS.json').read_text())
    limit=int(sys.argv[1]) if len(sys.argv)>1 else 100;offset=int(sys.argv[2]) if len(sys.argv)>2 else 0;depth=int(sys.argv[3]) if len(sys.argv)>3 else 4
    counts=Counter();begin=time.time();out=[]
    for pos in poss[offset:offset+limit]:
        rec=data[pos];ans=search(D[rec['row'][0]]['s'],rec['row'][2:],rec['state'],depth=depth,node_limit=2**(depth+1)-1);counts[ans['reason']]+=1
        out.append({'position':pos,'index':rec['index'],**ans})
        if len(out)%25==0:print(len(out),dict(counts),time.time()-begin,flush=True)
    (root/'evidence'/f'branch_{offset}_{len(out)}_d{depth}.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
    print('DONE',dict(counts),time.time()-begin)
