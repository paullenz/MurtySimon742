# Review and handoff — shared adjacency v6

## Outcome and exact scope

At (n,Delta,m)=(28,15,196), the preserved 6,918-row v5 frontier reduces to **388 rows in 167 demand patterns**. Exact certificates reject 2,301 rows in the common-column/F model and 4,138 more in the degree-type extension. Complete complementary proof trees reject 91 further roots, with 572 checked leaves. Every remaining root in the final bounded sweep stopped at depth six. No complete order is claimed. Higher edge counts were not scanned and no monotonicity extension is asserted.

The new hand threshold-activation argument rejects fourteen rows already counted in the base-model exclusions. A depth-four trial closed nine of fifty typed survivors; these overlap the later full depth-six sweep and are not additional progress. The initial base-only depth-four trial on one hundred rows closed none. Its five cases with integral basic counts were still relaxation points, not graphs. The trial led to retaining degree types and source/supplement type transport; its unsuccessful result remains preserved.

## Dependencies and verification boundary

The repository baseline is commit `00ad1a511971397fcd8a4341b021493c2383252e`. The uploaded original v5 archive and all 54 payload hashes matched locally. The full v5 mathematical computation was not re-executed in this turn. Its output option domains, source caps and forced-label sets are inputs to v6, not conclusions re-proved by the new checker. Their exact bytes are pinned; no unseen or unpreserved chat is used as a numerical input.

The primary published complement correspondence and quasi-edge statements were inspected in the Haynes–Henning–van der Merwe–Yeo paper (Theorems 3.1–3.2 and Observation 3.4). The complete paper was not independently re-proved. Inherited residual/activity lemmas and the broader order reductions remain explicit project dependencies.

`check_constraints.py` reconstructs all new constraints with named variables using a separately written implementation. `check_all.py` accepts only exact integer contradictions and complete branch trees, verifies frozen input hashes and checks every final disposition. It uses no solver and imports no discovery code. Discovery uses SciPy to suggest coefficients; failed rounding, solver failure or bounded-search noncompletion is never a rejection.

Symmetry averaging is a particularly important audit point. It is a convex averaging argument over all label/source permutations preserving the input domains, not an assumed automorphism of a counterexample. Fractional averages are valid even for integral graphs. Branching uses only integer block counts or degree-type counts. It never treats a mean edge probability as a Boolean edge.

## Falsification and negative-control tests

The actual-graph input has 916 selected systems on 639 labelled critical graphs, orders 5 through 22. Criticality, roots and quasi-edge selections are rechecked from adjacency. Singleton and broadened column domains are lifted exactly into both models. The base model has 300,567 tested constraint evaluations; the typed model has 588,729, including 22,547 fractional variable values. The shared-union bound has 413 nonempty checks and is strictly stronger than the separate-source maximum in 104 checks. The internal-F residual bound has 107 nonzero checks. All pass, but there is no positive-surplus graph in the sample.

The threshold theorem is tested in 7,817 abstract arc systems (12,000 attempted), with 66,103 layer checks and 7,409 positive-activation examples. These systems do not impose graph criticality or the density ledger. The infinite family's arithmetic is tested for p=18..10000, and separate F/residual constructions for p=18..150. These are tests of the symbolic derivation, not extrapolation or simultaneous graph constructions.

Ten corrupt-evidence controls are rejected across the two checker test programs: zero dual, unknown constraint, wrong right-hand side, omitted branch child, raw-average split, noninteger threshold, forged leaf, reuse of the left proof on the right branch, omitted disposition and duplicate disposition. The exact checker also verifies that the expanded final survivor file agrees with the original input.

## Operational and preservation notes

Long computations were executed and completed within this active response, with streamed row dispositions and recorded commands. An initial container invocation of the base certificate export was interrupted by the execution time limit; no partial export was treated as complete. The subsequent full export and the final full checker completed successfully. No running job is needed to use this checkpoint.

Input paths in the exploratory drivers were changed from this session's mounted directory to the package's preserved compressed dependencies. These are I/O-only edits recorded in `PATH_PORTABILITY_EDITS.json`; no model equations were changed. The drivers were compiled and tested after an indentation error introduced during path editing was fixed. The published checker/replay run was performed after these edits; operational editing errors are not mathematical rejections.

The GitHub discovery attempt in this turn exposed 48 read operations, with no create-tree or create-file action. Plugin discovery found only the already installed GitHub integration. This does not establish that the user's write permission changed. No remote v6 commit is asserted without branch attachment and read-back. The complete v6 ZIP is the new local preservation object; v5 remains the verified remote checkpoint. See `PUBLICATION_STATUS.json` for exact status, rather than treating this package's existence as a commit.

## Next mathematical target

Work from `evidence/FINAL_SURVIVORS.json.gz`: require one integral common column/F assignment and more of the joint selected-neighbourhood information, rather than only shared fractional marginals and block counts. The bounded count-branching trees can be deepened, or supplemented with better threshold/cardinality cuts, but success is not guaranteed by the current counts. For any new split, establish integrality for every lifted graph before using it.

The most review-sensitive items are the graph-to-averaged-model mapping; distinct-index multiplicities within equal classes; the residual status of forced supplement adjacencies; the fixed-degree conditional margins; and complementary coverage of integer branches. The threshold-layer inequality avoids summing the same selection cost twice: a vertex contributes once per outgoing degree layer, exactly its outgoing degree.

Retain **candidate mathematics; arithmetic REPRODUCED; independent external review OPEN**. No novelty, external endorsement, uniform coefficient improvement, complete order-28 proof, formal verification or proof through 1,000 is claimed.
