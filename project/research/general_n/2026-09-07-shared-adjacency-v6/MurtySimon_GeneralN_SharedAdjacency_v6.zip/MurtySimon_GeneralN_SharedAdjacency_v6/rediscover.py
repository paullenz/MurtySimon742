#!/usr/bin/env python3
"""Optional fresh numerical discovery, with exact checking of every accepted rejection.
Requires SciPy/NumPy. A partial --limit trial is labelled partial, never complete.
Writes only to a new output directory; does not overwrite preserved evidence.
"""
from __future__ import annotations
import argparse,gzip,hashlib,json,sys,time
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'exploration'))
from common_lp import build,certificate,verify
from degree_types import build_types
from branch_counts import search
from check_constraints import rebuild,rebuild_types,translate,verify_named
from check_all import check_tree

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--limit',type=int,default=0,help='0 = full input; positive values = first that many rows')
    parser.add_argument('--depth',type=int,default=6)
    parser.add_argument('--nodes',type=int,default=127)
    args=parser.parse_args()
    if not __debug__:parser.error('Assertions must remain enabled')
    if args.output.exists():parser.error('Output directory already exists')
    if args.limit<0 or args.depth<0 or args.nodes<1:parser.error('Invalid numerical limit')
    raw=gzip.decompress((ROOT/'dependencies/v5_FINAL_SURVIVORS.json.gz').read_bytes())
    demandraw=gzip.decompress((ROOT/'dependencies/n28_demands.json.gz').read_bytes())
    if hashlib.sha256(raw).hexdigest()!='72d511eeb75c40262649cbc2d08c94c40862bba0a2790d24185f5e54ea320f4b':raise ValueError('Frozen frontier mismatch')
    if hashlib.sha256(demandraw).hexdigest()!='c1e5e0f0ab48c0970abe0502081465d2032ba340015335fb80a5660580e5b9f9':raise ValueError('Frozen demands mismatch')
    data=json.loads(raw);D=json.loads(demandraw);limit=min(len(data),args.limit or len(data));args.output.mkdir(parents=True)
    certs={'base':[],'typed':[],'branch':[]};survivors=[];counts=Counter();begin=time.time()
    with (args.output/'DISPOSITIONS.jsonl').open('w') as stream:
        for pos,rec in enumerate(data[:limit]):
            s=D[rec['row'][0]]['s'];rho=rec['row'][2:];st=rec['state'];disposition=None
            details={'position':pos,'index':rec['index'],'attempts':[]}
            for phase,builder,reference in [('base',build,rebuild),('typed',build_types,rebuild_types)]:
                model=builder(s,rho,st);res=model.solve();details['attempts'].append({'phase':phase,'status':int(res.status),'message':str(res.message)})
                if res.status!=2:continue
                c=certificate(model)
                if c is None:continue
                verify(model,c);named=translate(model,c);verify_named(reference(s,rho,st),named)
                certs[phase].append({'position':pos,'index':rec['index'],'phase':phase,'certificate':named})
                disposition=phase+'_exact';break
            if disposition is None:
                result=search(s,rho,st,depth=args.depth,node_limit=args.nodes,typed=True)
                details['branch_nodes']=result['nodes'];details['branch_outcome']=result['reason']
                if result['tree'] is not None:
                    leaves=check_tree(rebuild_types(s,rho,st),result['tree'],s,rho,st)
                    certs['branch'].append({'position':pos,'index':rec['index'],'tree':result['tree'],'leaves':leaves})
                    disposition='branch_exact'
                else:
                    survivors.append({'position':pos,'index':rec['index'],'reason':result['reason'],'s':s,'row':rec['row'],'state':st})
                    disposition='unresolved'
            details['disposition']=disposition;counts[disposition]+=1
            stream.write(json.dumps(details,separators=(',',':'))+'\n');stream.flush()
            if (pos+1)%100==0:print(pos+1,dict(counts),round(time.time()-begin,2),flush=True)
    for phase,objects in certs.items():
        (args.output/f'EXACT_{phase.upper()}_CERTIFICATES.json.gz').write_bytes(gzip.compress((json.dumps(objects,separators=(',',':'))+'\n').encode(),mtime=0))
    (args.output/'SURVIVORS.json.gz').write_bytes(gzip.compress((json.dumps(survivors,separators=(',',':'))+'\n').encode(),mtime=0))
    result={'input_rows':len(data),'processed_rows':limit,'full_input_coverage':limit==len(data),
            'counts':dict(counts),'depth':args.depth,'node_limit':args.nodes,'seconds':time.time()-begin,
            'accepted_certificates_checked_with_separate_builder':True,
            'scope':{'n':28,'Delta':15,'m':196},'higher_edge_counts_covered':False,
            'mathematical_status':'candidate; independent external review OPEN'}
    (args.output/'REPORT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
