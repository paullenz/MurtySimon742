# Shared adjacency v6 — common columns, source-degree types and exact proof trees

7 September 2026. **Candidate mathematics; exact internal arithmetic REPRODUCED; independent mathematical review OPEN.** No complete order above the earlier n25/n27 candidates, improved global degree coefficient or novelty claim.

## Current result

The committed v5 input at **n=28, Delta=15, m=196** contains 6,918 necessary-condition rows. This checkpoint rejects **6,530**, leaving **388 rows in 167 demand patterns**:

| Test | Input rows | Exact exclusions | Remaining |
|---|---:|---:|---:|
| Common fractional columns, F and selected triples | 6,918 | 2,301 | 4,617 |
| Integer source-degree types coupled to pair transport | 4,617 | 4,138 | 479 |
| Fully closed proof trees within depth-six/node-127 limits | 479 | 91 | **388** |

The final 388 roots stopped at the depth limit. They are unresolved, not graph constructions or integer-feasibility witnesses. Shared marginals are fractional: this is not a complete common integral column/adjacency search. **Higher-edge-count coverage remains open; these computations cover 196 edges only.**

The new order-independent threshold-activation inequality gives a hand contradiction **65>57** for a specified v5 survivor. It also excludes an infinite above-target family of residual/demand patterns beginning at n=294. These are profile-family exclusions, not whole-order theorems. Fourteen hand certificates overlap the linear rejections and are not counted twice.

## Read and verify

Read [PROOF.md](PROOF.md), [RESULTS.json](RESULTS.json) and [REVIEW_AND_HANDOFF.md](REVIEW_AND_HANDOFF.md). The complete original v5 frontier and demand inputs are preserved here as lossless gzip files with pinned uncompressed hashes. No repository download or old multipart upload is needed for checking.

```sh
python3 -I -B replay.py --verify-only
python3 -I -B replay.py --check --output /absolute/path/to/new-v6-check
```

The default invocation checks integrity only. `--check` runs the full independent integer-certificate checker, branch-tree checker, actual-graph lifts, abstract threshold tests and negative controls in a **new working copy**. It writes fresh logs/reports there, leaving this original package unchanged. Python 3.10+ and its standard library suffice for checking; the recorded environment was CPython 3.13.5. No C++ compiler, optimisation solver or network is required. Keep assertions enabled; do not use `-O`.

`evidence/EXACT_CHECK_REPORT.json` records the full creation-session check: 2,301 base certificates, 4,138 degree-type certificates and 572 exact leaves in 91 closed branch trees. `evidence/FINAL_SURVIVORS.json.gz` and `FINAL_SURVIVOR_POSITIONS.json` preserve the exact remaining cases. The standalone checker verifies their disjoint and complete partition with the rejected cases, and matches expanded survivor states to the frozen v5 input.

## Discovery versus verification

The programs in `exploration/` retain all model builders, bounded searches, initial trials, complete sweeps and export/check code. Numerical discovery uses SciPy `linprog(method='highs')`; it proposes coefficients and branching choices only. No solver status is counted as a proof. Named, integer dual certificates and complete complementary branch trees carry each rejection. `rediscover.py` provides an optional fresh discovery run, with an explicit `--limit` mode for partial trials. Different solver versions may discover different valid certificates or close different bounded trees; preserved exact certificates remain independently checkable.

```sh
python3 -B rediscover.py --output /absolute/path/to/new-trial --limit 10
# Omit --limit for the whole preserved input; SciPy and NumPy required.
```

The checker imports neither discovery builder nor SciPy. Its separately implemented constraint reconstruction was compared against the discovery model for every exported base and typed rejection. Both implementations are nevertheless by ChatGPT/Geeps, not independent research authorship.

## Preservation and limitations

This is a separate v6 checkpoint. The repository baseline read in this session was `00ad1a511971397fcd8a4341b021493c2383252e`. Frozen proofs, previous checkpoints and the governed theorem ledger are unchanged. This README does not itself assert that v6 has been committed remotely; see [PUBLICATION_STATUS.json](PUBLICATION_STATUS.json) for the actual publication status.

Finite graph tests exercise real quasi-edge systems and fractional symmetry averages, but contain no positive-surplus graph. The universal graph-to-model argument and inherited reductions remain mathematical review obligations. The global coefficient `(10-sqrt(2))/14` is unchanged. Paul Lenz directed this work; ChatGPT/Geeps supplied the derivations, software and internal checks.
