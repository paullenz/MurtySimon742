#!/usr/bin/env python3
"""Verify the preserved v6 payload; optionally recheck all exact evidence in a fresh copy.
Verification and --check use Python's standard library only. No SciPy import.
The original package and historical reports are never rewritten by this wrapper.
"""
from __future__ import annotations
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def verify(root:Path)->dict:
    if not __debug__:raise ValueError('Do not use Python -O: regression assertions must remain enabled.')
    manifest=json.loads((root/'MANIFEST.json').read_text())
    entries=manifest['files'];seen=set()
    for item in entries:
        name=item['path'];p=Path(name)
        if p.is_absolute() or '..' in p.parts or name in seen:raise ValueError('Unsafe/duplicate manifest path')
        seen.add(name);f=root/p
        if not f.is_file() or f.is_symlink():raise ValueError('Missing/nonregular payload: '+name)
        raw=f.read_bytes()
        if len(raw)!=item['bytes'] or hashlib.sha256(raw).hexdigest()!=item['sha256']:
            raise ValueError('Payload hash mismatch: '+name)
    actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST.json'}
    if actual!=seen:raise ValueError('Manifest does not cover the exact payload')
    return {'verified_payload_files':len(entries),'every_sha256_matches':True,
            'manifest_sha256':hashlib.sha256((root/'MANIFEST.json').read_bytes()).hexdigest()}

def check(out:Path)->dict:
    if out.exists():raise ValueError('The output directory must not already exist.')
    integrity=verify(ROOT);out.mkdir(parents=True);work=out/'work'
    shutil.copytree(ROOT,work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    env=dict(os.environ);env.pop('PYTHONPATH',None);env.pop('PYTHONOPTIMIZE',None)
    env['PYTHONHASHSEED']='0';env['PYTHONDONTWRITEBYTECODE']='1';jobs=[];begin=time.time()
    for filename,typed in [('check_all.py',None),('test_lift.py','0'),('test_lift.py','1'),('test_threshold_family.py',None),('test_certificate_controls.py',None)]:
        name=filename+('' if typed is None else '.typed'+typed);jobenv=dict(env)
        if typed is not None:jobenv['TEST_TYPED']=typed
        with (out/(name+'.log')).open('w') as log:
            run=subprocess.run([sys.executable,'-B',str(work/'exploration'/filename)],cwd=work,env=jobenv,stdout=log,stderr=subprocess.STDOUT)
        jobs.append({'script':filename,'typed':typed,'exit_code':run.returncode})
        if run.returncode:raise RuntimeError('Check failed; inspect '+str(out/(name+'.log')))
    report=json.loads((work/'evidence/EXACT_CHECK_REPORT.json').read_text())
    expected={'base_rejections':2301,'typed_rejections':4138,'branch_leaves':572,'branch_rejections':91,'overlapping_threshold_checks':14,'final_survivors':388,'final_demand_patterns':167}
    if report['counts']!=expected:raise ValueError('Unexpected exact coverage results')
    result={'all_checks_pass':True,'integrity_before_check':integrity,'jobs':jobs,
            'counts':report['counts'],'seconds':time.time()-begin,
            'solver_used':False,'new_reports_in':str(work/'evidence'),
            'original_package_unchanged':True,'mathematical_status':'candidate; independent external review OPEN'}
    (out/'CHECK_RUN.json').write_text(json.dumps(result,indent=2)+'\n');return result

def main():
    p=argparse.ArgumentParser(description=__doc__)
    modes=p.add_mutually_exclusive_group();modes.add_argument('--verify-only',action='store_true');modes.add_argument('--check',action='store_true')
    p.add_argument('--output',type=Path,help='New directory for --check')
    args=p.parse_args()
    if args.check:
        if args.output is None:p.error('--check requires --output')
        result=check(args.output.resolve())
    else:
        if args.output is not None:p.error('--output is used only with --check')
        result=verify(ROOT)
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
