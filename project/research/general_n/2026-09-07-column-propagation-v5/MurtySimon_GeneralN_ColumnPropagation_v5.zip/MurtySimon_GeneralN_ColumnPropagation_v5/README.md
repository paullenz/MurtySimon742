# General-order column propagation and supplement activation — v5

7 September 2026. **Candidate mathematics; exact arithmetic REPRODUCED; independent mathematical review OPEN.** No completed new order, improved uniform degree coefficient, formal verification or novelty claim.

## Results

The new general supplement-activation inequality accounts for extra outgoing selections forced at supplements by mandatory selections elsewhere. A solver-free corollary excludes an entire retained order-28 row by **78 > 57**, and excludes an infinite family of demand/residual patterns, including all compatible individual-column refinements. These are pattern exclusions, not whole-order theorems.

The finite computation continues exactly the v4 input at **n=28, maximum degree 15, m=196**:

| Stage | Rows remaining |
|---|---:|
| Preserved v4 input | 13,196 |
| Joint column and one-source-row projection | 7,725 |
| After 663 cost certificates and 144 cut certificates | **6,918** |

The remaining rows occupy **830 demand patterns**. All rows, individual option domains, safe source bounds and forced-label sets are stored. The 47 additional direct block certificates are overlapping explanations, not further exclusions.

Start with [PROOF.md](PROOF.md), [RESULTS.json](RESULTS.json), and [REVIEW_AND_HANDOFF.md](REVIEW_AND_HANDOFF.md). [PROVENANCE.json](PROVENANCE.json) pins the upstream inputs and explicitly separates evidence preservation from mathematical certification.

## Verify and replay

Use trusted code and Python with assertions enabled; never use `-O`. Hash verification requires only Python's standard library. Complete arithmetic checking additionally needs **g++ with C++17 and Boost headers**. No SciPy, external optimisation solver or network is used. The preserved environment is recorded in [ENVIRONMENT.json](ENVIRONMENT.json).

From this directory:

```sh
python3 -I -B replay.py --verify-only
python3 -I -B replay.py --smoke --output /absolute/path/to/new-v5-smoke
python3 -I -B replay.py --check --output /absolute/path/to/new-v5-check
python3 -I -B replay.py --replay --output /absolute/path/to/new-v5-replay
```

The default is hash verification only. `--smoke` checks the first 100 rows, every stored activation certificate and the mathematical tests. **It does not check the whole row domain.** `--check` runs the separate implementations over all 13,196 inputs. `--replay` also regenerates the production results and compares their exact bytes before checking them. Each mode uses a fresh copy outside this checkpoint, writes new logs, and leaves historical evidence unchanged. Only the `seconds` field is ignored when comparing newly timed reports. The wrapper supplies the verified sibling source directory explicitly under isolated Python mode.

The original full discovery and full separate checker runs were executed in the creation session. Their logs and exact reports are retained. A wrapper/package test is reported separately in `PACKAGE_TEST_REPORT.json`; its stated scope must not be confused with the full mathematical computation.

## Main files

`exploration/` is the retained development-source directory, not a statement that every program is unfinished. Its current production route is `joint.py` + `row_support.cpp`, then `activation_joint.py`, then `finalize.py`. The separate checking route is `check_joint.py` + `check_row_support.cpp`, and `check_activation.py`. `block_bound.py` records short hand obstructions; `test_mathematics.py` contains the finite falsification/regression tests.

`evidence/FINAL_SURVIVORS.json` is the active frontier. `joint_0_13196.json` accounts for every input row; `activation_named_certificates.json` stores all 807 final rejection certificates by resource names. `CHECK_JOINT_13196.json` and `CHECK_ACTIVATION.json` record their complete separate checks.

The preliminary `propagate.py`, `activation.py`, `row_status.cpp`, their outputs, the 100-row development checks and formal column-count diagnostics remain preserved. Their counts are **not** additional advances or completed graph searches. Temporary process IDs, compiled binaries and interpreter caches are deliberately omitted; source and exact mathematical outputs are retained.

## Remaining obligations

The joint projection permits different source rows to be witnessed by different full column assignments. It has not imposed one common complete adjacency structure, and surviving rows are not graphs. The immediate next step is to couple multiple source rows through common individual columns, then apply label-tail and F-neighbourhood constraints.

This finite pass is **m=196 only**. Above-target edge-count coverage remains OPEN; no deletion-preserves-criticality or unproved monotonicity assumption is made. No full n=28 conclusion or proof through order 1,000 follows.

Both implementations and the internal tests were written by ChatGPT/Geeps under Paul Lenz's direction. Separate code is not independent research authorship or external expert review. The frozen n=25/n=27 candidates and governed theorem ledger are unchanged. The original creation-session GitHub publication status is recorded in PROVENANCE.json; the existence of a ZIP or patch is not a remote commit.
