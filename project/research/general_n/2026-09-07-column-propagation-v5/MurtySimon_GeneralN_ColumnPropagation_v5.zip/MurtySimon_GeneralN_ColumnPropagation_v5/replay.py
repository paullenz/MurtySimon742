#!/usr/bin/env python3
"""Verify frozen evidence or replay in a fresh, isolated working copy.

No network or optimisation package is required. Full checking needs g++ with
C++17 and Boost headers. Never invoke with -O: some preserved programs use
assertions. Fresh reports are not substituted for historical evidence.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
BOOTSTRAP = (
    "import sys,runpy;sys.path.insert(0,sys.argv[1]);"
    "sys.argv=sys.argv[2:];runpy.run_path(sys.argv[0],run_name='__main__')"
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read_manifest() -> dict:
    require(sys.flags.optimize == 0, 'Assertions must remain enabled: do not use -O.')
    data = json.loads((ROOT / 'MANIFEST.json').read_text(encoding='utf-8'))
    require(data.get('schema') == 'murty-simon-file-manifest-v1', 'Unknown manifest schema.')
    seen: set[str] = set()
    for record in data['files']:
        name = record['path']
        path = PurePosixPath(name)
        require(not path.is_absolute() and '..' not in path.parts and bool(path.parts), 'Unsafe path.')
        require(name not in seen and name != 'MANIFEST.json', 'Duplicate or recursive manifest entry.')
        seen.add(name)
        local = ROOT.joinpath(*path.parts)
        require(local.is_file() and not local.is_symlink(), 'Missing or unsafe payload: ' + name)
        require(local.stat().st_size == record['bytes'], 'Byte length mismatch: ' + name)
        require(sha256(local) == record['sha256'], 'SHA-256 mismatch: ' + name)
    return data


def without_seconds(value):
    """Only run-time fields vary; no mathematical/data field is discarded."""
    if isinstance(value, dict):
        return {k: without_seconds(v) for k, v in value.items() if k != 'seconds'}
    if isinstance(value, list):
        return [without_seconds(v) for v in value]
    return value


def compare_report(original: Path, fresh: Path) -> None:
    old = json.loads(original.read_text(encoding='utf-8'))
    new = json.loads(fresh.read_text(encoding='utf-8'))
    require(without_seconds(old) == without_seconds(new), 'Report mismatch: ' + fresh.name)


def run_script(work: Path, name: str, args: list[str], log: Path) -> dict:
    command = [sys.executable, '-I', '-B', '-c', BOOTSTRAP,
               str(work / 'exploration'), str(work / 'exploration' / name), *args]
    start = time.monotonic()
    with log.open('w', encoding='utf-8') as stream:
        completed = subprocess.run(command, cwd=work, stdout=stream,
                                   stderr=subprocess.STDOUT, check=False)
    require(completed.returncode == 0,
            f'{name} failed (exit {completed.returncode}); inspect {log}.')
    return {'script': name, 'arguments': args, 'exit_code': completed.returncode,
            'seconds': time.monotonic() - start, 'log': log.name}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--verify-only', action='store_true', help='Hash verification only (default).')
    group.add_argument('--smoke', action='store_true', help='100-row checks, all activation certificates, and tests.')
    group.add_argument('--check', action='store_true', help='All separate checkers and mathematical tests.')
    group.add_argument('--replay', action='store_true', help='Rerun production discovery, then all checkers.')
    parser.add_argument('--output', type=Path, help='A new directory; never an existing checkpoint.')
    args = parser.parse_args()
    manifest = read_manifest()
    mode = 'replay' if args.replay else 'check' if args.check else 'smoke' if args.smoke else 'verify-only'
    report = {'mode': mode, 'payload_files_verified': len(manifest['files']),
              'every_payload_sha256_matches': True, 'mathematical_review': 'OPEN'}
    if mode == 'verify-only':
        require(args.output is None, '--output is only used for smoke/check/replay.')
        print(json.dumps(report, indent=2))
        return
    require(args.output is not None, 'Use --output with a new directory.')
    output = args.output.expanduser().resolve()
    require(not output.exists(), 'Output already exists; refusing to overwrite it.')
    require(output != ROOT and ROOT not in output.parents, 'Output must be outside the frozen checkpoint.')
    output.mkdir(parents=True)
    work = output / 'working-copy'
    work.mkdir()
    for record in manifest['files']:
        source = ROOT / record['path']
        destination = work / record['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
    shutil.copy2(ROOT / 'MANIFEST.json', work / 'MANIFEST.json')
    logs = output / 'logs'
    logs.mkdir()
    steps: list[dict] = []

    def run(name: str, *arguments: str) -> None:
        steps.append(run_script(work, name, list(arguments), logs / f'{len(steps):02d}_{name}.log'))

    compared: list[str] = []
    if mode == 'replay':
        run('joint.py')
        run('activation_joint.py', '--input', 'joint_0_13196.json')
        run('finalize.py')
        run('block_bound.py')
        for name in ['joint_0_13196.json', 'activation_joint_0.json',
                     'activation_named_certificates.json', 'FINAL_SURVIVORS.json',
                     'block_certificates.json']:
            require(sha256(ROOT / 'evidence' / name) == sha256(work / 'evidence' / name),
                    'Exact discovery reproduction failed: ' + name)
            compared.append(name)
    if mode == 'smoke':
        run('joint.py', '--limit', '100')
        require(sha256(ROOT / 'evidence/joint_0_100.json') == sha256(work / 'evidence/joint_0_100.json'),
                '100-row discovery mismatch.')
        compared.append('joint_0_100.json')
        run('check_joint.py', '--limit', '100')
        joint_report = 'CHECK_JOINT_100.json'
    else:
        run('check_joint.py')
        joint_report = 'CHECK_JOINT_13196.json'
    run('check_activation.py')
    run('test_mathematics.py')
    for name in [joint_report, 'CHECK_ACTIVATION.json', 'MATHEMATICAL_TEST_REPORT.json']:
        compare_report(ROOT / 'evidence' / name, work / 'evidence' / name)
        compared.append(name + ' (ignoring seconds only)')
    # Check exact generated test data, not merely their reported totals.
    for name in ['abstract_activation_systems.json.gz', 'brute_joint_instances.json.gz',
                 'family_small_bases.json']:
        require(sha256(ROOT / 'evidence' / name) == sha256(work / 'evidence' / name),
                'Test-input regeneration mismatch: ' + name)
        compared.append(name)
    # Frozen payload bytes must not have changed while the copy was executed.
    read_manifest()
    report.update(steps=steps, compared=compared, all_requested_checks_pass=True,
                  frozen_checkpoint_unchanged=True,
                  full_input_domain_checked=(mode != 'smoke'))
    (output / 'REPLAY_REPORT.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
