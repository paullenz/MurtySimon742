#!/usr/bin/env python3
"""Build and test the checkpoint ZIP and a strictly additive Git patch.

Uses the frozen manifest, no network, and local temporary repositories only.
The resulting patch adds a new research directory; it does not edit README,
existing proof editions, other checkpoints or the theorem ledger.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
PREFIX = Path('project/research/general_n/2026-09-07-column-propagation-v5')
ARCHIVE_NAME = 'MurtySimon_GeneralN_ColumnPropagation_v5'


def need(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(directory: Path, *arguments: str, data: bytes | None = None) -> bytes:
    return subprocess.run(['git', '-c', 'core.autocrlf=false', *arguments], cwd=directory,
                          input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          check=True).stdout


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='New output directory.')
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('v5_frozen_replay', ROOT / 'replay.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    manifest = module.read_manifest()
    output = args.output.resolve()
    need(not output.exists(), 'Output must be a new directory.')
    output.mkdir(parents=True)
    names = [record['path'] for record in manifest['files']] + ['MANIFEST.json']
    original = {name: (ROOT / name).read_bytes() for name in names}
    archive_path = output / (ARCHIVE_NAME + '.zip')
    with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(names):
            info = zipfile.ZipInfo(ARCHIVE_NAME + '/' + name, (2026, 9, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, original[name], compresslevel=9)
    with zipfile.ZipFile(archive_path) as archive:
        need(archive.testzip() is None, 'ZIP CRC failure.')
        need(set(archive.namelist()) == {ARCHIVE_NAME + '/' + n for n in names}, 'ZIP path mismatch.')
        for name in names:
            need(archive.read(ARCHIVE_NAME + '/' + name) == original[name], 'ZIP byte mismatch: ' + name)
    with tempfile.TemporaryDirectory(prefix='murty-v5-patch-') as tmp:
        source = Path(tmp) / 'source'
        target = Path(tmp) / 'target'
        source.mkdir(); target.mkdir()
        git(source, 'init', '-q'); git(target, 'init', '-q')
        for name, data in original.items():
            path = source / PREFIX / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        git(source, 'add', '--', str(PREFIX))
        patch = git(source, 'diff', '--cached', '--binary', '--full-index', '--no-ext-diff')
        need(bool(patch), 'Empty additive patch.')
        git(target, 'apply', '--check', '-', data=patch)
        git(target, 'apply', '-', data=patch)
        restored = target / PREFIX
        found = {p.relative_to(restored).as_posix() for p in restored.rglob('*') if p.is_file()}
        need(found == set(names), 'Applied patch file set mismatch.')
        for name, data in original.items():
            need((restored / name).read_bytes() == data, 'Applied patch byte mismatch: ' + name)
        paths = git(source, 'diff', '--cached', '--name-only').decode().splitlines()
        need(all(p.startswith(PREFIX.as_posix() + '/') for p in paths), 'Patch escaped additive directory.')
    compressed_patch = gzip.compress(patch, compresslevel=9, mtime=0)
    patch_path = output / 'MurtySimon_ColumnPropagation_v5_Additive.patch.gz'
    patch_path.write_bytes(compressed_patch)
    need(gzip.decompress(compressed_patch) == patch, 'Compressed patch round-trip failed.')
    report = {'payload_files': len(manifest['files']), 'manifest_files': 1,
              'every_zip_member_matches_original_bytes': True,
              'patch_applied_in_separate_local_repository': True,
              'every_patch_file_matches_original_bytes': True,
              'patch_scope': PREFIX.as_posix(), 'github_commit_created': False,
              'manifest_sha256': digest((ROOT / 'MANIFEST.json').read_bytes()),
              'artifacts': [{'filename': p.name, 'bytes': p.stat().st_size,
                             'sha256': digest(p.read_bytes())} for p in [archive_path, patch_path]]}
    (output / 'DISTRIBUTION_REPORT.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
