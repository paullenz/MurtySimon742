"""Counts symmetric column refinements; not a graph enumeration."""
import json,time
from pathlib import Path
from functools import lru_cache
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]
@lru_cache(None)
def group_poly(opts,n,maxr,maxz):
    dp={(0,0,0):1}
    for d,R,z in opts:
        nxt=dict(dp)
        for (used,rr,zz),val in dp.items():
            for k in range(1,n-used+1):
                r1=rr+k*R;z1=zz+k*z
                if r1>maxr or z1>maxz:break
                key=(used+k,r1,z1);nxt[key]=nxt.get(key,0)+val
        dp=nxt
    return {(rr,zz):val for (u,rr,zz),val in dp.items() if u==n}
def count(s,rho,state):
    r=sum(rho);slack=sum(s)-r-2
    groups=Counter((s0,tuple(tuple(op) for op in opts),forced) for s0,opts,forced in zip(s,state['domains'],state['forced']))
    dp={(0,0):1}
    for (s0,opts,forced),n in groups.items():
        poly=group_poly(opts,n,r,slack);nxt={}
        for (rr,zz),v in dp.items():
            for (r1,z1),w in poly.items():
                if rr+r1<=r and zz+z1<=slack:
                    key=(rr+r1,zz+z1);nxt[key]=nxt.get(key,0)+v*w
        dp=nxt
    return dp.get((r,slack),0)
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--input',default='joint_0_100.json');args=p.parse_args()
    data=json.loads((ROOT/'evidence'/args.input).read_text());demands=json.loads((ROOT/'dependencies/n28_demands.json').read_text());rows=json.loads((ROOT/'dependencies/n28_projected_survivors.json').read_text());ans=[];start=time.time()
    for rec in data:
        if rec['result']['kind']!='survivor':continue
        row=rows[rec['index']];s=demands[row[0]]['s'];n=count(s,row[2:],rec['result']);ans.append([rec['index'],n])
    print('rows',len(ans),'columns',sum(x[1] for x in ans),'max',max(x[1] for x in ans), 'seconds',time.time()-start)
    print(ans[:30]);(ROOT/'evidence'/('column_counts_'+args.input)).write_text(json.dumps(ans)+'\n')
