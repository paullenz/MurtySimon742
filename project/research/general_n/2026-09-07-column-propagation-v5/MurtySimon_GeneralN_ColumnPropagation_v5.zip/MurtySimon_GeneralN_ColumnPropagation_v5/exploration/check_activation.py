#!/usr/bin/env python3
"""Rebuild the activation network by named resources and check exact duals.
No discovery, matching or minimum-cost program is imported.
"""
from collections import Counter
from math import lcm
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
def require(value,message):
    if not value:raise ValueError(message)

def named_network(s,h,state):
    a=len(s);b=len(h);S=sum(s);c=state['c'];F=state['forced'];D=[min(v[0] for v in options) for options in state['domains']]
    lower=[]
    for u in range(b):
        compulsory=[i for i in range(a) if F[i]>>u&1]
        lower.append(max([len(compulsory),S-sum(c)+c[u]]+[D[i]+1-h[u] for i in compulsory]))
    admissible=[];incoming=[set() for _ in h];label_sources=[set() for _ in s];pairset=set()
    for i in range(a):
        for u in range(b):
            q0=max(1,lower[u],D[i]+1-h[u])
            if h[u]<s[i] or q0>c[u]:continue
            for w in range(b):
                if w==u or F[i]>>w&1 or D[i]>h[u]+h[w] or q0>h[w]+c[w]+1:continue
                admissible.append((i,u,w));incoming[w].add(u);label_sources[i].add(u);pairset.add(frozenset((u,w)))
    p=[max(0,min(len(incoming[w]),b-1,h[w]+b-a-1)) for w in range(b)]
    U=min(sum(c),sum(p),len(pairset),sum(map(len,label_sources)));scale=lcm(*(v for v in p if v))
    arcs=[];source=('source',);sink=('sink',)
    for i in range(a):arcs.append((source,('label',i),s[i],0))
    for i in range(a):
        for u in sorted(label_sources[i]):arcs.append((('label',i),('source-label',i,u),1,0))
    used=set()
    for i,u,w in admissible:
        if p[w]>0:
            weight=max(0,lower[u]-lower[w]-h[w]-1)*(scale//p[w])
            arcs.append((('source-label',i,u),('ordered-pair',u,w),1,weight));used.add((u,w))
    for u,w in sorted(used):arcs.append((('ordered-pair',u,w),('supplement',w),1,0))
    for w in range(b):
        if p[w]:arcs.append((('supplement',w),sink,p[w],0))
    nodes={source,sink}|{x for arc in arcs for x in arc[:2]}
    return arcs,nodes,S,scale*(U-sum(lower)),scale

def verify(s,h,state,cert):
    arcs,nodes,required,budget,scale=named_network(s,h,state)
    if cert['kind']=='activation_cost':
        potential={tuple(node):value for node,value in cert['potential_by_node']}
        require(len(potential)==len(cert['potential_by_node']) and set(potential)==nodes,'Potential node domain mismatch')
        require(all(type(v)is int for v in potential.values()),'Noninteger potential')
        lower=required*(potential['sink',]-potential['source',])
        for u,v,k,cost in arcs:lower-=k*max(0,potential[v]-potential[u]-cost)
        require(lower==cert['cost_lower'] and lower>budget==cert['budget'] and scale==cert['scale'],'No strict exact cost contradiction')
    elif cert['kind']=='activation_cut':
        cut={tuple(node) for node in cert['cut_by_node']}
        require(('source',) in cut and ('sink',) not in cut and cut<=nodes,'Invalid cut')
        cap=sum(k for u,v,k,cost in arcs if u in cut and v not in cut)
        require(cap==cert['cut_capacity']<required==cert['required'],'No strict exact cut contradiction')
    else:raise ValueError('Not a rejection certificate')

def block(s,h,cert):
    level=cert['h'];p=sum(x==level for x in s);Z=[x for x in h if x>=level];W=[x for x in h if x<level]
    require(level>0 and len(Z)==level and p==cert['labels'] and p>0,'Not a forced block')
    ell=len(h)-len(s)-1
    if not W:require(cert['kind']=='no_supplement','Wrong empty-supplement certificate');return
    cap=max(W)+ell
    if cap<=0:require(cert['kind']=='no_incoming_capacity','Wrong incoming certificate');return
    amount=p*len(Z);needed=(amount+cap-1)//cap
    if cert['kind']=='incoming_count':
        require(needed==cert['needed']>len(W)==cert['available'],'Not an incoming contradiction');return
    lo=amount+needed*max(0,p-max(W)-1);hi=sum(h)+ell*len(h)
    require(cert['kind']=='activation_block' and lo==cert['selected_lower']>hi==cert['selected_upper'],'Not a block contradiction')
    require((max(W),cap,amount,needed)==(cert['outside_rho_max'],cert['incoming_cap'],cert['mandatory_arcs'],cert['required_supplements']),'Wrong block parameters')

def main():
    demands=json.loads((ROOT/'dependencies/n28_demands.json').read_text());rows=json.loads((ROOT/'dependencies/n28_projected_survivors.json').read_text());states=json.loads((ROOT/'evidence/joint_0_13196.json').read_text());certificates=json.loads((ROOT/'evidence/activation_named_certificates.json').read_text());frontier=json.loads((ROOT/'evidence/FINAL_SURVIVORS.json').read_text());counts=Counter()
    expected={x['index'] for x in states if x['result']['kind']=='survivor'};seen=set()
    for rec in certificates:
        i=rec['index'];require(i in expected and i not in seen,'Certificate coverage');seen.add(i);row=rows[i];verify(demands[row[0]]['s'],row[2:],states[i]['result'],rec['certificate']);counts[rec['certificate']['kind']]+=1
    left={x['index'] for x in frontier};require(len(left)==len(frontier) and not left&seen and left|seen==expected,'Survivor/rejection partition fails')
    for rec in frontier:
        i=rec['index'];require(rec['row']==rows[i] and rec['state']==states[i]['result'],'Changed survivor')
    blocks=json.loads((ROOT/'evidence/block_certificates.json').read_text())
    for rec in blocks:
        i=rec['index'];row=rows[i];block(demands[row[0]]['s'],row[2:],rec['certificate']);require(i not in left,'A block exclusion survived')
    # Negative controls: these modifications must fail exact validation.
    import copy
    cc=next(rec for rec in certificates if rec['certificate']['kind']=='activation_cost' and rec['certificate']['budget']>=0)
    bad=copy.deepcopy(cc['certificate']);bad['potential_by_node']=[[node,0] for node,val in bad['potential_by_node']]
    i=cc['index'];row=rows[i]
    try:verify(demands[row[0]]['s'],row[2:],states[i]['result'],bad)
    except ValueError:pass
    else:raise ValueError('Forged zero-potential certificate accepted')
    cut=next(rec for rec in certificates if rec['certificate']['kind']=='activation_cut');bad=copy.deepcopy(cut['certificate']);bad['cut_by_node']=[node for node in bad['cut_by_node'] if node!=['source']]
    i=cut['index'];row=rows[i]
    try:verify(demands[row[0]]['s'],row[2:],states[i]['result'],bad)
    except ValueError:pass
    else:raise ValueError('Forged cut accepted')
    out=dict(counts);out.update(joint_survivors=len(expected),final_survivors=len(left),patterns=len({rows[i][0] for i in left}),block_certificates=len(blocks),negative_controls_rejected=2,all_checks_pass=True)
    (ROOT/'evidence/CHECK_ACTIVATION.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
