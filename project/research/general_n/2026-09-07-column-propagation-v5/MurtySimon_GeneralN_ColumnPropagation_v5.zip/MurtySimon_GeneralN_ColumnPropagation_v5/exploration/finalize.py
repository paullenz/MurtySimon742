"""Prepare named-resource certificates and an explicit retained frontier."""
import json
from pathlib import Path
from activation import prepare
ROOT=Path(__file__).resolve().parents[1]
rows=json.loads((ROOT/'dependencies/n28_projected_survivors.json').read_text());demands=json.loads((ROOT/'dependencies/n28_demands.json').read_text());states=json.loads((ROOT/'evidence/joint_0_13196.json').read_text());data=json.loads((ROOT/'evidence/activation_joint_0.json').read_text());certs=[];left=[]
for rec in data:
 i=rec['index'];cert=rec['certificate'];row=rows[i];state=states[i]['result']
 if cert['kind']=='survivor':left.append({'index':i,'row':row,'state':state});continue
 N=prepare(demands[row[0]]['s'],row[2:],state);cert=dict(cert)
 if cert['kind']=='activation_cost':cert['potential_by_node']=[[name,val] for name,val in zip(N['nodes'],cert.pop('potential'))]
 else:cert['cut_by_node']=[N['nodes'][j] for j in cert.pop('cut')]
 certs.append({'index':i,'certificate':cert})
(ROOT/'evidence/activation_named_certificates.json').write_text(json.dumps(certs,separators=(',',':'))+'\n')
(ROOT/'evidence/FINAL_SURVIVORS.json').write_text(json.dumps(left,separators=(',',':'))+'\n')
print('saved',len(certs),'named rejections;',len(left),'explicit survivors')
