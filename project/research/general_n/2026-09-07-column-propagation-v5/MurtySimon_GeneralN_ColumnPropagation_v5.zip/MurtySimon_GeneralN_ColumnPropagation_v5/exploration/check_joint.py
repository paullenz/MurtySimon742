#!/usr/bin/env python3
"""Separate complete replay of the finite column-domain projection.
Uses set-valued two-sum products, lower-bound flow for mandatory matchings,
and a separately compiled joint generating-polynomial implementation.
It imports no discovery module. Both implementations share the mathematical
premises and were written by the same assistant, not independent researchers.
"""
from pathlib import Path
from collections import deque,Counter
from functools import lru_cache
import ctypes,json,subprocess,tempfile,time
ROOT=Path(__file__).resolve().parents[1]
_BUILD=tempfile.TemporaryDirectory(prefix='murty-check-')
_DLL=Path(_BUILD.name)/'row.so'
subprocess.run(['g++','-std=c++17','-O3','-shared','-fPIC',str(ROOT/'exploration/check_row_support.cpp'),'-o',str(_DLL)],check=True)
_LIB=ctypes.CDLL(str(_DLL));_FN=_LIB.row_support;_P=ctypes.POINTER(ctypes.c_int)
_FN.argtypes=[_P,ctypes.c_int,_P,_P,ctypes.c_int];_FN.restype=ctypes.c_int

def row_product(s,h,t,options,c,forced):
    values=[0,len(s),len(h),t]+list(s)+list(h)+list(c)+list(forced)
    sizes=[len(x) for x in options]
    for choices in options:
        values.append(len(choices))
        for choice in choices:values.extend(choice)
    input_=(ctypes.c_int*len(values))(*values);m=(ctypes.c_int*len(h))();f=(ctypes.c_int*sum(sizes))()
    if _FN(input_,len(values),m,f,1):raise ValueError('Checker polynomial failed')
    cols=[];p=0
    for size in sizes:cols.append(list(f[p:p+size]));p+=size
    return list(m),cols

def maxflow(n,edges,source,sink):
    g=[[] for _ in range(n)]
    for u,v,k in edges:
        if k:
            g[u].append([v,k,len(g[v])]);g[v].append([u,0,len(g[u])-1])
    value=0
    while True:
        level=[-1]*n;level[source]=0;queue=deque([source])
        while queue:
            u=queue.popleft()
            for v,k,j in g[u]:
                if k and level[v]<0:level[v]=level[u]+1;queue.append(v)
        if level[sink]<0:return value
        current=[0]*n
        def push(u,amount):
            if u==sink:return amount
            while current[u]<len(g[u]):
                e=g[u][current[u]];v,k,j=e
                if k and level[v]==level[u]+1:
                    sent=push(v,min(amount,k))
                    if sent:e[1]-=sent;g[v][j][1]+=sent;return sent
                current[u]+=1
            return 0
        while True:
            v=push(source,10**9)
            if not v:break
            value+=v

def matching(adj,required,q,b):
    a=len(adj);source=a+b;sink=source+1;n=sink+1
    arcs=[];balance=[0]*n
    def edge(u,v,low,high):
        if low>high:raise ValueError('Invalid circulation')
        arcs.append((u,v,high-low));balance[u]-=low;balance[v]+=low
    must=set(required)
    for i,allowed in enumerate(adj):
        edge(source,i,int(i in must),1)
        for w in range(b):
            if (allowed>>w)&1:edge(i,a+w,0,1)
    for w in range(b):edge(a+w,sink,0,1)
    edge(sink,source,q,q);S=n;T=n+1
    demand=0
    for u,val in enumerate(balance):
        if val>0:arcs.append((S,u,val));demand+=val
        elif val<0:arcs.append((u,T,-val))
    return maxflow(n+2,arcs,S,T)==demand

@lru_cache(maxsize=20000)
def sum_product(options,targetR,targetZ):
    a=len(options);prefix=[{(0,0)}]
    for choices in options:
        prefix.append({(r+R,z+Z) for r,z in prefix[-1] for d,R,Z in choices if r+R<=targetR and z+Z<=targetZ})
    if (targetR,targetZ) not in prefix[-1]:return None
    suffix=[set() for _ in range(a+1)];suffix[a]={(0,0)}
    for i in range(a-1,-1,-1):
        suffix[i]={(r+R,z+Z) for r,z in suffix[i+1] for d,R,Z in options[i] if r+R<=targetR and z+Z<=targetZ}
    kept=[]
    for i,choices in enumerate(options):
        kept.append(tuple((d,R,Z) for d,R,Z in choices if any((targetR-R-r,targetZ-Z-z) in suffix[i+1] for r,z in prefix[i])))
    return tuple(kept)

def verify_row(s,h,t=1,maxd=10):
    a=len(s);b=len(h);r=sum(h);S=sum(s);z=S-r-2*t
    if z<0:return None
    options=[]
    for demand in s:
        if demand:options.append(tuple((d,d-demand,0) for d in range(demand,maxd+1) if d-demand<=b))
        else:options.append(tuple((d,R,R-d) for d in range(maxd+1) for R in range(d,min(b,d+z)+1)))
    c=tuple(min(a-v,b-1) for v in h);forced=[0]*a
    while True:
        old=tuple(options),c,tuple(forced)
        lower=[sum((f>>u)&1 for f in forced) for u in range(b)]
        if any(x>cap for x,cap in zip(lower,c)):return None
        def suppliers(i,d,u,q=None):
            if h[u]<s[i]:return 0
            required=max(1,lower[u],d-h[u]+1)
            q=required if q is None else q
            if q<required or q>c[u]:return 0
            return sum(1<<w for w in range(b) if w!=u and not (forced[i]>>w)&1 and h[u]+h[w]>=d and h[w]+c[w]>=q-1)
        filtered=[]
        for i,choices in enumerate(options):
            cache={d:sum(1<<u for u in range(b) if suppliers(i,d,u)) for d,R,Z in choices}
            keep=tuple((d,R,Z) for d,R,Z in choices if cache[d].bit_count()>=s[i] and forced[i]&~cache[d]==0 and R+forced[i].bit_count()<=b)
            if not keep:return None
            filtered.append(keep)
        options=sum_product(tuple(filtered),r,z)
        if options is None:return None
        for i,choices in enumerate(options):
            E=0
            for d in set(op[0] for op in choices):
                E |= sum(1<<u for u in range(b) if suppliers(i,d,u))
            if E.bit_count()==s[i] and s[i]>0:forced[i]|=E
        lower=[sum((f>>u)&1 for f in forced) for u in range(b)]
        nc=[]
        for u in range(b):
            required=[i for i in range(a) if (forced[i]>>u)&1]
            cap=None
            for q in reversed(range(lower[u],c[u]+1)):
                if q==0:cap=0;break
                adj=[suppliers(i,min(op[0] for op in options[i]),u,q) for i in range(a)]
                if matching(adj,required,q,b):cap=q;break
            if cap is None:return None
            nc.append(cap)
        c=tuple(nc)
        if sum(c)<S:return None
        masks,flags=row_product(s,h,t,options,c,forced)
        if any(not mask for mask in masks):return None
        c=tuple(mask.bit_length()-1 for mask in masks)
        if sum(c)<S:return None
        options=tuple(tuple(opt for opt,yes in zip(choices,flag) if yes) for choices,flag in zip(options,flags))
        if any(not op for op in options):return None
        if (tuple(options),c,tuple(forced))==old:break
    E=[];pairsets=[]
    for i,choices in enumerate(options):
        d=min(op[0] for op in choices);pairs=set();mask=0
        for u in range(b):
            ws=suppliers(i,d,u)
            if ws:mask|=1<<u
            for w in range(b):
                if (ws>>w)&1:pairs.add((min(u,w),max(u,w)))
        E.append(mask);pairsets.append(pairs)
    edges=[];source=a+b;sink=source+1
    for i in range(a):
        edges.append((source,i,s[i]))
        for u in range(b):
            if (E[i]>>u)&1:edges.append((i,a+u,1))
    for u,cap in enumerate(c):edges.append((a+u,sink,cap))
    if maxflow(sink+1,edges,source,sink)<S:return None
    # Incrementally build actual pair sets; no bit-position encoding is shared.
    unions=[set() for _ in range(1<<a)];sums=[0]*(1<<a)
    for mask in range(1,1<<a):
        i=mask.bit_length()-1;prev=mask^(1<<i)
        unions[mask]=unions[prev]|pairsets[i];sums[mask]=sums[prev]+s[i]
        if sums[mask]>len(unions[mask]):return None
    return {'domains':[[list(op) for op in opts] for opts in options],'c':list(c),'forced':forced}

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int,default=0);args=p.parse_args()
    data=json.loads((ROOT/'evidence/joint_0_13196.json').read_text());rows=json.loads((ROOT/'dependencies/n28_projected_survivors.json').read_text());demands=json.loads((ROOT/'dependencies/n28_demands.json').read_text())
    if args.limit:data=data[:args.limit]
    assert [v['index'] for v in data]==list(range(len(data)))
    start=time.time();counts=Counter()
    for rec in data:
        i=rec['index'];row=rows[i];s=demands[row[0]]['s'];got=verify_row(s,row[2:]);expected=rec['result']
        assert (got is not None)==(expected['kind']=='survivor'),('disposition',i,expected)
        if got is not None:
            for key in got:assert got[key]==expected[key],('state',i,key)
        counts['checked']+=1;counts['survivors' if got is not None else 'rejected']+=1
        if i%100==0:print(i,dict(counts),round(time.time()-start,2),flush=True)
    out=dict(counts);out.update(all_dispositions_match=True,all_survivor_domains_caps_and_forced_sets_match=True,seconds=time.time()-start)
    (ROOT/'evidence'/f'CHECK_JOINT_{len(data)}.json').write_text(json.dumps(out,indent=2)+'\n');print(out,flush=True)
if __name__=='__main__':main()
