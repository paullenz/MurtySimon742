// Exact three-state row/column projection. No solver is used.
// Input: nRecords; then index,a,b,t; s[a],rho[b],caps[b],forced[a];
// and for each label: optionCount followed by (d,R,slackContribution).
#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
struct Opt{int d,R,z;};
struct Record{int id,a,b,t,r,slack; vector<int>s,rho,c;vector<uint64_t>forced;vector<vector<Opt>>dom;};
static bool feasible(const Record& P,int u,int q){
 int a=P.a,b=P.b,r=P.r,sl=P.slack,rr=P.rho[u], missing=a-rr-q;
 if(missing<0)return false;
 int nres=rr+1,nz=sl+1,ns=q+1,size=ns*nres*nz;
 auto at=[&](int j,int k,int z){return (j*nres+k)*nz+z;};
 uint64_t limit=(uint64_t(1)<<(r+1))-1;
 vector<uint64_t> dp(size),nx(size);dp[0]=1;
 for(int i=0;i<a;i++){
  fill(nx.begin(),nx.end(),0);
  bool mandated=P.forced[i]&(uint64_t(1)<<u);
  int suppleR=-1;
  for(int w=0;w<b;w++)if(w!=u && !(P.forced[i]&(uint64_t(1)<<w)) && P.rho[w]+P.c[w]>=q-1)
   suppleR=max(suppleR,P.rho[w]);
  for(auto op:P.dom[i]){
   if(op.R>r || op.z>sl)continue;
   bool S=q>0 && P.s[i]<=rr && op.d<=rr+q-1 && suppleR>=0 && op.d<=rr+suppleR && op.R<=b-max(1,P.s[i]);
   bool R=!mandated && op.R>=1;
   bool N=!mandated && op.d<=a-q-1 && op.R<=b-P.s[i]-1;
   for(int j=0;j<=min(q,i);j++)for(int k=0;k<=min(rr,i-j);k++){
    int absent=i-j-k;if(absent>missing)continue;
    for(int z=0;z+op.z<=sl;z++){
     uint64_t v=(dp[at(j,k,z)]<<op.R)&limit;if(!v)continue;
     if(S && j<q)nx[at(j+1,k,z+op.z)]|=v;
     if(R && k<rr)nx[at(j,k+1,z+op.z)]|=v;
     if(N && absent<missing)nx[at(j,k,z+op.z)]|=v;
    }
   }
  }
  dp.swap(nx);
 }
 return (dp[at(q,rr,sl)]>>r)&1;
}
int main(int argc,char**argv){
 if(argc!=3){cerr<<"input output required\n";return 2;}ifstream in(argv[1]);ofstream out(argv[2]);
 if(!in||!out)return 2;int count;in>>count;auto start=chrono::steady_clock::now();long long changed=0,reject=0,tests=0;
 for(int z=0;z<count;z++){
  Record P;in>>P.id>>P.a>>P.b>>P.t;P.s.resize(P.a);P.rho.resize(P.b);P.c.resize(P.b);P.forced.resize(P.a);P.dom.resize(P.a);
  int S=0;for(auto&v:P.s){in>>v;S+=v;}P.r=0;for(auto&v:P.rho){in>>v;P.r+=v;}for(auto&v:P.c)in>>v;for(auto&v:P.forced)in>>v;
  P.slack=S-P.r-2*P.t;if(P.r>=63||P.slack<0||P.b>=64)return 3;
  for(auto&vv:P.dom){int n;in>>n;for(int k=0;k<n;k++){Opt op;in>>op.d>>op.R>>op.z;vv.push_back(op);}}
  if(!in)return 4;vector<int> masks(P.b),cap(P.b);bool any=false;int sumcap=0;
  for(int u=0;u<P.b;u++){
   // Reuse only under an explicitly verified transposition symmetry.
   int twin=-1;
   for(int v=0;v<u;v++)if(P.rho[v]==P.rho[u]&&P.c[v]==P.c[u]){
    bool same=true;for(auto f:P.forced)if(bool(f&(uint64_t(1)<<u))!=bool(f&(uint64_t(1)<<v)))same=false;
    if(same){twin=v;break;}
   }
   if(twin>=0){masks[u]=masks[twin];cap[u]=cap[twin];}
   else{
    cap[u]=-1;
    for(int q=0;q<=P.c[u];q++){tests++;if(feasible(P,u,q)){masks[u]|=1<<q;cap[u]=q;}}
   }
   if(cap[u]!=P.c[u])any=true;sumcap+=cap[u];
  }
  if(any)changed++;
  if(sumcap<S || *min_element(cap.begin(),cap.end())<0)reject++;
  out<<P.id;for(int mask:masks)out<<' '<<mask;out<<'\n';
  if(z%500==0)cerr<<z<<" changed="<<changed<<" total-reject="<<reject<<" q-tests="<<tests<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<'\n';
 }
 cerr<<"DONE records="<<count<<" changed="<<changed<<" total-reject="<<reject<<" q-tests="<<tests<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<'\n';
}
