from pathlib import Path
import ctypes,subprocess
ROOT=Path(__file__).resolve().parents[1]
DLL=ROOT/'exploration/librow_support.so'
if not DLL.exists():
    subprocess.run(['g++','-std=c++17','-O3','-shared','-fPIC',str(ROOT/'exploration/row_support.cpp'),'-o',str(DLL)],check=True)
LIB=ctypes.CDLL(str(DLL));FN=LIB.row_support;PI=ctypes.POINTER(ctypes.c_int)
FN.argtypes=[PI,ctypes.c_int,PI,PI,ctypes.c_int];FN.restype=ctypes.c_int

def refine(s,rho,t,dom,c,forced,detailed=True):
    vals=[0,len(s),len(rho),t]+list(s)+list(rho)+list(c)+list(forced)
    for opts in dom:
        vals.append(len(opts))
        for op in opts:vals.extend(op)
    total=sum(map(len,dom));data=(ctypes.c_int*len(vals))(*vals);masks=(ctypes.c_int*len(rho))();flags=(ctypes.c_int*total)()
    result=FN(data,len(vals),masks,flags,int(detailed))
    if result:raise ValueError(f'Row support domain/error code {result}')
    out=[];k=0
    for opts in dom:out.append(list(flags[k:k+len(opts)]));k+=len(opts)
    return list(masks),out
