#!/usr/bin/env python3
"""Finite falsification and algorithm tests; never a substitute for the proofs."""
from pathlib import Path
from itertools import combinations,product
from collections import Counter
from fractions import Fraction
from functools import lru_cache
import gzip,json,random,time
from row_interface import refine
ROOT=Path(__file__).resolve().parents[1]
def need(x,msg):
    if not x:raise ValueError(msg)

def charged(arcs,q,rho,lower,pbar):
    lhs=Fraction(sum(q)-sum(lower));rhs=Fraction()
    for u,w in arcs:
        need(pbar[w]>0,'Positive incoming capacity missing')
        rhs+=Fraction(max(0,lower[u]-1-rho[w]-lower[w]),pbar[w])
    need(lhs>=rhs,'Supplement-activation inequality failed')
    return rhs>0

@lru_cache(None)
def critical(g):
    n=len(g);full=(1<<n)-1
    def d2(adj):
        for u in range(n):
            reach=(1<<u)|adj[u]
            for w in range(n):
                if adj[u]>>w&1:reach|=adj[w]
            if reach!=full:return False
        return not all(x.bit_count()==n-1 for x in adj)
    need(d2(g),'Input not diameter two')
    for u,v in combinations(range(n),2):
        if g[u]>>v&1:
            h=list(g);h[u]^=1<<v;h[v]^=1<<u;need(not d2(h),'Input not edge critical')
    return True

def actual_tests(rng):
    data=json.loads(gzip.decompress((ROOT/'dependencies/v3_actual_graph_instances.json.gz').read_bytes()));counts=Counter();graphs=set()
    for rec in data:
        g=rec['g'];n=len(g);v=rec['root'];critical(tuple(g));graphs.add(tuple(g));full=(1<<n)-1
        H=[full^g[u]^(1<<u) for u in range(n)];need(H[v].bit_count()==min(x.bit_count() for x in H),'Root not minimum degree')
        A=[i for i in range(n) if H[v]>>i&1];B=[i for i in range(n) if i!=v and not H[v]>>i&1];a=len(A);b=len(B)
        T=rec['triples'];sel=set();pairs=set();q=[0]*b;p=[0]*b;x=[0]*a
        for u,i,w in T:
            need(H[B[u]]>>A[i]&1 and H[B[u]]|H[A[i]]==full^(1<<B[w]),'Invalid quasi-edge')
            need((u,i) not in sel and tuple(sorted((u,w))) not in pairs,'Repeated selected resource')
            sel.add((u,i));pairs.add(tuple(sorted((u,w))));q[u]+=1;p[w]+=1;x[i]+=1
        need(pairs=={(u,w) for u,w in combinations(range(b),2) if not H[B[u]]>>B[w]&1},'Missing selected pair')
        R=[sum(bool(H[B[u]]>>A[i]&1) and (u,i) not in sel for u in range(b)) for i in range(a)]
        rho=[sum(bool(H[B[u]]>>A[i]&1) and (u,i) not in sel for i in range(a)) for u in range(b)]
        d=[sum(g[i]>>j&1 for j in A) for i in A];s=[max(0,di-ri) for di,ri in zip(d,R)]
        need(s==rec['s'] and rho==rec['rho'] and q==rec['q'],'Saved reconstruction differs')
        for u in range(b):
            for i in range(a):
                if not H[B[u]]>>A[i]&1:
                    need(d[i]<=a-q[u]-1,'Missing-neighbour bound failed');counts['missing_neighbour_checks']+=1
                    if q[u]:counts['nonzero_source_missing_neighbour_checks']+=1
        pbar=[rho[u]+b-a-1 for u in range(b)];need(all(pp<=cap for pp,cap in zip(p,pbar)),'Incoming degree bound failed')
        F=[sum(1<<u for u in range(b) if rho[u]>=s0) if s0>0 and sum(v>=s0 for v in rho)==s0 else 0 for s0 in s]
        lower=[sum((f>>u)&1 for f in F) for u in range(b)];need(all(lo<=qu for lo,qu in zip(lower,q)),'Forced sources not compulsory')
        subset=[]
        for i in range(a):subset.extend((u,w) for u,ii,w in T if ii==i and sum(1 for uu,jj,ww in T if jj==i and (uu,ww)<(u,w))<s[i])
        need(len(subset)==sum(s),'Demand subset size')
        counts['forced_activation_checks']+=1;counts['positive_forced_activation_checks']+=charged(subset,q,rho,lower,pbar)
        for _ in range(4):
            lo=[qu if rng.randrange(2) else 0 for qu in q]
            counts['mixed_lower_bound_activation_checks']+=1
            counts['positive_mixed_lower_bound_activation_checks']+=charged([(u,w) for u,i,w in T],q,rho,lo,pbar)
        opts=[[(di,ri,ri+si-di)] for di,ri,si in zip(d,R,s)]
        if sum(rho)<63 and a<=20 and b<=30 and sum(op[0][2] for op in opts)<=20:
            caps=[min(a-rr,b-1) for rr in rho];masks,flags=refine(s,rho,rec['t'],opts,caps,F)
            need(all(mask>>qu&1 for mask,qu in zip(masks,q)) and all(all(ff) for ff in flags),'Actual row lost from joint projection')
            counts['singleton_actual_joint_checks']+=1
        else:counts['outside_compiled_joint_domain']+=1
        counts['systems']+=1;counts['positive_surplus_systems']+=rec['t']>0;counts['selected_incidences']+=len(T)
        counts['zero_demand_selected_labels']+=sum(si==0 and xi>0 for si,xi in zip(s,x))
    counts['distinct_labelled_graphs']=len(graphs)
    return dict(counts)

def abstract_activation(rng):
    examples=[];counts=Counter()
    for trial in range(2000):
        b=rng.randrange(4,18);arcs=[]
        for u,w in combinations(range(b),2):
            if rng.random()<0.65:
                if rng.randrange(2):u,w=w,u
                arcs.append((u,w))
        q=[0]*b;p=[0]*b
        for u,w in arcs:q[u]+=1;p[w]+=1
        rho=[max([0]+[q[u]-1-q[w] for u,v in arcs if v==w]) for w in range(b)]
        lower=[qu if rng.randrange(2) else rng.randrange(qu+1) for qu in q]
        pbar=[pp+rng.randrange(3) for pp in p]
        subset=[arc for arc in arcs if rng.random()<0.85]
        counts['checks']+=1;counts['positive_cost_checks']+=charged(subset,q,rho,lower,pbar)
        examples.append({'b':b,'arcs':arcs,'subset':subset,'rho':rho,'q_lower':lower,'p_upper':pbar})
    (ROOT/'evidence/abstract_activation_systems.json.gz').write_bytes(gzip.compress((json.dumps(examples,separators=(',',':'))+'\n').encode(),mtime=0))
    # Counterexample to omitting the normalization by incoming capacity.
    arcs=[(u,w) for u in range(4) for w in [4,6,7,8]]+[(4,w) for w in [6,7,8]]
    q=[4]*4+[3,0,0,0,0];rho=[0]*6+[3,3,3];lo=[4]*4+[0]*5;pbar=[0]*4+[4,0,5,5,5]
    charged(arcs,q,rho,lo,pbar)
    raw=sum(max(0,lo[u]-1-rho[w]-lo[w]) for u,w in arcs)
    need(raw==12>sum(q)-sum(lo)==3,'Normalization negative control')
    counts['normalization_negative_control_rejected']=1
    return dict(counts)

def family(p):
    a=2*p;b=2*p+3;k=min(15,p-1);d=[max(0,16-p)]+[2]*k+[1]*(p-1-k)+[3]*p
    R=[max(6,p-10)]+[1]*k+[0]*(p-1-k)+[1]*p
    s=[max(0,x-y) for x,y in zip(d,R)];rho=[1]*(2*p+1)+[2,2]
    return d,R,s,rho

def havel(d):
    rem=[(dd,i) for i,dd in enumerate(d)];edges=[]
    while True:
        rem.sort(reverse=True)
        if not rem or rem[0][0]==0:break
        deg,u=rem.pop(0);need(deg<=len(rem),'Not graphical')
        for k in range(deg):
            dd,v=rem[k];need(dd>0,'Not graphical');rem[k]=(dd-1,v);edges.append([min(u,v),max(u,v)])
    need(len(set(map(tuple,edges)))==len(edges),'Repeated graph edge')
    return sorted(edges)

def family_tests():
    counts=Counter();bases=[]
    for p in range(10,10001):
        lhs=2*p+(p-2)*((2*p+2)//3);rhs=6*p+11
        need(lhs>rhs and 2*p*p-16*p-33>0,'Family activation failure');counts['parameter_regressions']+=1
    for p in range(10,501):
        d,R,s,rho=family(p);a=2*p;b=2*p+3;r=sum(rho)
        need(s==[0]+[1]*(p-1)+[2]*p,'Family demand');need(sum(R)==r==2*p+5 and sum(d)==2*r+4,'Family ledger')
        need(sum(s)-r-4==p-10,'Family zero-demand slack')
        if p<16:
            edges=havel(d);bases.append({'p':p,'F_edges':edges})
        else:
            cycle=list(range(p,2*p))+list(range(1,16));edges=[tuple(sorted((cycle[i],cycle[(i+1)%len(cycle)]))) for i in range(len(cycle))]
            edges.extend((p+i,p+i+8) for i in range(8));edges.extend((j,p+j) for j in range(16,p))
        degrees=[0]*a
        for i,j in edges:need(i!=j,'Loop');degrees[i]+=1;degrees[j]+=1
        need(degrees==d and len(set(map(tuple,edges)))==len(edges),'Family F construction failed')
        # Separate residual bipartite realization; not a realization of G.
        red=[(b-2,0),(b-2,1),(b-1,0),(b-1,2)]
        labels=list(range(p,2*p))+list(range(3,min(15,p-1)+1))+[0]*(R[0]-2)
        need(len(labels)==b-2,'Residual construction count')
        red.extend(enumerate(labels));rows=[0]*b;cols=[0]*a
        for u,i in red:rows[u]+=1;cols[i]+=1
        need(rows==rho and cols==R,'Residual construction degrees')
        counts['ledger_and_separate_graphicality_checks']+=1
    (ROOT/'evidence/family_small_bases.json').write_text(json.dumps(bases,separators=(',',':'))+'\n')
    return dict(counts)

def brute_joint(s,h,t,options,c,F):
    a=len(s);b=len(h);r=sum(h);z=sum(s)-r-2*t;masks=[0]*b;support=[[set() for i in range(a)] for u in range(b)]
    for choice in product(*(range(len(op)) for op in options)):
        cols=[options[i][j] for i,j in enumerate(choice)]
        if sum(x[1] for x in cols)!=r or sum(x[2] for x in cols)!=z:continue
        for u in range(b):
            for q in range(c[u]+1):
                if q+h[u]>a:continue
                okay=False
                for selected in combinations(range(a),q):
                    J=set(selected)
                    if any((F[i]>>u&1) and i not in J for i in range(a)):continue
                    if any(s[i]>h[u] or cols[i][0]>h[u]+q-1 or cols[i][1]>b-max(1,s[i]) or not any(w!=u and not F[i]>>w&1 and h[w]+c[w]>=q-1 and h[u]+h[w]>=cols[i][0] for w in range(b)) for i in J):continue
                    others=[i for i in range(a) if i not in J]
                    for residual in combinations(others,h[u]):
                        K=set(residual)
                        if any(cols[i][1]<1 for i in K):continue
                        if any(cols[i][0]>a-q-1 or cols[i][1]>b-s[i]-1 for i in others if i not in K):continue
                        okay=True;break
                    if okay:break
                if okay:
                    masks[u]|=1<<q
                    for i,j in enumerate(choice):support[u][i].add(j)
    if any(not mask for mask in masks):return masks,None
    flags=[[all(j in support[u][i] for u in range(b)) for j in range(len(options[i]))] for i in range(a)]
    return masks,flags

def joint_tests(rng):
    counts=Counter();examples=[]
    for trial in range(400):
        a=rng.randrange(2,5);b=rng.randrange(2,7);s=[rng.randrange(min(a,3)) for _ in range(a)];h=[rng.randrange(a+1) for _ in range(b)];r=sum(h);sl=rng.randrange(3)
        if (sum(s)-r-sl)%2:sl+=1
        t=(sum(s)-r-sl)//2;options=[]
        for si in s:
            allopts=[(d,R,R+si-d) for d in range(a) for R in range(b+1) if max(0,d-R)==si and 0<=R+si-d<=sl]
            options.append(rng.sample(allopts,min(len(allopts),rng.randrange(1,4))))
        c=[rng.randrange(min(a-rh,b-1)+1) for rh in h];F=[sum(1<<u for u in range(b) if rng.random()<0.04) for _ in s]
        expected,ff=brute_joint(s,h,t,options,c,F);actual,af=refine(s,h,t,options,c,F)
        need(expected==actual,'Joint masks differ from brute force')
        if ff is not None:need([[int(x) for x in row] for row in ff]==af,'Joint option support differs from brute force');counts['nonempty_all_row_domains']+=1
        counts['bruteforce_instances']+=1
        examples.append({'s':s,'rho':h,'t':t,'domains':options,'caps':c,'forced':F,'masks':actual})
    (ROOT/'evidence/brute_joint_instances.json.gz').write_bytes(gzip.compress((json.dumps(examples,separators=(',',':'))+'\n').encode(),mtime=0))
    return dict(counts)

def main():
    rng=random.Random(2026090705);start=time.time()
    report={'family':family_tests(),'joint_projection':joint_tests(rng),'abstract_activation':abstract_activation(rng),'actual_graphs':actual_tests(rng),'all_tests_pass':True,'seed':2026090705,'seconds':time.time()-start,'limits':'Same-assistant finite falsification tests. Abstract examples are not critical graphs; separate degree-sequence realizations do not construct G; no positive-surplus actual graph is claimed.'}
    (ROOT/'evidence/MATHEMATICAL_TEST_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
