#!/usr/bin/env python3
"""Exact supplement-activation min-cost network for column domains.
An exact potential is a certificate; solver status alone is never used.
"""
from __future__ import annotations
from math import lcm
from heapq import heappush,heappop
from collections import Counter
from pathlib import Path
import json,time
ROOT=Path(__file__).resolve().parents[1]

def bits(x):
    while x:
        z=x&-x;yield z.bit_length()-1;x-=z

def prepare(s,rho,state):
    a=len(s);b=len(rho);dom=state['domains'];c=state['c'];forced=state['forced']
    dmin=[min(opt[0] for opt in v) for v in dom]
    low=[sum(bool(mask&(1<<u)) for mask in forced) for u in range(b)]
    for u in range(b):
        low[u]=max([low[u],sum(s)-sum(c)+c[u]]+[dmin[i]-rho[u]+1 for i in range(a) if forced[i]&(1<<u)])
    triples=[];E=[0]*a;incoming=[set() for _ in rho];pairs=set()
    for i in range(a):
        for u in range(b):
            if s[i]>rho[u]:continue
            q0=max(1,low[u],dmin[i]-rho[u]+1)
            if q0>c[u]:continue
            for w in range(b):
                if w==u or forced[i]&(1<<w):continue
                if dmin[i]>rho[u]+rho[w] or rho[w]+c[w]<q0-1:continue
                triples.append((i,u,w));E[i]|=1<<u;incoming[w].add(u);pairs.add(tuple(sorted((u,w))))
    pbar=[max(0,min(b-1,rho[w]+b-a-1,len(incoming[w]))) for w in range(b)]
    U=min(sum(c),sum(pbar),len(pairs),sum(mask.bit_count() for mask in E))
    scale=lcm(*(x for x in pbar if x))
    edges=[];names=[('source',)]+[('label',i) for i in range(a)]
    ids={x:i for i,x in enumerate(names)}
    def node(name):
        if name not in ids:ids[name]=len(names);names.append(name)
        return ids[name]
    # Label->source-label keeps per-source-label incidence at most one.
    for i in range(a):edges.append((0,node(('label',i)),s[i],0))
    for i in range(a):
        for u in bits(E[i]):edges.append((node(('label',i)),node(('source-label',i,u)),1,0))
    for i,u,w in triples:
        if not pbar[w]:continue
        cost=max(0,low[u]-1-rho[w]-low[w])*(scale//pbar[w])
        edges.append((node(('source-label',i,u)),node(('ordered-pair',u,w)),1,cost))
    for u,w in sorted(set((u,w) for i,u,w in triples if pbar[w])):
        edges.append((node(('ordered-pair',u,w)),node(('supplement',w)),1,0))
    sink=node(('sink',))
    for w,k in enumerate(pbar):
        if k:edges.append((node(('supplement',w)),sink,k,0))
    return {'nodes':names,'edges':edges,'source':0,'sink':sink,'flow':sum(s),'scale':scale,
            'q_lower':low,'p_upper':pbar,'Q_upper':U,'budget':scale*(U-sum(low))}

def solve(N):
    n=len(N['nodes']);s=N['source'];t=N['sink'];g=[[] for _ in range(n)]
    for u,v,k,c in N['edges']:
        g[u].append([v,k,c,len(g[v])]);g[v].append([u,0,-c,len(g[u])-1])
    flow=cost=0;pot=[0]*n
    while flow<N['flow']:
        inf=10**100;dist=[inf]*n;dist[s]=0;prev=[None]*n;heap=[(0,s)]
        while heap:
            du,u=heappop(heap)
            if du!=dist[u]:continue
            for j,e in enumerate(g[u]):
                v,k,c,rev=e
                if not k:continue
                weight=c+pot[u]-pot[v]
                assert weight>=0
                d=du+weight
                if d<dist[v]:dist[v]=d;prev[v]=(u,j);heappush(heap,(d,v))
        if dist[t]==inf:
            cut=[i for i,x in enumerate(dist) if x<inf]
            cap=sum(k for u,v,k,c in N['edges'] if u in cut and v not in cut)
            assert cap==flow
            return {'kind':'activation_cut','cut':cut,'cut_capacity':cap,'required':N['flow']}
        far=max(x for x in dist if x<inf)
        pot=[v+(d if d<inf else far) for v,d in zip(pot,dist)]
        v=t;amount=N['flow']-flow
        while v!=s:u,j=prev[v];amount=min(amount,g[u][j][1]);v=u
        v=t
        while v!=s:
            u,j=prev[v];e=g[u][j];cost+=amount*e[2];e[1]-=amount;g[v][e[3]][1]+=amount;v=u
        flow+=amount
    lower=N['flow']*(pot[t]-pot[s])-sum(k*max(0,pot[v]-pot[u]-c) for u,v,k,c in N['edges'])
    assert lower==cost,(lower,cost)
    if lower>N['budget']:
        return {'kind':'activation_cost','potential':pot,'cost_lower':lower,'budget':N['budget'],'scale':N['scale']}
    return {'kind':'survivor','cost_lower':lower,'budget':N['budget'],'scale':N['scale']}

def verify(N,cert):
    if cert['kind']=='activation_cut':
        W=set(cert['cut']); assert N['source'] in W and N['sink'] not in W
        cap=sum(k for u,v,k,c in N['edges'] if u in W and v not in W)
        assert cap==cert['cut_capacity']<N['flow']==cert['required']
    elif cert['kind']=='activation_cost':
        p=cert['potential'];assert len(p)==len(N['nodes']) and all(type(x)is int for x in p)
        lower=N['flow']*(p[N['sink']]-p[N['source']])-sum(k*max(0,p[v]-p[u]-c) for u,v,k,c in N['edges'])
        assert lower==cert['cost_lower']>N['budget']==cert['budget'] and N['scale']==cert['scale']
    else:raise ValueError('Not a rejection')

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--input',default='propagation_0_13196.json');p.add_argument('--limit',type=int,default=0);args=p.parse_args()
    demands=json.loads((ROOT/'dependencies/n28_demands.json').read_text()); rows=json.loads((ROOT/'dependencies/n28_projected_survivors.json').read_text()); data=json.loads((ROOT/'evidence'/args.input).read_text())
    result=[];counts=Counter();start=time.time()
    for j,rec in enumerate(data[:args.limit] if args.limit else data):
        if rec['result']['kind']!='survivor':continue
        row=rows[rec['index']];s=demands[row[0]]['s'];N=prepare(s,row[2:],rec['result']);cert=solve(N)
        if cert['kind']!='survivor':verify(N,cert)
        result.append({'index':rec['index'],'certificate':cert});counts[cert['kind']]+=1
        if j%100==0:print(j,dict(counts),round(time.time()-start,2),flush=True)
    (ROOT/'evidence'/('activation_joint_'+str(args.limit)+'.json')).write_text(json.dumps(result,separators=(',',':'))+'\n')
    print(dict(counts),time.time()-start,flush=True)
if __name__=='__main__':main()
