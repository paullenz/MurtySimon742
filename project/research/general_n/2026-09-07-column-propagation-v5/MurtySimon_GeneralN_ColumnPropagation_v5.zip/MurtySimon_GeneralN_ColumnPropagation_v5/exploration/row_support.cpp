// Exact three-state row/column projection. No solver is used.
// Input: nRecords; then index,a,b,t; s[a],rho[b],caps[b],forced[a];
// and for each label: optionCount followed by (d,R,slackContribution).
#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
struct Opt{int d,R,z;};
struct Record{int id,a,b,t,r,slack; vector<int>s,rho,c;vector<uint64_t>forced;vector<vector<Opt>>dom;};
static bool feasible(const Record& P,int u,int q,int pin=-1,int choice=-1){
 int a=P.a,b=P.b,r=P.r,sl=P.slack,rr=P.rho[u], missing=a-rr-q;
 if(missing<0)return false;
 int nres=rr+1,nz=sl+1,ns=q+1,size=ns*nres*nz;
 auto at=[&](int j,int k,int z){return (j*nres+k)*nz+z;};
 uint64_t limit=(uint64_t(1)<<(r+1))-1;
 vector<uint64_t> dp(size),nx(size);dp[0]=1;
 for(int i=0;i<a;i++){
  fill(nx.begin(),nx.end(),0);
  bool mandated=P.forced[i]&(uint64_t(1)<<u);
  int suppleR=-1;
  for(int w=0;w<b;w++)if(w!=u && !(P.forced[i]&(uint64_t(1)<<w)) && P.rho[w]+P.c[w]>=q-1)
   suppleR=max(suppleR,P.rho[w]);
  for(int oi=0;oi<(int)P.dom[i].size();oi++){
   if(i==pin && oi!=choice)continue;
   auto op=P.dom[i][oi];
   if(op.R>r || op.z>sl)continue;
   bool S=q>0 && P.s[i]<=rr && op.d<=rr+q-1 && suppleR>=0 && op.d<=rr+suppleR && op.R<=b-max(1,P.s[i]);
   bool R=!mandated && op.R>=1;
   bool N=!mandated && op.d<=a-q-1 && op.R<=b-P.s[i]-1;
   for(int j=0;j<=min(q,i);j++)for(int k=0;k<=min(rr,i-j);k++){
    int absent=i-j-k;if(absent>missing)continue;
    for(int z=0;z+op.z<=sl;z++){
     uint64_t v=(dp[at(j,k,z)]<<op.R)&limit;if(!v)continue;
     if(S && j<q)nx[at(j+1,k,z+op.z)]|=v;
     if(R && k<rr)nx[at(j,k+1,z+op.z)]|=v;
     if(N && absent<missing)nx[at(j,k,z+op.z)]|=v;
    }
   }
  }
  dp.swap(nx);
 }
 return (dp[at(q,rr,sl)]>>r)&1;
}

extern "C" int row_support(const int* data,int length,int* masks,int* flags,int detailed){
 int pos=0;auto take=[&](){if(pos>=length)throw 1;return data[pos++];};
 try {
 Record P;P.id=take();P.a=take();P.b=take();P.t=take();P.s.resize(P.a);P.rho.resize(P.b);P.c.resize(P.b);P.forced.resize(P.a);P.dom.resize(P.a);
 if(P.a<1 || P.a>20 || P.b<1 || P.b>30)return -2;
 int S=0;for(auto&v:P.s){v=take();S+=v;}P.r=0;for(auto&v:P.rho){v=take();P.r+=v;}for(auto&v:P.c)v=take();for(auto&v:P.forced)v=take();
 P.slack=S-P.r-2*P.t;if(P.r>=63 || P.slack<0 || P.slack>20)return -3;
 vector<int> off(P.a+1);for(int i=0;i<P.a;i++){int n=take();off[i+1]=off[i]+n;for(int k=0;k<n;k++)P.dom[i].push_back({take(),take(),take()});}
 if(pos!=length)return -4;
 vector<int> reps;
 for(int u=0;u<P.b;u++){
  int twin=-1;
  for(int v:reps)if(P.rho[v]==P.rho[u] && P.c[v]==P.c[u]){
   bool same=true;for(auto f:P.forced)if(bool(f&(uint64_t(1)<<u))!=bool(f&(uint64_t(1)<<v)))same=false;
   if(same){twin=v;break;}
  }
  if(twin>=0)masks[u]=masks[twin];else{reps.push_back(u);masks[u]=0;for(int q=0;q<=P.c[u];q++)if(feasible(P,u,q))masks[u]|=1<<q;}
 }
 for(int k=0;k<off.back();k++)flags[k]=1;
 if(!detailed)return 0;
 for(int u=0;u<P.b;u++)if(!masks[u])return 0;
 for(int i=0;i<P.a;i++){
  int twin=-1;
  for(int j=0;j<i;j++)if(P.s[i]==P.s[j] && P.forced[i]==P.forced[j] && P.dom[i].size()==P.dom[j].size()){
   bool same=true;for(int k=0;k<(int)P.dom[i].size();k++)if(P.dom[i][k].d!=P.dom[j][k].d || P.dom[i][k].R!=P.dom[j][k].R || P.dom[i][k].z!=P.dom[j][k].z)same=false;
   if(same){twin=j;break;}
  }
  if(twin>=0){for(int k=0;k<(int)P.dom[i].size();k++)flags[off[i]+k]=flags[off[twin]+k];continue;}
  for(int k=0;k<(int)P.dom[i].size();k++)for(int u:reps){
   bool ok=false;for(int q=0;q<=P.c[u]&&!ok;q++)if(masks[u]&(1<<q))ok=feasible(P,u,q,i,k);
   if(!ok){flags[off[i]+k]=0;break;}
  }
 }
 return 0;
 }catch(...){return -5;}
}
