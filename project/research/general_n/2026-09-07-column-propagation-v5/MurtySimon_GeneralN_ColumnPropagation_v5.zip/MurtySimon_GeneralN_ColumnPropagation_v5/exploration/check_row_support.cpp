// Separately written checker: a packed two-sum generating polynomial.
// No discovery code is imported. This uses the same proved recurrence,
// not an independent mathematical argument.
#include <boost/multiprecision/cpp_int.hpp>
#include <vector>
#include <algorithm>
#include <cstdint>
using boost::multiprecision::cpp_int;
using namespace std;
struct Choice{int d,R,z;};
struct Input{int a,b,t,r,sl;vector<int>s,h,cap,forced;vector<vector<Choice>>choices;};
static bool coefficient(const Input& x,int u,int q,int selected_label=-1,int selected_choice=-1){
 const int rho=x.h[u],missing=x.a-rho-q;if(missing<0)return false;
 int stride=rho+1,states=(q+1)*stride;
 vector<cpp_int> P(states),V(states);P[0]=1;
 vector<cpp_int> guard(x.r+1);
 for(int R=0;R<=x.r;R++)for(int z=0;z<=x.sl;z++)guard[R]|=((cpp_int(1)<<(x.r-R+1))-1)<<(64*z);
 cpp_int endmask=(cpp_int(1)<<(64*(x.sl+1)))-1;
 for(int i=0;i<x.a;i++){
  for(auto &v:V)v=0;
  bool forced=(x.forced[i]>>u)&1;
  for(int S=0;S<=q;S++)for(int Rrow=0;Rrow<=rho;Rrow++){
   int gone=i-S-Rrow;
   if(gone<0||gone>missing||P[S*stride+Rrow]==0)continue;
   for(int j=0;j<(int)x.choices[i].size();j++){
    if(i==selected_label && j!=selected_choice)continue;
    auto c=x.choices[i][j];if(c.R>x.r||c.z>x.sl)continue;
    cpp_int value=((P[S*stride+Rrow]&guard[c.R])<<(c.R+64*c.z))&endmask;
    if(value==0)continue;
    if(!forced){
     if(Rrow<rho && c.R>0)V[S*stride+Rrow+1]|=value;
     if(gone<missing && c.d+q<=x.a-1 && c.R+x.s[i]<x.b)V[S*stride+Rrow]|=value;
    }
    if(S>=q || x.s[i]>rho || c.d>rho+q-1 || c.R+max(1,x.s[i])>x.b)continue;
    bool witness=false;
    for(int w=0;w<x.b;w++)if(w!=u && !((x.forced[i]>>w)&1) && x.h[w]+x.cap[w]>=q-1 && rho+x.h[w]>=c.d){witness=true;break;}
    if(witness)V[(S+1)*stride+Rrow]|=value;
   }
  }
  P.swap(V);
 }
 return bool((P[q*stride+rho]>>(x.r+64*x.sl))&1);
}
extern "C" int row_support(const int* data,int n,int* masks,int* flags,int detailed){
 int p=0;auto read=[&](){if(p>=n)throw 1;return data[p++];};
 try{
 (void)read();Input x;x.a=read();x.b=read();x.t=read();if(x.a<=0||x.a>20||x.b<=0||x.b>30)return -2;
 x.s.resize(x.a);x.h.resize(x.b);x.cap.resize(x.b);x.forced.resize(x.a);x.choices.resize(x.a);
 int S=0;x.r=0;for(int &v:x.s){v=read();S+=v;}for(int &v:x.h){v=read();x.r+=v;}for(int &v:x.cap)v=read();for(int &v:x.forced)v=read();
 x.sl=S-x.r-2*x.t;if(x.r<0||x.r>=63||x.sl<0||x.sl>20)return -3;
 vector<int> start(x.a+1);
 for(int i=0;i<x.a;i++){int k=read();start[i+1]=start[i]+k;while(k--)x.choices[i].push_back({read(),read(),read()});}
 if(p!=n)return -4;
 // Symmetry is checked explicitly, not inferred merely from repeated degrees.
 vector<int> roots;
 for(int u=0;u<x.b;u++){
  int representative=-1;
  for(int v:roots)if(x.h[u]==x.h[v] && x.cap[u]==x.cap[v]){
   bool same=true;for(int f:x.forced)if(((f>>u)&1)!=((f>>v)&1))same=false;
   if(same){representative=v;break;}
  }
  masks[u]=0;
  if(representative>=0)masks[u]=masks[representative];else{roots.push_back(u);for(int q=x.cap[u];q>=0;q--)if(coefficient(x,u,q))masks[u]|=1<<q;}
 }
 fill(flags,flags+start.back(),1);
 if(!detailed)return 0;for(int u=0;u<x.b;u++)if(!masks[u])return 0;
 for(int i=0;i<x.a;i++){
  int copy=-1;
  for(int j=0;j<i;j++)if(x.s[i]==x.s[j]&&x.forced[i]==x.forced[j]&&x.choices[i].size()==x.choices[j].size()){
   bool same=true;for(int k=0;k<(int)x.choices[i].size();k++){auto A=x.choices[i][k],B=x.choices[j][k];if(A.d!=B.d||A.R!=B.R||A.z!=B.z)same=false;}
   if(same){copy=j;break;}
  }
  if(copy>=0){for(int k=0;k<(int)x.choices[i].size();k++)flags[start[i]+k]=flags[start[copy]+k];continue;}
  for(int k=0;k<(int)x.choices[i].size();k++)for(int u:roots){
   bool found=false;
   for(int q=x.cap[u];q>=0&&!found;q--)if((masks[u]>>q)&1)found=coefficient(x,u,q,i,k);
   if(!found){flags[start[i]+k]=0;break;}
  }
 }
 return 0;
 }catch(...){return -5;}
}
