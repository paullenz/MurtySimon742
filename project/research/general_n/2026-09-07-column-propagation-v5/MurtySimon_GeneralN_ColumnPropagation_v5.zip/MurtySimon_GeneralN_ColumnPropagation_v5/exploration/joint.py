#!/usr/bin/env python3
"""Candidate column-domain propagation, exact integer necessary conditions.
No surviving state is a graph. No external solver is imported.
"""
from __future__ import annotations
import json,sys,time
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]

def bits(x):
    while x:
        p=x & -x; yield p.bit_length()-1; x-=p

def column_sum_filter(dom,r,slack):
    """Multichoice (residual sum, zero-demand slack) support, via bitsets."""
    a=len(dom); limit=(1<<(r+1))-1
    pref=[[1]+[0]*slack]
    for opts in dom:
        prev=pref[-1]; nxt=[0]*(slack+1)
        for d,R,z in opts:
            for k in range(z,slack+1):nxt[k]|=(prev[k-z]<<R)&limit
        pref.append(nxt)
    if not (pref[-1][slack]>>r)&1:return None
    suffix=[[0]*(slack+1) for _ in range(a+1)]; suffix[a][0]=1
    for i in range(a-1,-1,-1):
        for d,R,z in dom[i]:
            for k in range(z,slack+1):suffix[i][k]|=(suffix[i+1][k-z]<<R)&limit
    reverse=[[sum(1<<(r-j) for j in bits(mask)) for mask in row] for row in suffix]
    ans=[]
    for i,opts in enumerate(dom):
        ans.append(tuple((d,R,z) for d,R,z in opts if any(pref[i][k] & (reverse[i+1][slack-z-k]>>R) for k in range(slack-z+1))))
    return ans

def maximum_matching(adj,required=(),stop=None):
    """Match required labels first, then extend; preserves mandatory coverage."""
    m={}
    def aug(i,seen):
        for w in bits(adj[i]&~seen[0]):
            seen[0]|=1<<w
            if w not in m or aug(m[w],seen):m[w]=i;return True
        return False
    for i in required:
        if not aug(i,[0]):return -1
    count=len(m)
    if stop is not None and count>=stop:return count
    mandatory=set(required)
    for i in sorted((i for i in range(len(adj)) if i not in mandatory), key=lambda i:adj[i].bit_count()):
        if aug(i,[0]):count+=1
        if stop is not None and count>=stop:return count
    return count

def pair_hall(s,pair_masks):
    unions=[0]*(1<<len(s)); sums=[0]*len(unions)
    for mask in range(1,len(unions)):
        one=mask&-mask; i=one.bit_length()-1; other=mask^one
        sums[mask]=sums[other]+s[i]; unions[mask]=unions[other]|pair_masks[i]
        if sums[mask]>unions[mask].bit_count():return mask
    return None

def source_hall(s,E,c):
    # Exhaustive source subsets are unnecessary: expand capacities to clone
    # vertices and match s_i copies of each label. Clones must not allow
    # multiple uses of one source for a given label, so use integral flow.
    a=len(s);b=len(c);N=a+b+2;T=N-1;adj=[[] for _ in range(N)]
    def add(u,v,k):
        adj[u].append([v,k,len(adj[v])]);adj[v].append([u,0,len(adj[u])-1])
    for i,v in enumerate(s):
        add(0,i+1,v)
        for u in bits(E[i]):add(i+1,a+1+u,1)
    for u,k in enumerate(c):add(a+1+u,T,k)
    total=0
    while True:
        parent=[None]*N;parent[0]=(-1,-1);q=[0]
        for u in q:
            if parent[T] is not None:break
            for j,e in enumerate(adj[u]):
                if e[1] and parent[e[0]] is None:parent[e[0]]=(u,j);q.append(e[0])
        if parent[T] is None:break
        v=T;amount=10**9
        while v: u,j=parent[v];amount=min(amount,adj[u][j][1]);v=u
        v=T
        while v:
            u,j=parent[v];e=adj[u][j];e[1]-=amount;adj[v][e[2]][1]+=amount;v=u
        total+=amount
    return total>=sum(s)

def propagate(s,rho,t=1,dmax=None,do_hall=True,initial=None,joint=True):
    a=len(s);b=len(rho);r=sum(rho);S=sum(s);slack=S-r-2*t
    if dmax is None:dmax=a-1
    if slack<0:return {'kind':'negative_slack'}
    dom=[]
    for s0 in s:
        if s0:
            opts=tuple((d,d-s0,0) for d in range(s0,dmax+1) if d-s0<=b)
        else:
            opts=tuple((d,d+z,z) for d in range(dmax+1) for z in range(min(slack,b-d)+1))
        dom.append(opts)
    c=tuple(min(a-r,b-1) for r in rho);forced=[0]*a;rounds=0
    if initial is not None:
        dom=[tuple(tuple(opt) for opt in opts) for opts in initial["domains"]];c=tuple(initial["c"]);forced=list(initial["forced"])
    pair_idx={}
    for u in range(b):
        for w in range(u+1,b):pair_idx[u,w]=len(pair_idx)
    while True:
        rounds+=1;previous=(tuple(dom),c,tuple(forced))
        f=[sum(bool(mask&(1<<u)) for mask in forced) for u in range(b)]
        if any(f[u]>c[u] for u in range(b)):return {'kind':'forced_cap','round':rounds}
        def allowed(i,d,q_override=None,u_override=None):
            out=[0]*b
            for u in range(b):
                if u_override is not None and u!=u_override:continue
                if s[i]>rho[u]:continue
                q=max(1,f[u],d-rho[u]+1) if q_override is None else q_override
                if q<max(1,f[u],d-rho[u]+1) or q>c[u]:continue
                for w in range(b):
                    if w!=u and not forced[i]&(1<<w) and d<=rho[u]+rho[w] and rho[w]+c[w]>=q-1:
                        out[u]|=1<<w
            return out
        E=[];newdom=[]
        for i,opts in enumerate(dom):
            union=0;surv=[];cache={}
            for d,R,z in opts:
                if d not in cache:
                    out=allowed(i,d);cache[d]=sum(1<<u for u,v in enumerate(out) if v)
                mask=cache[d]
                if mask.bit_count()>=s[i] and forced[i]&mask==forced[i] and R<=b-forced[i].bit_count():
                    surv.append((d,R,z));union|=mask
            if not surv:return {'kind':'label_domain','label':i,'round':rounds}
            newdom.append(tuple(surv));E.append(union)
        dom=column_sum_filter(newdom,r,slack)
        if dom is None:return {'kind':'column_sum','round':rounds}
        # Recompute unions after exact column sums remove options.
        E=[0]*a
        for i,opts in enumerate(dom):
            for d in set(x[0] for x in opts):
                E[i]|=sum(1<<u for u,v in enumerate(allowed(i,d)) if v)
            if E[i].bit_count()==s[i] and s[i]>0:forced[i]|=E[i]
        # Forced sets changed: use their updated lower bounds, old caps.
        f=[sum(bool(mask&(1<<u)) for mask in forced) for u in range(b)]
        newc=[]
        for u in range(b):
            mandatory=[i for i in range(a) if forced[i]&(1<<u)]
            cap=None
            for q in range(c[u],f[u]-1,-1):
                if q==0:cap=0;break
                adjacency=[allowed(i,min(d for d,R,z in dom[i]),q,u)[u] for i in range(a)]
                if maximum_matching(adjacency,mandatory,q)>=q:cap=q;break
            if cap is None:return {'kind':'source_matching','source':u,'round':rounds}
            newc.append(cap)
        c=tuple(newc)
        if sum(c)<S:return {'kind':'total_source','round':rounds}
        if joint:
            from row_interface import refine
            masks,flags=refine(s,rho,t,dom,c,forced)
            if not all(masks):return {'kind':'joint_empty_row','round':rounds}
            c=tuple(mask.bit_length()-1 for mask in masks)
            if sum(c)<S:return {'kind':'joint_total_source','round':rounds}
            dom=[tuple(opt for opt,keep in zip(opts,ff) if keep) for opts,ff in zip(dom,flags)]
            if not all(dom):return {'kind':'joint_empty_column','round':rounds}
        if (tuple(dom),c,tuple(forced))==previous:break
        if rounds>100:raise RuntimeError('Nonconvergence')
    # Test total and subset pair resources using optimistic minimum degrees.
    E=[0]*a;pair_masks=[]
    for i in range(a):
        out=allowed(i,min(d for d,R,z in dom[i]));pairs=0
        for u,mask in enumerate(out):
            if mask:E[i]|=1<<u
            for w in bits(mask):pairs|=1<<pair_idx[min(u,w),max(u,w)]
        pair_masks.append(pairs)
    if do_hall:
        if not source_hall(s,E,c):return {'kind':'source_hall','round':rounds}
        bad=pair_hall(s,pair_masks)
        if bad is not None:return {'kind':'pair_hall','mask':bad,'round':rounds}
    return {'kind':'survivor','round':rounds,'domains':dom,'c':c,'forced':forced}

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int,default=0);p.add_argument('--offset',type=int,default=0);args=p.parse_args()
    demands=json.loads((ROOT/'dependencies/n28_demands.json').read_text())
    rows=json.loads((ROOT/'dependencies/n28_projected_survivors.json').read_text())
    todo=rows[args.offset:args.offset+args.limit] if args.limit else rows[args.offset:]
    result=[];counts=Counter();start=time.time()
    for z,row in enumerate(todo):
        s=demands[row[0]]['s'];ans=propagate(s,row[2:],dmax=10)
        result.append({'index':z+args.offset,'result':ans});counts[ans['kind']]+=1
        if z%100==0:print(z,dict(counts),round(time.time()-start,2),flush=True)
    target=ROOT/'evidence'/f'joint_{args.offset}_{len(todo)}.json'
    target.write_text(json.dumps(result,separators=(',',':'))+'\n')
    print(dict(counts),'seconds',time.time()-start,flush=True)
if __name__=='__main__':main()
