"""A solver-free forced-block / supplement-activation bound."""
from collections import Counter
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
def obstruction(s,rho):
    a=len(s);b=len(rho);ell=b-a-1;r=sum(rho);U=r+ell*b
    for h,p in Counter(s).items():
        if h<=0:continue
        Z=[u for u,x in enumerate(rho) if x>=h]
        if len(Z)!=h:continue
        outside=[x for x in rho if x<h]
        if not outside:return {'h':h,'labels':p,'kind':'no_supplement'}
        c=max(outside);Pcap=c+ell;arcs=h*p
        if Pcap<=0:return {'h':h,'labels':p,'kind':'no_incoming_capacity'}
        need=(arcs+Pcap-1)//Pcap
        if need>len(outside):return {'h':h,'labels':p,'kind':'incoming_count','needed':need,'available':len(outside)}
        lower=arcs+need*max(0,p-1-c)
        if lower>U:return {'h':h,'labels':p,'kind':'activation_block','outside_rho_max':c,'incoming_cap':Pcap,'mandatory_arcs':arcs,'required_supplements':need,'selected_lower':lower,'selected_upper':U}
    return None
if __name__=='__main__':
 d=json.loads((ROOT/'dependencies/n28_demands.json').read_text());rows=json.loads((ROOT/'dependencies/n28_projected_survivors.json').read_text());out=[]
 for i,row in enumerate(rows):
  cert=obstruction(d[row[0]]['s'],row[2:])
  if cert:out.append({'index':i,'certificate':cert})
 (ROOT/'evidence/block_certificates.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
 print('direct block exclusions',len(out),Counter(x['certificate']['kind'] for x in out));print('row0',out[0])
