#!/usr/bin/env python3
"""Verify preserved bytes, then run both arithmetic implementations from scratch."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import subprocess
import sys
import tempfile


def check_files(root: Path) -> int:
    inventory = json.loads((root / 'MANIFEST.json').read_text())
    seen = set()
    for row in inventory['files']:
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or str(relative) != row['path']:
            raise ValueError('Unsafe or noncanonical manifest path')
        if row['path'] in seen:
            raise ValueError('Duplicate manifest member')
        seen.add(row['path'])
        target = root / row['path']
        if not target.is_file() or target.is_symlink():
            raise ValueError(f'Missing or nonregular member: {relative}')
        raw = target.read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError(f'File integrity mismatch: {relative}')
    return len(seen)


def run(root: Path, verify_only: bool) -> dict:
    count = check_files(root)
    answer = {'integrity_files_checked': count,
              'mathematical_proof_verified': False,
              'independent_external_audit': False}
    if verify_only:
        answer['status'] = 'PRESERVED_BYTES_MATCH'
        return answer
    with tempfile.TemporaryDirectory(prefix='n25-d14-fresh-') as directory:
        out = Path(directory)
        for script in ('verify_primary.py', 'verify_independent.py'):
            command = [sys.executable, '-I', '-B', str(root / script), '--output', str(out)]
            if script == 'verify_independent.py':
                command += ['--reference', str(out)]
            completed = subprocess.run(command, capture_output=True, text=True, timeout=180)
            if completed.returncode != 0 or completed.stderr:
                raise RuntimeError(f'{script} failed: {completed.stderr}')
        expected = json.loads((root / 'results/primary_summary.json').read_text())
        current = json.loads((out / 'primary_summary.json').read_text())
        if expected != current:
            raise RuntimeError('Fresh primary output differs from the preserved result')
        expected_second = json.loads((root / 'results/independent_summary.json').read_text())
        current_second = json.loads((out / 'independent_summary.json').read_text())
        if expected_second != current_second:
            raise RuntimeError('Fresh independent output differs from the preserved result')
        answer.update(status='BOTH_ARITHMETIC_RUNS_REPRODUCED', states=current['state_count'],
                      residual_column_vectors=current['column_vectors'], survivors=current['survivors'],
                      state_key_sha256=current['state_key_sha256'])
    return answer


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--verify-only', action='store_true')
    p.add_argument('--output', type=Path)
    args = p.parse_args()
    try:
        result = run(Path(__file__).resolve().parent, args.verify_only)
        text = json.dumps(result, indent=2, sort_keys=True) + '\n'
        print(text, end='')
        if args.output:
            args.output.write_text(text)
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.TimeoutExpired) as error:
        print(f'FAIL: {error}', file=sys.stderr)
        raise SystemExit(1)
