#!/usr/bin/env python3
from pathlib import Path
from functools import lru_cache
import json
from graphical_caps import label_ok

@lru_cache(None)
def match_weight(d,delta,rb,h):
    # Select an increasing subsequence of the sorted full-degree list and
    # match it to the sorted intervals [delta_i,delta_i+rb].
    q=len(delta); neg=-100
    dp=[neg]*(q+1);dp[0]=0
    for degree in d:
        nd=dp[:]
        for j in range(q):
            if dp[j]>=0 and delta[j]<=degree<=delta[j]+rb:
                nd[j+1]=max(nd[j+1],dp[j]+(degree>=h))
        dp=nd
    return dp[q]

def bound(d,rho,caps,h):
    per=[]
    for b,rb in enumerate(rho):
        best=0
        for q in range(1,min(caps[b],10-rb)+1):
            avail=sorted((rw for w,rw in enumerate(rho) if w!=b and rw+caps[w]>=q-1),reverse=True)
            if len(avail)<q:continue
            for delta in label_ok(tuple(d),rb,q):
                if all(x<=y for x,y in zip(reversed(delta),avail[:q])):
                    best=max(best,match_weight(tuple(d),delta,rb,h))
        per.append(best)
    return per

if __name__=='__main__':
    p=Path(__file__).parent
    raw=json.loads((p/'refinement_D7.json').read_text())
    out=[]
    for row in raw['rows']:
        if row['failure'] is not None:continue
        d,rho,caps=row['degrees'],row['rho'],row['refined_caps']
        failures=[]
        for h in range(1,max(d)+1):
            labels=[x for x in d if x>=h]
            lower=sum(labels)-sum(min(x,len(labels)) for x in rho)
            per=bound(d,rho,caps,h)
            if sum(per)<lower:failures.append({'h':h,'lower':lower,'upper':sum(per),'per_source':per})
        row={**row,'weighted_failures':failures,'survives_weighted':not failures}
        out.append(row)
        print(row['source_index'],row['r'],'OPEN' if not failures else 'KILL',[(x['h'],x['lower'],x['upper']) for x in failures],flush=True)
    (p/'weighted_D7.json').write_text(json.dumps(out,indent=2)+'\n')
