#!/usr/bin/env python3
"""Finite regression of a general residual inequality; not its mathematical proof."""
import json
from collections import Counter
from itertools import combinations
import networkx as nx

def main():
    totals=Counter(); rows=[]
    atlas=nx.graph_atlas_g()
    for index,g in enumerate(atlas):
        n=len(g)
        if n<3 or min(dict(g.degree()).values())==0: continue
        V=set(g); N={a:set(g[a]) for a in V}
        if any(N[a]|N[b]==V for a,b in g.edges()): continue
        if not any(set().union(*(N[a] for a in S))==V for S in combinations(V,3)): continue
        # Direct edge-addition test of 3-total-domination criticality.
        nonedges=[(a,b) for a,b in combinations(V,2) if b not in N[a]]
        critical=True
        for a,b in nonedges:
            NN={u:N[u]|({b} if u==a else {a} if u==b else set()) for u in V}
            if not any(NN[u]|NN[w]==V for u,w in list(g.edges())+[(a,b)]):
                critical=False; break
        if not critical: continue
        totals['three_total_domination_critical_graphs']+=1
        def exception(a,b):
            missing=V-(N[a]|N[b])
            return next(iter(missing)) if len(missing)==1 else None
        for v in V:  # ALL base vertices, stronger than minimum-degree only.
            A=N[v]; B=V-A-{v}
            if not B: continue
            pairs=[frozenset((b,w)) for b,w in combinations(B,2) if w not in N[b]]
            options={pair:[] for pair in pairs}
            edge_pair={}
            for a in A:
                for b in N[a]&B:
                    w=exception(a,b)
                    if w in B:
                        pair=frozenset((b,w));options[pair].append((a,b));edge_pair[(a,b)]=pair
            if any(not opts for opts in options.values()):
                raise AssertionError(('Claim-A failure',index,v))
            r=sum(len(N[a]&B) for a in A)-len(pairs)
            F=[(a,c) for a,c in combinations(A,2) if c not in N[a]]
            totals['base_vertex_decompositions']+=1
            for b in B:
                S=N[b]&A;T=A-S
                # Every b-A edge must be selected, and different ones must use different B-pairs.
                need=[edge_pair.get((a,b)) for a in S]
                if None in need or len(set(need))!=len(need): continue
                # Other missing pairs have a free choice; cross-edges of different pairs are disjoint.
                chosen={p:opts[0] for p,opts in options.items()}
                for a in S: chosen[edge_pair[a,b]]=(a,b)
                selected=set(chosen.values())
                residual={(a,c) for a in A for c in N[a]&B} - selected
                if len(residual)!=r: raise AssertionError('duplicate selected edge')
                if any(c not in S for a,c in F if a in S) or any(a not in S for a,c in F if c in S):
                    raise AssertionError('F crosses S and T')
                eS=sum(a in S and c in S for a,c in F)
                eT=sum(a in T and c in T for a,c in F)
                forcedS=set()
                for a,c in F:
                    if a in S:
                        wa=exception(a,b);wc=exception(c,b)
                        if wa==wc: raise AssertionError('noninjective supplements')
                        forcedS.update(((c,wa),(a,wc)))
                if not forcedS<=residual or len(forcedS)!=2*eS:
                    raise AssertionError(('S witnesses',index,v,b))
                forcedT=set()
                for a,c in F:
                    if a in T:
                        opts=[(u,z) for u,w in [(a,c),(c,a)] for z in N[u] if exception(u,z)==w]
                        if not opts or not all(z in B for u,z in opts):
                            raise AssertionError(('T witness location',index,v,b,a,c,opts))
                        forcedT.add(opts[0])
                if not forcedT<=residual or len(forcedT)!=eT or forcedS&forcedT:
                    raise AssertionError(('T injectivity',index,v,b))
                if r<len(F)+eS: raise AssertionError(('inequality',index,v,b,r,F))
                totals['inactive_vertex_scenarios']+=1
                totals['seen_F_edges_witnessed_twice']+=eS
                totals['missed_F_edges_witnessed_once']+=eT
                rows.append({'atlas_index':index,'n':n,'v':v,'b':b,'r':r,'F_edges':len(F),'F_seen_edges':eS,
                             'forced_seen_edges':sorted(forcedS),'forced_missed_edges':sorted(forcedT)})
    return {'status':'PASS','scope':'NetworkX supplied graph atlas through order seven; regression only',
            'networkx_version':nx.__version__, 'atlas_graphs':len(atlas),'counts':dict(totals),'cases':rows}
if __name__=='__main__':
    result=main()
    import pathlib
    out=pathlib.Path(__file__).with_name('inactive_lemma_atlas_results.json')
    out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
