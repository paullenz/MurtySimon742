#!/usr/bin/env python3
"""Seeded finite stress test of the three new residual inequalities.
This is NOT an exhaustive graph enumeration and NOT a proof of the lemmas.
"""
from collections import Counter
from itertools import combinations
from pathlib import Path
import argparse
import json
import random


def require(x, message):
    if not x:
        raise RuntimeError(message)


def diameter_two(N):
    return all((N[i] >> j) & 1 or N[i] & N[j]
               for i in range(len(N)) for j in range(i))


def experiment(seed=7422514, samples=240):
    rng = random.Random(seed)
    count = Counter()
    graphs = []
    for sample in range(samples):
        n = 8 + sample % 9
        full = (1 << n) - 1
        for _ in range(1000):
            G = [0] * n
            p = .35 + rng.random() * .4
            for i in range(n):
                for j in range(i):
                    if rng.random() < p:
                        G[i] |= 1 << j; G[j] |= 1 << i
            if diameter_two(G):
                break
        else:
            raise RuntimeError('Could not generate diameter-two input')
        edges = [(i, j) for i in range(n) for j in range(i) if (G[i] >> j) & 1]
        rng.shuffle(edges)
        for i, j in edges:
            G[i] ^= 1 << j; G[j] ^= 1 << i
            if not diameter_two(G):
                G[i] |= 1 << j; G[j] |= 1 << i
        H = [full ^ G[i] ^ (1 << i) for i in range(n)]
        he = [(i, j) for i in range(n) for j in range(i) if H[i] >> j & 1]
        if min(H) == 0:
            count['isolated_complement_skips'] += 1; continue
        require(not any(H[i] | H[j] == full for i, j in he), 'H has total dominating edge')
        if not any(H[i] | H[j] | H[z] == full for i, j, z in combinations(range(n), 3)):
            count['not_three_total_domination_skips'] += 1; continue
        for i in range(n):
            for j in range(i):
                if H[i] >> j & 1: continue
                newer = H.copy(); newer[i] |= 1 << j; newer[j] |= 1 << i
                require(any(newer[a] | newer[b] == full for a,b in he + [(i,j)]),
                        'Not total-domination-critical after edge addition')
        count['directly_checked_three_total_domination_critical_graphs'] += 1
        graphs.append({'sample':sample,'n':n,'G_adjacency_bitmasks':G})
        def exception(a,b):
            missing = full ^ (H[a] | H[b])
            return missing.bit_length()-1 if missing and not missing & (missing-1) else None
        for v in range(n):
            A = [a for a in range(n) if H[v] >> a & 1]
            B = [b for b in range(n) if b != v and not H[v] >> b & 1]
            F = [(a,c) for a,c in combinations(A,2) if not H[a] >> c & 1]
            cross = {(a,b) for a in A for b in B if H[a] >> b & 1}
            options = {}
            for b,w in combinations(B,2):
                if H[b] >> w & 1:continue
                variants = [(a,u,z) for u,z in ((b,w),(w,b)) for a in A
                            if H[a] >> u & 1 and exception(a,u)==z]
                require(variants,'Claim-A assignment unavailable')
                options[(b,w)]=variants
            chosen = [rng.choice(variants) for variants in options.values()]
            selected = {(a,b) for a,b,w in chosen}
            require(len(selected)==len(chosen),'Selected assignment not injective')
            residual = cross - selected
            rho = {b:sum(z==b for a,z in residual) for b in B}
            columns = {a:sum(x==a for x,z in residual) for a in A}
            d = {a:sum(a in edge for edge in F) for a in A}
            for a,b,w in chosen:
                require(d[a] <= rho[b] + rho[w], 'B-pair residual inequality failed')
                require(d[a] <= rho[b] + columns[a], 'A-column residual inequality failed')
                count['selected_edges_checked'] += 1
            for b in B:
                if rho[b]:continue
                S = {a for a in A if H[a] >> b & 1}
                seen = sum(a in S and c in S for a,c in F)
                require(len(residual)>=len(F)+seen,'All-active counting inequality failed')
                count['inactive_vertex_inequalities_checked'] += 1
                count['seen_F_edges_in_inactive_tests'] += seen
            count['decompositions_checked'] += 1
    return dict(status='PASS',kind='FINITE_NONEXHAUSTIVE_REGRESSION_NOT_PROOF',
                seed=seed,requested_samples=samples,counts=dict(count),graphs=graphs)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=Path('results/graph_regression.json'))
    a=p.parse_args(); result=experiment()
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='graphs'},sort_keys=True))
