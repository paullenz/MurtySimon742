#!/usr/bin/env python3
"""Check the uploaded dossier against fresh verifier outputs. No theorem promotion."""
from pathlib import Path
from zipfile import ZipFile
from collections import Counter
from lxml import etree
from docx import Document
import hashlib, json, platform, re, sys

ROOT = Path(__file__).resolve().parent
source = Path(sys.argv[1])
doc = Document(source)
tables = [[[c.text for c in row.cells] for row in t.rows] for t in doc.tables]
primary = json.loads((ROOT/'results/primary_summary.json').read_text())
columns = json.loads((ROOT/'results/primary_column_cases.json').read_text())
names = ['pair_threshold','source_total','source_threshold','column_lower_bound','all_columns','survives']
with ZipFile(source) as z:
    tree = etree.fromstring(z.read('word/document.xml'))
    ns = {'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    paragraphs = [''.join(p.xpath('.//w:t/text()',namespaces=ns)) for p in tree.xpath('//w:p',namespaces=ns)]
    source_records = []
    for i, text in enumerate(paragraphs):
        m = re.fullmatch(r'Original source: (\S+\.py)  \|  (\d+) lines', text)
        if not m: continue
        name, length = m.group(1), int(m.group(2))
        expected = paragraphs[i+1].split(': ',1)[1]
        lines = []
        for text in paragraphs[i+2:]:
            m = re.fullmatch(r'\s*(\d*) \| (.*)',text)
            if not m: break
            number, code = m.groups()
            if number:
                assert int(number) == len(lines)+1
                lines.append(code)
            else:
                lines[-1] += code
        data = ('\n'.join(lines)+'\n').encode()
        assert len(lines) == length
        assert hashlib.sha256(data).hexdigest() == expected
        assert (ROOT/name).read_bytes() == data
        source_records.append(dict(file=name,lines=length,sha256=expected))
    edits = {tag:len(tree.xpath('//w:'+tag,namespaces=ns)) for tag in ['ins','del','commentRangeStart']}
    comment_parts = [p for p in z.namelist() if 'comments' in p]

for table_id,k in zip(range(4,8),(5,4,3,2)):
    expected=[]
    for row in primary['rows']:
        if row['k'] == k:
            expected.append([row['r'],row['states']]+[row['dispositions'].get(n,0) for n in names])
    assert [[int(c.replace(',','')) for c in row] for row in tables[table_id][1:]] == expected

for i,k in enumerate((5,4,3,2),1):
    rows=[r for r in primary['rows'] if r['k']==k]
    expected=[sum(r['states'] for r in rows)]+[sum(r['dispositions'].get(n,0) for r in rows) for n in names[:-1]]
    assert [int(c.replace(',','')) for c in tables[2][i][2:]] == expected
assert [int(c.replace(',','')) for c in tables[2][-1][2:]] == [sum(int(tables[2][i][j].replace(',','')) for i in range(1,5)) for j in range(2,8)]

outer_rows = sum([tables[i][1:] for i in range(8,12)],[])
refinement_count=0
for i,(row,entry,aggregate) in enumerate(zip(outer_rows,columns,tables[12][1:]),1):
    k,r,d,rho=json.loads(entry['key']);w=entry['witness'];cc=w['columns']
    expected_rho='; '.join(f'{v}×{n}' for v,n in sorted(Counter(rho).items()))
    assert row == [str(i),str(r),'('+','.join(map(str,d))+')',expected_rho,str(w['h']),str(w['column_count'])]
    required=[c['required'] for c in cc]
    qr=str(min(required)) if min(required)==max(required) else f'{min(required)}–{max(required)}'
    refined=sum(sum(c['caps'])>=c['required'] for c in cc)
    refinement_count+=refined
    assert aggregate == [str(i),str(len(cc)),qr,str(max(c['upper'] for c in cc)),str(min(c['required']-c['upper'] for c in cc)),str(refined)]
    assert all(c['upper'] < c['required'] for c in cc)

assert refinement_count==110
assert len(outer_rows)==len(columns)==31
assert sum(len(e['witness']['columns']) for e in columns)==1480
assert primary['state_key_sha256']=='882a99e6e6df73fc23c6380ec19b4324fd59eb16bc384519cbe9aa9ea2f18462'
assert primary['uncompressed_ledger_sha256']=='23139a1c76b41c23974e4bba96a3c5427b9505492e6e3e69e0b392795ea80eab'
expected_hashes={
    'primary_summary.json':'445704d80236caa197c58a2a5fb6d908af44059bf33e36002d0b4a7d523aab49',
    'independent_summary.json':'1c99ab649aa5ede3813b302ed73988a45cb4f8f2765301d3039f643758e39af2',
    'primary_column_cases.json':'20ca9375e091485a7998352d72180a8dff6023621840f03959ea17ce4f3080ed',
    'primary_ledger.jsonl.gz':'70a441208917666a9db50bb3b389ff48d4fc4a8525ce1c8895bdb87637005730'}
for name,expected in expected_hashes.items():
    assert hashlib.sha256((ROOT/'results'/name).read_bytes()).hexdigest()==expected
result=dict(status='PASS',review_kind='INTERNAL_DOCUMENT_REVIEW_AND_REPRODUCTION',
    source_document_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    recovered_sources=source_records,source_lines=sum(r['lines'] for r in source_records),
    all_46_band_rows_match=True,all_31_outer_rows_match=True,all_31_column_aggregate_rows_match=True,
    all_1480_columns_rejected=True,columns_requiring_refinement=refinement_count,
    result_hashes=expected_hashes,tracked_elements=edits,comment_parts=comment_parts,
    python=sys.version,platform=platform.platform(),external_mathematical_audit=False,
    project_certification_promoted=False)
(ROOT/'document_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
