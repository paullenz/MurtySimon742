#!/usr/bin/env python3
"""Permissive all-active degree/residual enumeration: elementary necessary tests."""
from functools import lru_cache
from itertools import combinations
from math import comb
from pathlib import Path
import json,time

@lru_cache(None)
def multisets(n,total,lo,hi):
    if n==0: return ((),) if total==0 else ()
    out=[]
    for a in range(lo,hi+1):
        if a*n>total:break
        if a+hi*(n-1)<total:continue
        out.extend((a,)+p for p in multisets(n-1,total-a,a,hi))
    return tuple(out)

def capacity(d,rho):
    # Over-enumerates non-graphical degrees and all possible positive residual patterns.
    for h in range(1,max(d)+1):
        labels=[x for x in d if x>=h]
        lower=sum(labels)-sum(min(x,len(labels)) for x in rho)
        upper=sum(a+b>=h for a,b in combinations(rho,2))
        if lower>upper: return False,{'kind':'threshold','h':h,'lower':lower,'upper':upper}
    caps=[]
    for b,rb in enumerate(rho):
        supp=sorted((rb+rw for w,rw in enumerate(rho) if w!=b),reverse=True)
        best=0
        for q in range(1,min(len(d),10-rb)+1):
            if len(supp)<q: continue
            if d[q-1]>rb+q-1:continue
            if all(x<=y for x,y in zip(reversed(d[:q]),supp[:q])):
                best=q
        caps.append(best)
    if sum(caps)<sum(d)-sum(rho):
        return False,{'kind':'source','lower':sum(d)-sum(rho),'upper':sum(caps),'caps':caps}
    return True,{'caps':caps}

def scan(D):
    rows=[];sur=[]
    for r in range(14,43-5*(9-D)):
        counts={'raw':0,'threshold':0,'source':0,'survivors':0}
        for d in multisets(10,2*(r+3),0,D):
            if max(d)!=D:continue
            for rho in multisets(14,r,1,10):
                counts['raw']+=1
                yes,why=capacity(d,rho)
                if not yes:counts[why['kind']]+=1
                else:
                    counts['survivors']+=1
                    sur.append({'r':r,'k':9-D,'degrees':d,'rho':rho,'caps':why['caps']})
        rows.append({'r':r,**counts})
        print(D,r,counts,flush=True)
    return {'D':D,'k':9-D,'rows':rows,'survivors':sur}

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('D',type=int,nargs='+');args=p.parse_args()
    for D in args.D:
        t=time.time();out=scan(D);out['seconds']=time.time()-t
        Path(__file__).with_name(f'all_active_D{D}.json').write_text(json.dumps(out,indent=2)+'\n')
