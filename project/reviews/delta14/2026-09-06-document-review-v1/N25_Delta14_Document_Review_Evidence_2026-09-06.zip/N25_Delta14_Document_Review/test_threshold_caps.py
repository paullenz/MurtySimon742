import json
from pathlib import Path
from itertools import combinations
rows=json.loads(Path(__file__).with_name('graphical_caps_D6.json').read_text())
res=[]
for row in rows:
    d,rho,caps=row['degrees'],row['rho'],row['graphical_caps']
    failures=[]
    for h in range(1,max(d)+1):
        ds=[x for x in d if x>=h]
        lower=sum(ds)-sum(min(x,len(ds)) for x in rho)
        upper_per=[]
        for b,rb in enumerate(rho):
            elig=[x for x in ds if x<=rb+caps[b]-1]
            supp=sorted([rb+rw for w,rw in enumerate(rho) if w!=b],reverse=True)
            best=0
            for j in range(1,min(caps[b],len(elig))+1):
                if all(x<=y for x,y in zip(reversed(elig[:j]),supp[:j])):best=j
            upper_per.append(best)
        upper=sum(upper_per)
        if upper<lower:failures.append({'h':h,'lower':lower,'upper':upper,'per_source':upper_per})
    res.append({**row,'threshold_failures':failures,'final_survives':row['survives'] and not failures})
    print(row['id'],row['r'],'OPEN' if res[-1]['final_survives'] else 'KILL',[(f['h'],f['lower'],f['upper']) for f in failures])
Path(__file__).with_name('threshold_propagated_D6.json').write_text(json.dumps(res,indent=2)+'\n')
