#!/usr/bin/env python3
"""New permissive local test using graphical degrees of a selected label set."""
from functools import lru_cache
from itertools import combinations_with_replacement
from pathlib import Path
import json

def graphical(ds):
    d=sorted(ds,reverse=True)
    if sum(d)%2:return False
    while d:
        x=d.pop(0)
        if x<0 or x>len(d):return False
        for i in range(x):
            d[i]-=1
            if d[i]<0:return False
        d.sort(reverse=True)
    return True

@lru_cache(None)
def graphs(q):
    return tuple(p for p in combinations_with_replacement(range(q),q) if graphical(p))

@lru_cache(None)
def label_ok(ds,rb,q):
    good=[]
    for delta in graphs(q):
        j=0;yes=True
        for x in delta:
            while j<len(ds) and ds[j]<x:j+=1
            if j==len(ds) or ds[j]>x+rb:
                yes=False;break
            j+=1
        if yes:good.append(delta)
    return tuple(good)

def tighten(d,rho,caps):
    hist=[caps[:]]
    while True:
        new=[]
        for b,rb in enumerate(rho):
            best=0
            for q in range(1,min(caps[b],10-rb)+1):
                avail=sorted((rw for w,rw in enumerate(rho) if w!=b and rw+caps[w]>=q-1),reverse=True)
                if len(avail)<q:continue
                if any(all(x<=y for x,y in zip(reversed(delta),avail[:q])) for delta in label_ok(tuple(d),rb,q)):
                    best=q
            new.append(best)
        if new==caps:break
        caps=new;hist.append(caps[:])
    return caps,hist

if __name__=='__main__':
    rows=json.loads(Path(__file__).with_name('all_active_D6.json').read_text())['survivors']
    res=[]
    for i,row in enumerate(rows):
        caps,hist=tighten(row['degrees'],row['rho'],row['caps'])
        row={**row,'id':i,'graphical_caps':caps,'iterations':hist,'upper':sum(caps),'lower':row['r']+6,'survives':sum(caps)>=row['r']+6}
        res.append(row)
        print(i,row['r'],sum(caps),row['lower'],'SURVIVE' if row['survives'] else 'KILL',caps,flush=True)
    Path(__file__).with_name('graphical_caps_D6.json').write_text(json.dumps(res,indent=2)+'\n')
