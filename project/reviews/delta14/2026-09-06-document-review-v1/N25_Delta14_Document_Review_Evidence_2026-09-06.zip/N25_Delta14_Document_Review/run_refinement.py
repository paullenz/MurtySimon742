#!/usr/bin/env python3
from pathlib import Path
from itertools import combinations
import json,argparse,time
from graphical_caps import tighten

def threshold_witness(d,rho,caps):
    for h in range(1,max(d)+1):
        labels=[x for x in d if x>=h]
        lower=sum(labels)-sum(min(x,len(labels)) for x in rho)
        per=[]
        for b,rb in enumerate(rho):
            elig=[x for x in labels if x<=rb+caps[b]-1]
            supp=sorted((rb+rw for w,rw in enumerate(rho) if w!=b),reverse=True)
            best=0
            for j in range(1,min(caps[b],len(elig))+1):
                if all(x<=y for x,y in zip(reversed(elig[:j]),supp[:j])):best=j
            per.append(best)
        if sum(per)<lower:return {'kind':'refined_threshold','h':h,'lower':lower,'upper':sum(per),'per_source':per}
    return None

def main(D):
    p=Path(__file__).parent
    raw=json.loads((p/f'all_active_D{D}.json').read_text())
    rows=[];t=time.time()
    for i,row in enumerate(raw['survivors']):
        d,rho=row['degrees'],row['rho']
        caps,hist=tighten(d,rho,row['caps'])
        failure=threshold_witness(d,rho,caps)
        if not failure and sum(caps)<row['r']+6:
            failure={'kind':'refined_sum','lower':row['r']+6,'upper':sum(caps)}
        rows.append({**row,'source_index':i,'refined_caps':caps,'iterations':hist,'failure':failure})
        if not failure:print('SURVIVES',D,i,row['r'],d,rho,caps,flush=True)
    out={'D':D,'k':9-D,'initial_survivors':len(rows),'final_survivors':sum(x['failure'] is None for x in rows),'seconds':time.time()-t,'rows':rows}
    (p/f'refinement_D{D}.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='rows'}),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('D',type=int,nargs='+');a=p.parse_args()
    for D in a.D:main(D)
