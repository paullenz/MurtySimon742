#!/usr/bin/env python3
from pathlib import Path
from functools import lru_cache
import json

def distributions(lower,total,cap=14):
    def rec(i,left,p):
        if i==len(lower):
            if left==0:yield tuple(p)
            return
        tail=sum(lower[i+1:])
        for x in range(lower[i],min(cap,left-tail)+1):
            yield from rec(i+1,left-x,p+[x])
    yield from rec(0,total,[])

def qcaps(d,rho,R):
    caps=[]
    for b,rb in enumerate(rho):
        supp=sorted([rb+rw for w,rw in enumerate(rho) if w!=b],reverse=True)
        best=0
        for q in range(1,11-rb):
            eligible=sorted(d[a] for a in range(10) if d[a]<=R[a]+rb and d[a]<=rb+q-1)
            if len(eligible)<q:continue
            if all(x<=y for x,y in zip(reversed(eligible[:q]),supp[:q])):best=q
        caps.append(best)
    return caps

if __name__=='__main__':
    p=Path(__file__).parent
    states=json.loads((p/'durfee_survivors.json').read_text());out=[]
    for row in states:
        d,rho=row['degrees'],row['rho'];h=row['h'];r=row['r'];low=[max(0,x-h) for x in d]
        records=[];surv=[]
        for R in distributions(low,r):
            caps=qcaps(d,rho,R)
            needed=sum(max(0,a-b) for a,b in zip(d,R));upper=sum(caps)
            rec={'R':R,'caps':caps,'lower':needed,'upper':upper,'fails':upper<needed}
            records.append(rec)
            if not rec['fails']:surv.append(rec)
        out.append({**row,'columns_tested':len(records),'column_survivors':len(surv),'columns':records})
        print(row['id'],r,len(records),len(surv), 'best',max(x['upper'] for x in records),flush=True)
        for a in surv[:2]:print(' LIVE',a,flush=True)
    (p/'column_residual_results.json').write_text(json.dumps(out,indent=2)+'\n')
