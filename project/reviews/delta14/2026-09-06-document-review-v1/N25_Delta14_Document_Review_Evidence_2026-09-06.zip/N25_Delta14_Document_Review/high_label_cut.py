#!/usr/bin/env python3
from itertools import combinations
from pathlib import Path
import json

def cut(d,rho,caps):
    possible={a:[b for b,rb in enumerate(rho) if caps[b]>0 and d[a]<=rb+caps[b]-1 and any(w!=b and d[a]<=rb+rw for w,rw in enumerate(rho))] for a in range(len(d))}
    high=[a for a in range(len(d)) if not possible[a]]
    if not high:return None
    low=[a for a in range(len(d)) if a not in high]
    budget=sum(rho)-sum(d[a] for a in high)
    if budget<0:return {'kind':'residual_only_deficit','high':high,'lower':sum(d[a] for a in high),'upper':sum(rho)}
    lower=sum(d[a] for a in high)-len(high)*(len(high)-1)
    if lower<=0:return None
    dp={0:0}
    for a in low:
        nd={}
        for used,total in dp.items():
            for h in range(min(len(high),d[a])+1):
                supplies=sum(rho[b]>=h for b in possible[a])
                cost=max(0,d[a]-supplies)
                if used+cost<=budget:
                    nd[used+cost]=max(nd.get(used+cost,-1),total+h)
        dp=nd
    upper=max(dp.values(),default=-1)
    if upper<lower:return {'kind':'residual_only_neighbour_cut','high':high,'budget':budget,'lower':lower,'upper':upper,'possible_sources':possible}
    return None
if __name__=='__main__':
    p=Path(__file__).parent;out=[]
    for row in json.loads((p/'weighted_D7.json').read_text()):
        if not row['survives_weighted']:continue
        f=cut(row['degrees'],row['rho'],row['refined_caps'])
        out.append({**row,'high_cut':f})
        print(row['source_index'],row['r'],'OPEN' if f is None else 'KILL',f,flush=True)
    (p/'high_cut_D7.json').write_text(json.dumps(out,indent=2)+'\n')
