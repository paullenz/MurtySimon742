#!/usr/bin/env python3
import json
from pathlib import Path
from itertools import combinations

def tighten(d,rho,caps):
    history=[caps[:]]
    while True:
        new=[]
        for b,rb in enumerate(rho):
            best=0
            for q in range(1,min(caps[b],10-rb)+1):
                if d[q-1]>rb+q-1:continue
                available=sorted((rb+rw for w,rw in enumerate(rho) if w!=b and rw+caps[w]>=q-1),reverse=True)
                if len(available)<q:continue
                if all(x<=y for x,y in zip(reversed(d[:q]),available[:q])):best=q
            new.append(best)
        if new==caps:break
        history.append(new);caps=new
    return caps,history

if __name__=='__main__':
    for D in [6]:
        raw=json.loads(Path(__file__).with_name(f'all_active_D{D}.json').read_text())
        result=[]
        for i,row in enumerate(raw['survivors']):
            caps,hist=tighten(row['degrees'],row['rho'],row['caps'])
            r=row['r']; lower=r+6
            result.append({**row,'propagated_caps':caps,'history':hist,'lower':lower,'upper':sum(caps),'survives':sum(caps)>=lower})
            print(i,r,lower,sum(caps), 'SURVIVES' if sum(caps)>=lower else 'killed',caps)
        Path(__file__).with_name('propagated_caps_D6.json').write_text(json.dumps(result,indent=2)+'\n')
