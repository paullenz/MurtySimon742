#!/usr/bin/env python3
"""Deterministic unit/negative tests. These do not prove graph-theoretic lemmas."""
import hashlib
import importlib.util
from itertools import combinations, combinations_with_replacement, permutations, product
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent

def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'))
    out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out);return out

P=module('verify_primary');S=module('verify_independent');R=module('run_all')

class VerificationTests(unittest.TestCase):
    def test_multiset_domains_against_brute_force(self):
        for length in range(5):
            brute=list(combinations_with_replacement(range(4),length))
            for total in range(13):
                expected={x for x in brute if sum(x)==total}
                self.assertEqual(set(P.multisets(length,total,0,3)),expected)
                self.assertEqual({S.expand(h) for h in S.histograms(3,length,total)},expected)

    def test_positive_residual_shift(self):
        for total in range(4,13):
            a=set(P.multisets(4,total,1,4))
            b={S.expand(h,1) for h in S.histograms(3,4,total-4)}
            self.assertEqual(a,b)

    def test_matching_against_bruteforce(self):
        seq=[x for n in range(4) for x in combinations_with_replacement(range(4),n)]
        def brute(labels,supplies):
            for n in range(min(len(labels),len(supplies)),-1,-1):
                for sub in combinations(labels,n):
                    for targets in permutations(supplies,n):
                        if all(x<=y for x,y in zip(sub,targets)):return n
        for labels in seq:
            for supplies in seq:
                self.assertEqual(S.matching_number(labels,supplies),brute(labels,supplies))

    def test_sorted_matching_equivalence(self):
        for ds in combinations_with_replacement(range(5),3):
            for ss in combinations_with_replacement(range(5),4):
                for n in range(1,4):
                    self.assertEqual(P.matches(list(ds[:n]),sorted(ss,reverse=True)[:n]),
                                     S.matching_number(ds,ss)>=n)

    def test_column_enumeration(self):
        low=(1,1,1,1,1,1,2,4,4,4)
        first=set(P.column_vectors(low,22))
        second={tuple(a+b for a,b in zip(low,x)) for x in S.weak_compositions(2,10)}
        self.assertEqual(first,second);self.assertEqual(len(first),55)

    def test_source_caps_agree_on_final_columns(self):
        rho=(1,)*10+(3,)*4
        for d in ((4,4,4,4,4,4,5,7,7,7),(4,4,4,4,4,4,6,6,7,7)):
            low=tuple(x-3 for x in d)
            for col in P.column_vectors(low,22):
                first=P.source_caps(d,rho,col)
                self.assertEqual(first,S.neighbours_bound(d,rho,col))
                self.assertEqual(first,[0]*10+[7]*4)

    def test_final_neighbourhood_contradiction(self):
        self.assertEqual(P.neighbourhood_caps((1,)*10+(3,)*4,[0]*10+[7]*4),[0]*10+[3]*4)

    def test_saved_complete_results(self):
        a=json.loads((ROOT/'results/primary_summary.json').read_text())
        b=json.loads((ROOT/'results/independent_summary.json').read_text())
        self.assertEqual(a['state_count'],59264)
        self.assertEqual(a['survivors'],0)
        for field in ('state_count','state_key_sha256','rows','survivors','column_vectors'):
            self.assertEqual(a[field],b[field])
        self.assertEqual(a['column_vectors'],1480)
        self.assertEqual(len(a['rows']),46)

    def example(self,root):
        (root/'x.txt').write_bytes(b'original\n')
        data={'files':[{'path':'x.txt','bytes':9,'sha256':hashlib.sha256(b'original\n').hexdigest()}]}
        (root/'MANIFEST.json').write_text(json.dumps(data))
        return data

    def test_integrity_accepts_exact_bytes(self):
        with tempfile.TemporaryDirectory() as p:
            root=Path(p);self.example(root);self.assertEqual(R.check_files(root),1)

    def test_integrity_rejects_altered_bytes(self):
        with tempfile.TemporaryDirectory() as p:
            root=Path(p);self.example(root);(root/'x.txt').write_bytes(b'altered!\n')
            with self.assertRaises(ValueError):R.check_files(root)

    def test_integrity_rejects_missing_file(self):
        with tempfile.TemporaryDirectory() as p:
            root=Path(p);self.example(root);(root/'x.txt').unlink()
            with self.assertRaises(ValueError):R.check_files(root)

    def test_integrity_rejects_unsafe_and_duplicate_paths(self):
        with tempfile.TemporaryDirectory() as p:
            root=Path(p);data=self.example(root);data['files'].append(data['files'][0].copy())
            (root/'MANIFEST.json').write_text(json.dumps(data))
            with self.assertRaises(ValueError):R.check_files(root)
            data['files']=data['files'][:1];data['files'][0]['path']='../x.txt'
            (root/'MANIFEST.json').write_text(json.dumps(data))
            with self.assertRaises(ValueError):R.check_files(root)

if __name__=='__main__':unittest.main(verbosity=2)
