# Explicit t=2 adaptation of the separate frozen v4 checker.
#!/usr/bin/env python3
"""Independent standard-library checker of the projected order-28 stage.
Checks exact evidence partition, zero-slack identity, degree-count feasibility,
and demand/degree lower bounds; does not import the discovery implementation.
"""
from collections import Counter
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]

def require(ok: bool, message: str)->None:
    if not ok: raise ValueError(message)

def least_demands(s: list[int],j:int)->list[int|None]:
    # Cardinality DP. Labels with demand >= j must be included.
    dp={0:0}
    for v in s:
        nd={}
        for count,value in dp.items():
            nd[count+1]=min(nd.get(count+1,10**9),value+v)
            if v<j:nd[count]=min(nd.get(count,10**9),value)
        dp=nd
    return [dp.get(h) for h in range(len(s)+1)]

def pair_count(rho:list[int],j:int)->int:
    hist=Counter(rho);count=0
    for u in hist:
        for v in hist:
            if u>v or u+v<j:continue
            count+=hist[u]*hist[v] if u<v else hist[u]*(hist[u]-1)//2
    return count

def threshold(s:list[int],rho:list[int],r:int,j:int):
    minima=least_demands(s,j);total=2*r+4;bounds=[]
    for h,value in enumerate(minima):
        if value is None:continue
        # Each low degree is <= j-1; each high degree belongs to [j,10].
        if total>10*h+(12-h)*(j-1) or total<j*h:continue
        high_degree=max(h*j,total-(12-h)*(j-1))
        residual=sum(min(v,h) for v in rho)
        bounds.append([h,max(value,high_degree-residual)])
    pairs=pair_count(rho,j)
    rejected=all(bound>pairs for _,bound in bounds)
    return rejected,pairs,bounds

def verify_certificate(s:list[int],row:list[int],cert:dict)->None:
    _,r,*rho=row
    if cert['kind']=='zero_slack':
        slack=sum(s)-r-4
        require(all(v>0 for v in s) and slack!=0,'Bad zero-slack rejection')
        require(cert['slack']==slack,'Forged slack')
    elif cert['kind']=='projected_pair':
        j=cert['threshold'];require(type(j)is int and 2<=j<=10,'Bad threshold')
        bad,pairs,bounds=threshold(s,rho,r,j)
        require(cert['pairs']==pairs and cert['bounds']==bounds,'Forged pair table')
        require(bad,'Pair inequality does not reject')
    else:raise ValueError('Unknown certificate kind')

def verify_directory(root:Path=ROOT,negative_tests:bool=True)->dict:
    ev=root/'evidence'; demands=json.loads((ev/'n28_demands.json').read_text())
    source=[list(map(int,line.split())) for line in (ev/'n28_surviving_rows.txt').read_text().splitlines()]
    source_keys={tuple(row) for row in source}
    require(len(source_keys)==len(source),'Duplicate source row')
    certs=json.loads((ev/'n28_projected_pair_certificates.json').read_text())
    survivors=json.loads((ev/'n28_projected_survivors.json').read_text())
    accounted=set();counts=Counter()
    for obj in certs:
        row=obj['row'];key=tuple(row)
        require(key in source_keys and key not in accounted,'Bad certificate row or duplicate')
        verify_certificate(demands[row[0]]['s'],row,obj['certificate'])
        accounted.add(key);counts[obj['certificate']['kind']]+=1
    for row in survivors:
        key=tuple(row)
        require(key in source_keys and key not in accounted,'Bad surviving row or duplicate')
        idx,r,*rho=row;s=demands[idx]['s']
        require(not(all(v>0 for v in s)and sum(s)-r-4!=0),'Survivor violates slack identity')
        require(all(not threshold(s,rho,r,j)[0] for j in range(2,11)),'Survivor fails projected cut')
        accounted.add(key)
    require(accounted==source_keys,'Omitted source rows')
    report={'rows_checked':len(source),'zero_slack_certificates':counts['zero_slack'],
            'projected_pair_certificates':counts['projected_pair'],'surviving_rows':len(survivors),
            'surviving_demands':len({row[0] for row in survivors}),'complete_partition':True}
    if negative_tests:
        from copy import deepcopy
        obj=next(x for x in certs if x['certificate']['kind']=='projected_pair')
        bad=deepcopy(obj);bad['certificate']['pairs']+=1
        caught=False
        try:verify_certificate(demands[bad['row'][0]]['s'],bad['row'],bad['certificate'])
        except ValueError:caught=True
        require(caught,'Forged pair count accepted')
        require(set(map(tuple,survivors[:-1]))|{tuple(x['row']) for x in certs} != source_keys,'Omitted row not detected')
        report['negative_controls']={'forged_pair_count_rejected':True,'omitted_survivor_detected':True}
    return report

if __name__=='__main__':
    report=verify_directory();print(json.dumps(report,indent=2))
