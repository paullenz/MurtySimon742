# Explicit t=2 adaptation of the frozen v4 projected stage.
"""Exact projected pair cuts; a numerical relaxation, not graph construction."""
from pathlib import Path
from collections import Counter
import json,itertools
ROOT=Path(__file__).resolve().parents[1]

def reject(s,rho,r):
    slack=sum(s)-r-4
    if slack and not any(x==0 for x in s):return {'kind':'zero_slack','slack':slack}
    D=2*r+4
    for j in range(2,11):
        pairs=sum(u+v>=j for u,v in itertools.combinations(rho,2))
        forced=[v for v in s if v>=j]; optional=sorted(v for v in s if v<j)
        bounds=[]
        for h in range(len(forced),13):
            if 10*h+(12-h)*(j-1)<D or j*h>D:continue
            minimum_selected=sum(forced)+sum(optional[:h-len(forced)])
            high_degree=max(h*j,D-(12-h)*(j-1))
            minimum_selected=max(minimum_selected,high_degree-sum(min(x,h) for x in rho))
            bounds.append((h,minimum_selected))
        if not bounds or min(x[1] for x in bounds)>pairs:
            return {'kind':'projected_pair','threshold':j,'pairs':pairs,'bounds':bounds}
    return None

def main():
    demands=json.loads((ROOT/'evidence/n28_demands.json').read_text())
    counts=Counter();certs=[];surv=[]
    for line in (ROOT/'evidence/n28_surviving_rows.txt').read_text().splitlines():
        row=list(map(int,line.split()));i,r,*rho=row;s=demands[i]['s']
        c=reject(s,rho,r)
        counts['rows']+=1
        if c is None:counts['survivors']+=1;surv.append(row)
        else:counts[c['kind']]+=1;certs.append({'row':row,'certificate':c})
    (ROOT/'evidence/n28_projected_pairs_report.json').write_text(json.dumps(counts,indent=2)+'\n')
    (ROOT/'evidence/n28_projected_pair_certificates.json').write_text(json.dumps(certs,separators=(',',':'))+'\n')
    (ROOT/'evidence/n28_projected_survivors.json').write_text(json.dumps(surv,separators=(',',':'))+'\n')
    print(dict(counts))
if __name__=='__main__':main()
