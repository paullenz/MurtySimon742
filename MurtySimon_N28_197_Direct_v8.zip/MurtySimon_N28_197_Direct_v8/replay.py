#!/usr/bin/env python3
"""Integrity-only by default; full separate check or optional new discovery.

All executions use a fresh working copy. The preserved package is never
rewritten. Check mode requires standard-library Python and g++/Boost;
rediscovery additionally requires SciPy and can produce different duals.
"""
from __future__ import annotations
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, shutil, subprocess, sys, time
ROOT=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(x,message):
    if not x:raise ValueError(message)
def verify(root):
    manifest=json.loads((root/'MANIFEST.json').read_text())
    found={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.so')}
    expected={x['path'] for x in manifest['files']}
    require(len(expected)==len(manifest['files']), 'Duplicate manifest member')
    require(found==expected|{'MANIFEST.json'}, 'Unexpected or missing package payload')
    for x in manifest['files']:
        rel=PurePosixPath(x['path']);require(not rel.is_absolute() and '..' not in rel.parts,'Unsafe manifest path')
        p=root/x['path'];require(not p.is_symlink() and p.is_file(),'Missing/symlink payload')
        require(p.stat().st_size==x['bytes'] and digest(p)==x['sha256'],'Payload mismatch: '+x['path'])
    return {'payload_files':len(expected),'all_sha256_match':True,'manifest_sha256':digest(root/'MANIFEST.json')}
def stable(x):
    if isinstance(x,dict):return {k:stable(v) for k,v in x.items() if k not in ('seconds','stage_seconds')}
    if isinstance(x,list):return [stable(v) for v in x]
    return x

def main():
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group()
    g.add_argument('--verify-only',action='store_true');g.add_argument('--check',action='store_true');g.add_argument('--rediscover',action='store_true')
    p.add_argument('--output',type=Path);a=p.parse_args()
    require(__debug__,'Run without -O');start=time.monotonic();before=verify(ROOT)
    if not a.check and not a.rediscover:
        print(json.dumps({'integrity':before,'arithmetic_replayed':False},indent=2));return
    require(a.output is not None,'--output is required for checking or discovery')
    out=a.output.resolve();require(not out.exists() and out!=ROOT and ROOT not in out.parents,'Choose a new output outside the package')
    out.mkdir(parents=True);work=out/'working_copy';shutil.copytree(ROOT,work,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.so'))
    records=[]
    def run(name,cmd,capture=None):
        log=out/(name+'.log');t=time.monotonic()
        with log.open('wb') as f:
            result=subprocess.run(cmd,cwd=work,stdout=f,stderr=subprocess.STDOUT)
        records.append({'name':name,'exit_code':result.returncode,'seconds':time.monotonic()-t,'log':log.name})
        require(result.returncode==0,'Failed '+name+'; see '+str(log))
        if capture:shutil.copyfile(log,work/capture)
    py=[sys.executable,'-I','-B']
    if a.rediscover:
        run('prepare',py+[str(work/'src/prepare.py')])
        run('compile_scan',['g++','-O3','-std=c++17',str(work/'src/scan_rows.cpp'),'-o',str(out/'scan_rows')])
        run('scan_rows',[str(out/'scan_rows'),str(work/'evidence/demands.txt'),str(work/'evidence/row_survivors.txt'),str(work/'evidence/row_bands.txt')],Path('evidence/ROWS_REPORT.json'))
        # Rebuild the independent row summary and bytes before the complete checking route.
        run('compile_rows',['g++','-O3','-std=c++17',str(work/'src/check_rows.cpp'),'-o',str(out/'check_rows')])
        run('check_rows',[str(out/'check_rows'),str(work/'evidence/demands.txt'),str(work/'evidence/check_row_survivors.txt'),str(work/'evidence/check_row_bands.txt')],Path('evidence/ROWS_CHECK_REPORT.json'))
        shutil.copyfile(work/'evidence/demands.json',work/'evidence/n28_demands.json')
        shutil.copyfile(work/'evidence/row_survivors.txt',work/'evidence/n28_surviving_rows.txt')
        run('projected',py+[str(work/'exploration/projected_pairs.py')])
        run('joint',py+[str(work/'src/joint197.py')])
        run('LP',py+[str(work/'src/lp197.py'),'--workers','4'])
    run('direct197_check',py+[str(work/'src/check197.py'),'--output',str(out/'direct_check')])
    run('all_degree_scope',py+[str(work/'src/check_scope197.py'),'--output',str(out/'ALL_DEGREES_AND_FAN.json')])
    result=json.loads((out/'direct_check/EXACT_CHECK_REPORT.json').read_text())
    if not a.rediscover:
        require(stable(result)==stable(json.loads((work/'evidence/EXACT_CHECK_REPORT.json').read_text())),'Fresh exact report differs from preserved result')
        require(json.loads((out/'ALL_DEGREES_AND_FAN.json').read_text())==json.loads((work/'evidence/ALL_DEGREES_AND_FAN.json').read_text()),'Scope arithmetic report differs')
    after=verify(ROOT);require(before==after,'Original package changed')
    report={'mode':'rediscover-and-check' if a.rediscover else 'full-separate-check','integrity_before':before,'jobs':records,'scope':result['scope'],'charging_domain':result['charging_domain'],'residual_rows':result['residual_domain']['states'],'LP_exact_rejections':result['LP_exact_rejections'],'final_survivors':result['final_survivors'],'all_checks_pass':True,'original_payloads_unchanged':True,'weak_core_reduction_used':False,'196_edge_full_ancestor_chain_replayed':False,'optimisation_required_for_check':False,'seconds':time.monotonic()-start,'mathematical_status':'candidate; independent review OPEN'}
    (out/'FULL_REPLAY_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
