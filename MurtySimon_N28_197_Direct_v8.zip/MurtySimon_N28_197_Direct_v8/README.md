# Direct n=28 / Delta=15 / 197-edge checkpoint — v8

7 September 2026. **Candidate mathematics; full direct arithmetic checked; independent mathematical review OPEN.**

Read [PROOF.md](PROOF.md), [RESULTS.json](RESULTS.json) and [REVIEW_AND_HANDOFF.md](REVIEW_AND_HANDOFF.md). This package generates the entire **t=2** domain and excludes it with exact arithmetic. It does not reuse the t=1 survivor list as an input domain and does not use the separate weak-core density reduction.

The new direct route has 12,012 charging demand tuples;1,229 intervals expand to8,216,928 residual rows;5,154 pass the row screen,2,959 pass the projected screen and1,584 pass joint-column propagation. Exact shared, source-type and endpoint-type certificates exclude **787+790+7=1,584**, leaving **zero**. No branching or optimisation status alone is counted as proof.

The proof also excludes every other maximum degree at197, including the short Delta16 contradiction **26<=176/7**. Fan's strict197.2075 bound limits an order28 counterexample to at most197 edges. With the separately preserved complete196-edge equality route, this supplies a complete **candidate** order28 proof of at most196 edges, equality onlyK(14,14). Its structural and published inputs still require independent review; the theorem ledger is not promoted.

## Verify or reproduce

Use Python3.10+ without `-O`. Integrity checking requires only Python's standard library:

```sh
python3 -I -B replay.py --verify-only
```

The complete separate direct197 checker additionally requires **g++ with C++17 and Boost headers**, for the inherited finite-domain programs. It uses no optimisation solver, no network, and imports no discovery model:

```sh
python3 -I -B replay.py --check --output /absolute/path/to/new-v8-replay
```

This copies the immutable package into a fresh working directory, reconstructs every domain and every final certificate, and writes a new report. It also checks all-degree scope arithmetic. It does not relabel new timings as historical outputs. The stored completed clean replay report is `evidence/FULL_REPLAY_REPORT.json`; the direct checker report is `evidence/EXACT_CHECK_REPORT.json`.

Optional **discovery** uses the preserved fixed-scope scripts and SciPy. The optional wrapper runs in a new working copy:

```sh
python3 -I -B replay.py --rediscover --output /absolute/path/to/new-v8-discovery
```

New discovery coefficients/timings can differ with solver versions. Its output must pass the separate checker; no equality of arbitrary new solver outputs to old duals is assumed. Do not run the historical standalone examples inside copied dependencies as a v8 entry point. In particular the older v3 `verify_scope` is equality-only and is not used here; the generic tuple checker is called explicitly witht=2.

## Contents and boundaries

All sources, exact certificates, input tuples and rows, intermediate survivors, zero final survivors, reports and mathematical references needed for the new direct197 route are included. No previous ZIP is required to run this new checker. The separate complete196-edge chain is an explicit inherited dependency for equality, not secretly folded into the direct197 proof.

The `reviews/` directory records fresh complete v6 and LocalIncidence-v7 checking passes and the archive-intake evidence. Both original archives remain separate from the other repository's degree-load-v7 audit bundle. The reported old ZIP uploads were not accessible in the initial repository read-back; this local package does not claim to have attached or moved them.

Original referenced evidence, frozen n25/n27 proofs and the governed theorem ledger are unchanged. Both implementations were written by the same assistant. No independent expert acceptance, priority, full all-order theorem, new uniform degree coefficient or formal proof-kernel certification is claimed. Actual-graph regression samples contain no positive-surplus graph.
