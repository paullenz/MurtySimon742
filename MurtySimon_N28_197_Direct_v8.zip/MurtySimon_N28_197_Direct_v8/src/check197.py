#!/usr/bin/env python3
"""Complete independent t=2 check; no discovery code or optimisation library.

Finite scope: (n,Delta,m)=(28,15,197). Reconstruct the demand domain,
residual enumeration, projected and joint domains, and every final LP
contradiction. Standard-library Python plus a C++17 compiler/Boost for
inherited finite-domain checking. Graph-theoretic premises remain subject
to independent mathematical review.
"""
from __future__ import annotations
from pathlib import Path
from fractions import Fraction
from collections import Counter
from copy import deepcopy
import argparse, gzip, json, subprocess, sys, time
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'dependencies'), str(ROOT/'exploration')]
import v3_check as C
import check_projected
from check_constraints import rebuild, rebuild_types, verify_named
from check_total import rebuild_total

SCOPE = {'n':28, 'a':12, 'b':15, 'm':197, 't':2}

def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)

def load(path: Path):
    raw = path.read_bytes()
    if path.suffix == '.gz':
        raw = gzip.decompress(raw)
    return json.loads(raw)

def initial_record(rec: dict) -> None:
    s = rec['s']
    require(len(s)==12 and s==sorted(s) and all(type(x) is int and 0<=x<12 for x in s), 'Bad demand tuple')
    score = sum((Fraction(x*(13-2*x),12-x) for x in s), Fraction())
    require(score>=19, 'Demand tuple outside t=2 charging domain')
    charge = sum((Fraction(x*(x-1),12-x) for x in s), Fraction())
    lo = 15 - (-charge.numerator//charge.denominator)
    hi = min(sum(s)-4,64)
    require(rec['rmin']==lo and rec['rmax']==hi, 'Incorrect t=2 residual interval')
    if rec['certificate']['kind']=='OPEN':
        require(15<=lo<=hi<=63, 'Unsupported or empty open residual interval')
    else:
        C.verify_record(rec,12,15,2)

def initial_domain(data: dict, expected: int):
    require(all(type(data.get(k)) is int and data[k]==v for k,v in SCOPE.items()), 'Wrong fixed scope: expected n28/Delta15/m197/t2')
    seen=set();kept=[];counts=Counter()
    for rec in data['records']:
        key=tuple(rec['s'])
        require(key not in seen, 'Duplicate charging tuple')
        initial_record(rec);seen.add(key);kind=rec['certificate']['kind'];counts[kind]+=1
        if kind=='OPEN':kept.append({k:rec[k] for k in ('s','rmin','rmax')})
    require(len(seen)==expected, 'Incomplete charging domain')
    return kept,dict(counts)

def partition_final(inputs: list, certificates: list, survivors: list) -> None:
    source={x['position']:x for x in inputs}
    require(len(source)==len(inputs), 'Duplicate LP input')
    seen=set()
    for rec in certificates:
        pos=rec['position']
        require(type(pos) is int and pos in source and pos not in seen, 'Unknown/duplicate LP certificate row')
        require(rec['row']==source[pos]['row'] and rec['outcome']=='exact_rejection', 'Wrong certificate row/outcome')
        require(rec['phase'] in ('shared','typed','endpoint'), 'Unknown LP phase')
        seen.add(pos)
    for rec in survivors:
        pos=rec['position']
        require(pos in source and pos not in seen and rec==source[pos], 'Unknown/duplicate/modified final survivor')
        seen.add(pos)
    require(seen==set(source), 'Unaccounted LP input')

def must_reject(label, fn, report):
    try:fn()
    except (ValueError,KeyError,TypeError,IndexError):report[label]='REJECTED'
    else:raise ValueError('Damaged evidence wrongly accepted: '+label)

def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True,help='New directory for fresh checking outputs')
    args=parser.parse_args();out=args.output.resolve()
    require(not out.exists(), 'Output directory must be new')
    out.mkdir(parents=True)
    ev=ROOT/'evidence';started=time.monotonic();timings={};st=time.monotonic()
    expected=C.domain_count(12,15,2)
    initial=load(ev/'initial_certificates.json.gz')
    demands,kinds=initial_domain(initial,expected)
    require(demands==load(ev/'demands.json')==load(ev/'n28_demands.json'), 'Retained-demand handoff mismatch')
    text=str(len(demands))+'\n'+''.join(' '.join(map(str,r['s']+[r['rmin'],r['rmax']]))+'\n' for r in demands)
    require((ev/'demands.txt').read_text()==text, 'C++ input differs from independently verified domain')
    timings['initial']=time.monotonic()-st
    print('Demand domain checked',expected,len(demands),flush=True)
    st=time.monotonic();binary=out/'check_rows'
    subprocess.run(['g++','-O3','-std=c++17',str(ROOT/'src/check_rows.cpp'),'-o',str(binary)],check=True)
    result=subprocess.run([str(binary),str(ev/'demands.txt'),str(out/'rows.txt'),str(out/'bands.txt')],check=True,capture_output=True,text=True)
    row_report=json.loads(result.stdout)
    require(row_report==load(ev/'ROWS_REPORT.json')==load(ev/'ROWS_CHECK_REPORT.json'), 'Residual classification totals/digest disagree')
    for file in ('row_survivors.txt','check_row_survivors.txt','n28_surviving_rows.txt'):
        require((out/'rows.txt').read_bytes()==(ev/file).read_bytes(), 'Residual survivor handoff differs: '+file)
    for file in ('row_bands.txt','check_row_bands.txt'):
        require((out/'bands.txt').read_bytes()==(ev/file).read_bytes(), 'Per-demand residual band mismatch')
    timings['residual_enumeration']=time.monotonic()-st
    print('Residual domain checked',row_report,flush=True)
    st=time.monotonic();projected=check_projected.verify_directory(ROOT)
    timings['projected']=time.monotonic()-st
    print('Projected partition checked',projected,flush=True)
    # This module compiles its own separately written joint row checker.
    st=time.monotonic();import check_joint
    projected_rows=load(ev/'n28_projected_survivors.json')
    dispositions=[json.loads(line) for line in (ev/'joint197.jsonl').read_text().splitlines()]
    require(len(dispositions)==len(projected_rows), 'Incomplete joint dispositions')
    expected_lp=[];joint_rejects=0;reported_kinds=Counter()
    for index,(row,record) in enumerate(zip(projected_rows,dispositions)):
        require(record['index']==index, 'Unordered or duplicate joint index')
        s=demands[row[0]]['s'];require(row[1]==sum(row[2:]) and len(row)==17, 'Bad residual row')
        checked=check_joint.verify_row(s,row[2:],t=2,maxd=10)
        got=record['result'];reported_kinds[got['kind']]+=1
        require((checked is not None)==(got['kind']=='survivor'), 'Joint disposition differs at '+str(index))
        if checked is None:joint_rejects+=1
        else:
            for key,value in checked.items():
                require(got[key]==value, 'Incorrect retained joint state at '+str((index,key)))
            expected_lp.append({'position':index,'index':index,'row':row,'s':s,'state':got})
        if (index+1)%500==0:print('Joint checked',index+1,flush=True)
    inputs=load(ev/'JOINT_SURVIVORS.json.gz')
    require(inputs==expected_lp, 'Joint/LP handoff mismatch')
    require(reported_kinds==Counter(load(ev/'JOINT_REPORT.json')['counts']), 'Joint summary mismatch')
    timings['joint']=time.monotonic()-st
    print('Joint partition checked',len(projected_rows),joint_rejects,len(inputs),flush=True)
    st=time.monotonic();certs=load(ev/'LP_CERTIFICATES.json.gz');survivors=load(ev/'FINAL_SURVIVORS.json.gz')
    partition_final(inputs,certs,survivors)
    require([json.loads(line) for line in (ev/'LP_SWEEP.jsonl').read_text().splitlines()]==certs, 'Production sweep differs from complete certificate list')
    source={rec['position']:rec for rec in inputs};counts=Counter();builders={'shared':rebuild,'typed':rebuild_types,'endpoint':rebuild_total};first=None
    for n,rec in enumerate(certs,1):
        original=source[rec['position']]
        system=builders[rec['phase']](original['s'],original['row'][2:],original['state'],t=2)
        verify_named(system,rec['certificate']);counts[rec['phase']]+=1
        if first is None:first=(system,rec['certificate'])
        if n%300==0:print('LP certificates checked',n,dict(counts),flush=True)
    require(dict(counts)==load(ev/'LP_REPORT.json')['counts'] and not survivors, 'LP summary or zero-survivor claim differs')
    require('scipy' not in sys.modules and 'common_lp' not in sys.modules and 'degree_types' not in sys.modules, 'Verification imported discovery/optimisation library')
    timings['LP']=time.monotonic()-st
    # Negative controls target actual validation gates, without repeating the full sweep.
    controls={}
    bad=dict(initial,t=1);must_reject('wrong_t_scope',lambda:initial_domain(bad,expected),controls)
    bad=dict(initial,m=196);must_reject('wrong_edge_scope',lambda:initial_domain(bad,expected),controls)
    bad=dict(initial,records=initial['records'][:-1]);must_reject('omitted_demand',lambda:initial_domain(bad,expected),controls)
    bad=dict(initial,records=initial['records']+[initial['records'][0]]);must_reject('duplicate_demand',lambda:initial_domain(bad,expected),controls)
    dual=deepcopy(next(x for x in initial['records'] if x['certificate']['kind']=='dual'))
    dual['certificate']['weights']=[0]*12;dual['certificate']['mu']=0
    must_reject('zero_initial_dual',lambda:initial_record(dual),controls)
    must_reject('omitted_LP_disposition',lambda:partition_final(inputs,certs[:-1],survivors),controls)
    must_reject('duplicate_LP_disposition',lambda:partition_final(inputs,certs+[certs[0]],survivors),controls)
    bad=deepcopy(certs[0]);bad['row'][1]+=1
    must_reject('wrong_LP_input_row',lambda:partition_final(inputs,[bad]+certs[1:],survivors),controls)
    system,cert=first
    bad=deepcopy(cert);bad['rhs']-=1;must_reject('forged_LP_rhs',lambda:verify_named(system,bad),controls)
    bad=deepcopy(cert);bad['ub'].append(['not_a_constraint',1]);must_reject('unknown_LP_constraint',lambda:verify_named(system,bad),controls)
    bad=deepcopy(cert);bad['ub'][0][1]=-1;must_reject('negative_inequality_multiplier',lambda:verify_named(system,bad),controls)
    bad=deepcopy(cert);bad['eq'].append(bad['eq'][0]);must_reject('duplicate_LP_multiplier',lambda:verify_named(system,bad),controls)
    bad={'rhs':-1,'ub':[],'eq':[]};must_reject('empty_LP_contradiction',lambda:verify_named(system,bad),controls)
    report={'scope':SCOPE,'charging_domain':expected,'initial_counts':kinds,'retained_demands':len(demands),'residual_domain':row_report,'projected':projected,'joint':{'inputs':len(projected_rows),'exact_rejections':joint_rejects,'survivors':len(inputs),'surviving_demand_patterns':len({r['row'][0] for r in inputs})},'LP_exact_rejections':dict(counts),'LP_inputs':len(inputs),'final_survivors':len(survivors),'complete_fresh_domain_and_disjoint_handoffs':True,'all_joint_survivor_columns_caps_forced_labels_reconstructed':True,'every_LP_constraint_rebuilt_by_separate_checker':True,'discovery_or_optimisation_imported':False,'negative_controls':controls,'stage_seconds':timings,'seconds':time.monotonic()-started,'mathematical_status':'candidate; independent mathematical review OPEN','weak_core_reduction_used':False,'old_t1_survivors_used_as_t2_domain':False,'full_upstream_equality_chain_replayed_here':False}
    (out/'EXACT_CHECK_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,indent=2,sort_keys=True),flush=True)
if __name__=='__main__':main()
