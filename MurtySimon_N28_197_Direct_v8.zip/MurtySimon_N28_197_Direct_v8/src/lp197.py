"""Complete staged t=2 LP separation. Solver reports alone reject no row."""
from pathlib import Path
import sys,json,gzip,time,argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'dependencies'))
from common_lp import build,certificate,verify
from degree_types import build_types
from total_degree import build_total
from check_total import rebuild_total
from check_constraints import rebuild,rebuild_types,translate,verify_named,signature
STAGES=[('shared',build,rebuild),('typed',build_types,rebuild_types),('endpoint',build_total,rebuild_total)]

def solve(rec):
 start=time.monotonic();s,rho,state=rec['s'],rec['row'][2:],rec['state']; attempts=[]
 result={'position':rec['position'],'row':rec['row']}
 for phase,builder,checker in STAGES:
  m=builder(s,rho,state,t=2);ans=m.solve()
  attempts.append({'phase':phase,'status':int(ans.status),'variables':len(m.names),'equalities':len(m.eq),'inequalities':len(m.ub)})
  if ans.status!=2:continue
  cert=certificate(m)
  if cert is None:continue
  verify(m,cert);named=translate(m,cert);other=checker(s,rho,state,t=2)
  assert set(m.names)==other.variables
  assert {signature({m.names[j]:v for j,v in e.items()},b) for e,b in m.eq}==set(other.equalities)
  assert {signature({m.names[j]:v for j,v in e.items()},b) for e,b in m.ub}==set(other.inequalities)
  verify_named(other,named)
  result.update(outcome='exact_rejection',phase=phase,certificate=named);break
 else:result['outcome']='OPEN'
 result['attempts']=attempts;result['seconds']=time.monotonic()-start;return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=4);args=p.parse_args()
 todo=json.loads(gzip.decompress((ROOT/'evidence/JOINT_SURVIVORS.json.gz').read_bytes()))
 start=time.monotonic();cnt=Counter();out=[]
 with (ROOT/'evidence/LP_SWEEP.jsonl').open('w') as stream,ProcessPoolExecutor(max_workers=args.workers) as pool:
  for item in pool.map(solve,todo,chunksize=1):
   stream.write(json.dumps(item,separators=(',',':'))+'\n');stream.flush();out.append(item);cnt[item.get('phase',item['outcome'])]+=1
   if len(out)%50==0:print(len(out),dict(cnt),round(time.monotonic()-start,1),flush=True)
 certs=[r for r in out if r['outcome']=='exact_rejection'];open_positions={r['position'] for r in out if r['outcome']!='exact_rejection'}
 (ROOT/'evidence/LP_CERTIFICATES.json.gz').write_bytes(gzip.compress((json.dumps(certs,separators=(',',':'))+'\n').encode(),mtime=0))
 kept=[r for r in todo if r['position'] in open_positions]
 (ROOT/'evidence/FINAL_SURVIVORS.json.gz').write_bytes(gzip.compress((json.dumps(kept,separators=(',',':'))+'\n').encode(),mtime=0))
 report={'scope':{'n':28,'Delta':15,'m':197,'t':2},'input_rows':len(todo),'counts':dict(cnt),'remaining_rows':len(kept),'remaining_demand_patterns':len({r['row'][0] for r in kept}),'every_rejection_separately_checked':True,'full_constraint_sets_compared':True,'seconds':time.monotonic()-start}
 (ROOT/'evidence/LP_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print('DONE',report,flush=True)
if __name__=='__main__':main()
