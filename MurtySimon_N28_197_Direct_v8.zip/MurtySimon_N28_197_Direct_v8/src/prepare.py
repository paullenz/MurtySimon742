"""Fresh t=2 necessary demand domain; all accepted cuts independently rechecked."""
from pathlib import Path
import sys,json,gzip,time,collections
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'dependencies'))
import v3_discover as D
import v3_check as C

def main():
 start=time.monotonic();records=[];survivors=[];counts=collections.Counter()
 for s in D.demands(12,15,2):
  lo,hi=D.bounds(s,15,2);rec={'s':s,'rmin':lo,'rmax':hi}
  if lo>hi:cert={'kind':'bounds'}
  else:cert=D.support_certificate(s,15,hi) or D.dual_certificate(s,15,hi)
  if cert is None: survivors.append(rec.copy());cert={'kind':'OPEN'}
  else:C.verify_record(dict(rec,certificate=cert),12,15,2)
  rec['certificate']=cert;records.append(rec);counts[cert['kind']]+=1
  if len(records)%2000==0: print('initial',len(records),dict(counts),flush=True)
 assert len(records)==C.domain_count(12,15,2)
 out={'n':28,'a':12,'b':15,'m':197,'t':2,'records':records}
 (ROOT/'evidence/initial_certificates.json.gz').write_bytes(gzip.compress((json.dumps(out,separators=(',',':'))+'\n').encode(),mtime=0))
 (ROOT/'evidence/demands.json').write_text(json.dumps(survivors,separators=(',',':'))+'\n')
 text=str(len(survivors))+'\n'+''.join(' '.join(map(str,r['s']+[r['rmin'],r['rmax']]))+'\n' for r in survivors)
 (ROOT/'evidence/demands.txt').write_text(text)
 report={'scope':{'n':28,'Delta':15,'m':197,'t':2},'demand_domain':len(records),'counts':dict(counts),'domain_count_independently_recomputed':True,'retained_demands':len(survivors),'max_r':max((r['rmax'] for r in survivors),default=None),'seconds':time.monotonic()-start}
 (ROOT/'evidence/INITIAL_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
if __name__=='__main__':main()
