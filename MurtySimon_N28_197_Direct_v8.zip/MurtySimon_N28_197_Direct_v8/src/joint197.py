"""Full t=2 joint column propagation with separately implemented exact replay."""
from pathlib import Path
import sys,json,gzip,time,collections
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'exploration'))
import joint
import check_joint

def main():
 rows=json.loads((ROOT/'evidence/n28_projected_survivors.json').read_text());demands=json.loads((ROOT/'evidence/demands.json').read_text())
 out=[];kept=[];cnt=collections.Counter();begin=time.monotonic()
 with (ROOT/'evidence/joint197.jsonl').open('w') as stream:
  for index,row in enumerate(rows):
   s=demands[row[0]]['s'];got=joint.propagate(s,row[2:],t=2,dmax=10)
   check=check_joint.verify_row(s,row[2:],t=2,maxd=10)
   assert (check is not None)==(got['kind']=='survivor'),('disposition',index,got)
   if check is not None:
    for key,value in check.items():assert json.loads(json.dumps(got[key]))==value,('state',index,key)
    kept.append({'position':index,'index':index,'row':row,'s':s,'state':got})
   rec={'index':index,'result':got};stream.write(json.dumps(rec,separators=(',',':'))+'\n');stream.flush();out.append(rec);cnt[got['kind']]+=1
   if (index+1)%100==0:print(index+1,dict(cnt),round(time.monotonic()-begin,1),flush=True)
 (ROOT/'evidence/JOINT_SURVIVORS.json.gz').write_bytes(gzip.compress((json.dumps(kept,separators=(',',':'))+'\n').encode(),mtime=0))
 report={'rows':len(rows),'counts':dict(cnt),'survivors':len(kept),'demand_patterns':len({r['row'][0] for r in kept}),'all_dispositions_and_survivor_states_recomputed':True,'scope':{'n':28,'Delta':15,'m':197,'t':2},'seconds':time.monotonic()-begin}
 (ROOT/'evidence/JOINT_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print('DONE',report,flush=True)
if __name__=='__main__':main()
