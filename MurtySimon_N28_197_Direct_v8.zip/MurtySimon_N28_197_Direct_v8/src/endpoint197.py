"""Explicit t=2 endpoint-model scan; only separate exact certificates reject rows."""
from pathlib import Path
import os,sys,json,gzip,time,argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'dependencies'))
from total_degree import build_total
from check_total import rebuild_total
from common_lp import certificate,verify
from check_constraints import translate,verify_named,signature

def solve(rec):
 start=time.monotonic();s,rho,state=rec['s'],rec['row'][2:],rec['state']
 m=build_total(s,rho,state,t=2,local=False)
 ans=m.solve();result={'position':rec['position'],'row':rec['row'],'status':int(ans.status),'variables':len(m.names),'equalities':len(m.eq),'inequalities':len(m.ub)}
 if ans.status==2:
  cert=certificate(m)
  if cert is not None:
   verify(m,cert);named=translate(m,cert);other=rebuild_total(s,rho,state,t=2,local=False)
   assert set(m.names)==other.variables
   assert {signature({m.names[j]:v for j,v in e.items()},b) for e,b in m.eq}==set(other.equalities)
   assert {signature({m.names[j]:v for j,v in e.items()},b) for e,b in m.ub}==set(other.inequalities)
   verify_named(other,named);result['certificate']=named;result['outcome']='exact_rejection'
  else:result['outcome']='uncertified_numeric_infeasible'
 elif ans.status==0:result['outcome']='fractional_survivor'
 else:result['outcome']='unresolved_solver_status'
 result['seconds']=time.monotonic()-start
 return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--pilot',type=int,default=0);p.add_argument('--workers',type=int,default=2);args=p.parse_args()
 if args.pilot:
  rows=json.loads((ROOT/'evidence/n28_projected_survivors.json').read_text());demands=json.loads((ROOT/'evidence/demands.json').read_text());todo=[]
  for line in (ROOT/'evidence/joint197.jsonl').read_text().splitlines():
   rec=json.loads(line)
   if rec['result']['kind']=='survivor':
    i=rec['index'];row=rows[i];todo.append({'position':i,'s':demands[row[0]]['s'],'row':row,'state':rec['result']})
  todo=todo[:args.pilot];tag='ENDPOINT_PILOT'
 else:
  todo=json.loads(gzip.decompress((ROOT/'evidence/JOINT_SURVIVORS.json.gz').read_bytes()));tag='ENDPOINT'
 start=time.monotonic();cnt=Counter();out=[]
 with (ROOT/f'evidence/{tag}.jsonl').open('w') as stream, ProcessPoolExecutor(max_workers=args.workers) as pool:
  for item in pool.map(solve,todo,chunksize=1):
   stream.write(json.dumps(item,separators=(',',':'))+'\n');stream.flush();out.append(item);cnt[item['outcome']]+=1
   if len(out)%20==0 or args.pilot:print(len(out),dict(cnt),round(time.monotonic()-start,1),'last',item['position'],item['variables'],round(item['seconds'],2),flush=True)
 certs=[r for r in out if r['outcome']=='exact_rejection'];open_positions={r['position'] for r in out if r['outcome']!='exact_rejection'}
 (ROOT/f'evidence/{tag}_CERTIFICATES.json.gz').write_bytes(gzip.compress((json.dumps(certs,separators=(',',':'))+'\n').encode(),mtime=0))
 kept=[r for r in todo if r['position'] in open_positions]
 (ROOT/f'evidence/{tag}_SURVIVORS.json.gz').write_bytes(gzip.compress((json.dumps(kept,separators=(',',':'))+'\n').encode(),mtime=0))
 report={'scope':{'n':28,'Delta':15,'m':197,'t':2},'input_rows':len(todo),'counts':dict(cnt),'remaining_rows':len(kept),'remaining_demand_patterns':len({r['row'][0] for r in kept}),'pilot':bool(args.pilot),'every_rejection_separately_checked':True,'full_constraint_sets_compared':True,'seconds':time.monotonic()-start}
 (ROOT/f'evidence/{tag}_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print('DONE',report,flush=True)
if __name__=='__main__':main()
