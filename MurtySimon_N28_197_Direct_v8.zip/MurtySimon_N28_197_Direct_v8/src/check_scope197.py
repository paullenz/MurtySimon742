#!/usr/bin/env python3
"""Exact arithmetic for all n=28/m=197 degree cases and Fan's strict bound.

This checks arithmetic, not the external theorem or structural lemmas.
"""
from fractions import Fraction
from pathlib import Path
import argparse, json

def check():
    n,m=28,197
    assert n*14//2==196<m
    # For b=16, a=11 and t=5, the charging sum must be at least 26.
    a,b=11,16;t=m-b*(n-b)
    values=[Fraction(s*(a+1-2*s),a-s) for s in range(a)]
    upper=a*max(values);lower=b+2*t
    assert t==5 and max(values)==Fraction(16,7) and lower==26 and upper==Fraction(176,7)<lower
    high=[]
    for b in range(17,27):
        t=m-b*(n-b);left=b+2*t;right=(n-b)**2//4
        assert t>0 and left>right
        high.append({'Delta':b,'t':t,'required_left':left,'permitted_right':right,'rejected':True})
    fan=Fraction(n*n,4)+(n*n-Fraction(81,5)*n+56)/320
    assert fan==Fraction(78883,400) and 197<fan<198
    assert 27<m # universal-vertex critical graph is a star
    return {'scope':{'n':28,'m':197},'degree_0_through_14':'degree sum <=196','degree_15':'complete fresh t=2 numerical chain in check197.py',
      'degree_16':{'a':11,'t':5,'scores_by_s':[str(x) for x in values],'max_score':'16/7','upper_sum':'176/7','required_sum':26,'exact_gap':str(Fraction(lower)-upper),'rejected':True},
      'degrees_17_through_26':high,'degree_27':'universal-vertex critical graphs are stars with 27 edges',
      'all_degrees_covered_conditionally_on_structural_inputs':True,
      'Fan_strict_bound':str(fan),'Fan_decimal':'197.2075','Fan_integer_consequence':'m<=197',
      'Fan_source':'Tao Wang, On Murty-Simon Conjecture, arXiv:1205.4397, page 2, reporting Fan\u2019s theorem for n>=25',
      'Fan_original_proof_reaudited':False,'weak_core_density_reduction_used':False,'equality_at_196':'separate inherited LocalIncidence-v7 and Delta16/equality chain',
      'mathematical_status':'candidate; independent mathematical review OPEN'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);args=p.parse_args()
    if not __debug__:raise RuntimeError('Run without -O')
    result=check();text=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if args.output:args.output.write_text(text)
    print(text,end='')
if __name__=='__main__':main()
