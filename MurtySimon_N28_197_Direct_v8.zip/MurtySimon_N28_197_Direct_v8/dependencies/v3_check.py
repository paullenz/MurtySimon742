#!/usr/bin/env python3
"""Independent arithmetic replay, standard library only.
Does not import discovery code or trust saved capacities or domain counts.
Mathematical necessity of the inequalities remains a separate review obligation.
"""
from __future__ import annotations
from fractions import Fraction
from itertools import combinations_with_replacement
from math import comb, lcm
from functools import lru_cache
from pathlib import Path
import argparse, gzip, json, time


def require(test, message):
    if not test:
        raise ValueError(message)


@lru_cache(None)
def domain_count(a, b, t):
    multiplier = lcm(*range(1, a+1))
    scores = [x*(a+1-2*x)*(multiplier//(a-x)) for x in range(a)]
    target = (b+2*t)*multiplier
    # Direct enumeration, no discovery branch pruning.
    return sum(sum(scores[x] for x in seq) >= target
               for seq in combinations_with_replacement(range(a), a))


@lru_cache(None)
def rho_count(a, b, r):
    # Coefficient of X^b Y^r in product_{j=1}^a (1-X Y^j)^(-1).
    dp = [[0]*(r+1) for _ in range(b+1)]
    dp[0][0] = 1
    for j in range(1, a+1):
        for number in range(1, b+1):
            for total in range(j, r+1):
                dp[number][total] += dp[number-1][total-j]
    return dp[b][r]


def caps_from_scratch(s, rho):
    a, b = len(s), len(rho)
    upper = [min(a-r, b-1, len([x for x in s if x <= r])) for r in rho]
    rounds = 0
    while True:
        revised = []
        for u in range(b):
            capacities = sorted((rho[v]+upper[v] for v in range(b) if v != u), reverse=True)
            allowed = [0]
            for q in range(1, upper[u]+1):
                if len(capacities) >= q and capacities[q-1] >= q-1:
                    allowed.append(q)
            revised.append(max(allowed))
        if revised == upper:
            return upper, rounds
        upper = revised
        rounds += 1


def verify_row(s, rho, cert):
    require(cert is not None, 'An unrejected row remains.')
    caps, rounds = caps_from_scratch(s, rho)
    require(cert['caps'] == caps and cert['rounds'] == rounds, 'Incorrect row caps/refinement.')
    k = cert['k']
    require(type(k) is int and 1 <= k <= len(s), 'Invalid prefix.')
    labels = sorted(s, reverse=True)[:k]
    lhs = sum(labels)
    rhs = 0
    for idx, r in enumerate(rho):
        eligible = sum(1 for x in labels if x <= r)
        rhs += min(caps[idx], eligible)
    require(cert['demand'] == lhs and cert['capacity'] == rhs and lhs > rhs, 'Invalid row inequality.')


def verify_record(rec, a, b, t):
    s = rec['s']
    require(len(s) == a and s == sorted(s) and all(type(x) is int and 0 <= x < a for x in s), 'Invalid demand list.')
    score = sum((Fraction(x*(a+1-2*x), a-x) for x in s), Fraction())
    require(score >= b+2*t, 'Demand outside charging domain.')
    residual_charge = sum((Fraction(x*(x-1), a-x) for x in s), Fraction())
    lo = b - (-residual_charge.numerator//residual_charge.denominator)
    hi = min(sum(s)-2*t, a*(a-1)//2-t)
    require(rec['rmin'] == lo and rec['rmax'] == hi, 'Incorrect residual interval.')
    cert = rec['certificate']
    kind = cert['kind']
    if kind == 'bounds':
        require(lo > hi, 'Invalid interval rejection.')
    elif kind in ('source_count', 'support'):
        h = cert['h']
        require(type(h) is int and 2 <= h < a, 'Invalid demand threshold.')
        labels = [x for x in s if x >= h]
        require(bool(labels), 'Empty high-demand set.')
        k = len(labels)
        zmax = min(b, (hi-b)//(h-1))
        require(cert['zmax'] == zmax, 'Incorrect support bound.')
        if kind == 'source_count':
            require(max(labels) > zmax, 'Invalid source-count cut.')
        else:
            candidates = []
            K = a-k+h
            # Independently enumerate (z,p) and test feasibility rather than
            # using the discovery implementation's closed-form pmax.
            for z in range(zmax+1):
                for p in range(z+1):
                    pairs = comb(z, 2)-comb(z-p, 2)
                    if p and (a-h < K+1 or p*(K+1) > pairs):
                        continue
                    candidates.append((z-p)*min(k, K, a-h) + min(p*min(k, a-h), pairs))
            upper = max(candidates)
            require(cert['demand'] == sum(labels) and cert['capacity'] == upper and sum(labels) > upper,
                    'Invalid support-pair inequality.')
    elif kind == 'dual':
        y, mu, L = cert['weights'], cert['mu'], cert['scale']
        require(len(y) == a and all(type(x) is int and x >= 0 for x in y), 'Invalid dual weights.')
        require(type(mu) is int and type(L) is int and L > 0, 'Invalid dual scale.')
        labels = sorted(s, reverse=True)
        lhs = b*mu
        for k in range(a):
            lhs += y[k]*sum(labels[:k+1])
        for j in range(1, a+1):
            use = mu
            for k in range(a):
                use += y[k]*min(a-j, sum(x <= j for x in labels[:k+1]))
            require(use <= L*(j-1), 'Dual fails a residual-type constraint.')
        require(lhs > L*(hi-b), 'Dual does not give a strict contradiction.')
    elif kind == 'residual_rows':
        rows = cert['rows']
        seen = set()
        sizes = {r:0 for r in range(lo, hi+1)}
        for row in rows:
            rho = row['rho']
            key = tuple(rho)
            require(len(rho) == b and rho == sorted(rho) and all(type(x) is int and 1 <= x <= a for x in rho),
                    'Invalid residual list.')
            require(key not in seen, 'Duplicate residual list.')
            seen.add(key)
            require(sum(rho) in sizes, 'Residual sum outside interval.')
            sizes[sum(rho)] += 1
            verify_row(s, rho, row['certificate'])
        for r, actual in sizes.items():
            require(actual == rho_count(a, b, r), 'Incomplete residual domain.')
    else:
        raise ValueError('Unknown certificate kind.')
    return kind


def verify_scope(data):
    n,b,a,m,t = (data[x] for x in ('n','b','a','m','t'))
    require(a == n-1-b and m == n*n//4 and t == m-b*(n-b) and t > 0, 'Bad scope parameters.')
    seen=set(); kinds={}; rows=0
    for rec in data['records']:
        key=tuple(rec['s'])
        require(key not in seen, 'Duplicate demand list.')
        seen.add(key)
        kind=verify_record(rec,a,b,t)
        kinds[kind]=kinds.get(kind,0)+1
        if kind=='residual_rows': rows+=len(rec['certificate']['rows'])
    expected=domain_count(a,b,t)
    require(len(seen)==expected,'Incomplete charging domain.')
    c=data['counts']
    require(c['charging_domain']==expected and c['residual_rows']==rows and c['surviving_rows']==0,
            'Incorrect saved summary.')
    require(c['bound_rejections']==kinds.get('bounds',0)
            and c['support_rejections']==kinds.get('source_count',0)+kinds.get('support',0)
            and c['dual_rejections']==kinds.get('dual',0)
            and c['residual_stage_demands']==kinds.get('residual_rows',0),'Incorrect stage counts.')
    return {'n':n,'b':b,'demand_profiles':expected,'residual_profiles':rows,'kinds':kinds,
            'all_exact_certificates_pass':True,'complete_arithmetic_coverage':True,
            'graph_theoretic_lemmas_formally_verified':False,'external_review':'OPEN'}


def negative_controls(data):
    from copy import deepcopy
    cases=[]
    dual=next(r for r in data['records'] if r['certificate']['kind']=='dual')
    bad=deepcopy(dual);bad['certificate']['weights']=[0]*data['a'];bad['certificate']['mu']=0
    cases.append(('zero_dual',bad))
    residual=next(r for r in data['records'] if r['certificate']['kind']=='residual_rows')
    bad=deepcopy(residual);bad['certificate']['rows'].pop()
    cases.append(('missing_residual_row',bad))
    bad=deepcopy(residual);bad['certificate']['rows'][0]['certificate']['caps']=[0]*data['b']
    cases.append(('forged_caps',bad))
    results={}
    for name,case in cases:
        try: verify_record(case,data['a'],data['b'],data['t'])
        except ValueError:results[name]='REJECTED'
        else:raise ValueError('Negative control was wrongly accepted: '+name)
    bad=deepcopy(data);bad['records'].pop()
    try:verify_scope(bad)
    except ValueError:results['missing_demand_profile']='REJECTED'
    else:raise ValueError('Missing demand profile was wrongly accepted.')
    return results


def main():
    p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,default=Path(__file__).parent/'evidence')
    p.add_argument('--output',type=Path)
    args=p.parse_args();reports=[];t0=time.monotonic();first=None
    for n,b in [(28,16),(30,17),(33,19)]:
        data=json.loads(gzip.decompress((args.evidence/f'n{n}_delta{b}.json.gz').read_bytes()))
        reports.append(verify_scope(data))
        print(json.dumps(reports[-1],sort_keys=True),flush=True)
        if first is None:first=data
    report={'scopes':reports,'negative_controls':negative_controls(first),'seconds':time.monotonic()-t0}
    print(json.dumps({'negative_controls':report['negative_controls']},sort_keys=True))
    if args.output:args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
