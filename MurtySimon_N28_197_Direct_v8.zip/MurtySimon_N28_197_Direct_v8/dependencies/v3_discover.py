#!/usr/bin/env python3
"""Demand-only necessary-condition scanner. No graph-realizability assertion.
SciPy proposes dual weights; all accepted dual contradictions use exact integers.
The independent checker uses only the standard library and imports no discovery code.
"""
from __future__ import annotations
from fractions import Fraction
from functools import lru_cache
from math import comb, lcm
from pathlib import Path
import argparse, gzip, json


def bounds(s: list[int], b: int, t: int) -> tuple[int, int]:
    a = len(s)
    charge = sum((Fraction(x*(x-1), a-x) for x in s), Fraction())
    lower = b + (charge.numerator + charge.denominator - 1)//charge.denominator
    return lower, min(sum(s)-2*t, comb(a, 2)-t)


def demands(a: int, b: int, t: int):
    """All sorted demand multisets satisfying the weak charging condition."""
    scale = lcm(*range(1, a+1))
    f = [x*(a+1-2*x)*(scale//(a-x)) for x in range(a)]
    tail = [max(f[x:]) for x in range(a)]
    target = (b+2*t)*scale
    chosen: list[int] = []
    def visit(left: int, last: int, score: int):
        if left == 0:
            if score >= target:
                yield chosen.copy()
            return
        if score + left*tail[last] < target:
            return
        for x in range(last, a):
            if score+f[x]+(left-1)*tail[x] < target:
                continue
            chosen.append(x)
            yield from visit(left-1, x, score+f[x])
            chosen.pop()
    yield from visit(a, 0, 0)


@lru_cache(None)
def capacity(a: int, k: int, h: int, z: int) -> int:
    K = a-k+h
    low = min(k, K, a-h)
    high = min(k, a-h)
    pmax = min(z, max(0, 2*z-2*K-3)) if a-h >= K+1 else 0
    return max((z-p)*low + min(p*high, p*z-p*(p+1)//2)
               for p in range(pmax+1))


def support_certificate(s: list[int], b: int, rmax: int):
    a = len(s)
    for h in range(2, a):
        high = [x for x in s if x >= h]
        if not high:
            continue
        zmax = min(b, (rmax-b)//(h-1))
        if max(high) > zmax:
            return {'kind':'source_count', 'h':h, 'zmax':zmax}
        cap = max(capacity(a, len(high), h, z) for z in range(zmax+1))
        if sum(high) > cap:
            return {'kind':'support', 'h':h, 'zmax':zmax,
                    'demand':sum(high), 'capacity':cap}
    return None


def dual_certificate(s: list[int], b: int, rmax: int):
    from scipy.optimize import linprog
    a = len(s)
    ss = sorted(s, reverse=True)
    D = [sum(ss[:k]) for k in range(1, a+1)]
    A = [[min(a-j, sum(x <= j for x in ss[:k])) for j in range(1, a+1)]
         for k in range(1, a+1)]
    result = linprog([-x for x in D+[b]],
                     A_ub=[[A[k][j] for k in range(a)]+[1] for j in range(a)],
                     b_ub=list(range(a)), bounds=[(0, None)]*a+[(None, None)],
                     method='highs')
    if not result.success:
        return None   # Failure, infeasibility status, or noncompletion proves nothing.
    y = [max(Fraction(), Fraction(float(x)).limit_denominator(10000))
         for x in result.x[:a]]
    mu = min(Fraction(j)-sum(y[k]*A[k][j] for k in range(a)) for j in range(a))
    score = sum(y[k]*D[k] for k in range(a)) + b*mu
    if score <= rmax-b:
        return None
    scale = lcm(mu.denominator, *(x.denominator for x in y))
    yi = [int(x*scale) for x in y]
    mui = int(mu*scale)
    # Exact recheck, not an LP status, is the acceptance criterion.
    assert all(mui+sum(yi[k]*A[k][j] for k in range(a)) <= scale*j for j in range(a))
    assert sum(yi[k]*D[k] for k in range(a))+b*mui > scale*(rmax-b)
    return {'kind':'dual', 'scale':scale, 'weights':yi, 'mu':mui}


@lru_cache(None)
def residual_profiles(a: int, b: int, total: int):
    out = []
    prefix = []
    def visit(left, last, remaining):
        if left == 0:
            if remaining == 0:
                out.append(tuple(prefix))
            return
        for x in range(last, min(a, remaining//left)+1):
            if remaining-x > (left-1)*a:
                continue
            prefix.append(x)
            visit(left-1, x, remaining-x)
            prefix.pop()
    visit(b, 1, total)
    return tuple(out)


def row_caps(s: list[int], rho: tuple[int, ...]) -> tuple[list[int], int]:
    a, b = len(s), len(rho)
    c = [min(a-x, b-1, sum(si <= x for si in s)) for x in rho]
    rounds = 0
    while True:
        new = []
        for u, cu in enumerate(c):
            q = cu
            while q and sum(rho[w]+c[w] >= q-1 for w in range(b) if w != u) < q:
                q -= 1
            new.append(q)
        if new == c:
            return c, rounds
        c = new
        rounds += 1


def row_certificate(s: list[int], rho: tuple[int, ...]):
    c, rounds = row_caps(s, rho)
    ss = sorted(s, reverse=True)
    for k in range(1, len(s)+1):
        demand = sum(ss[:k])
        upper = sum(min(cu, sum(x <= j for x in ss[:k])) for j, cu in zip(rho, c))
        if demand > upper:
            return {'k':k, 'demand':demand, 'capacity':upper, 'caps':c, 'rounds':rounds}
    return None


def run_scope(n: int, b: int) -> dict:
    a = n-1-b
    m = n*n//4
    t = m-b*(n-b)
    if a < 2 or t <= 0:
        raise ValueError('This scanner requires a >= 2 and strict positive surplus.')
    records = []
    counts = {'charging_domain':0, 'bound_rejections':0, 'support_rejections':0,
              'dual_rejections':0, 'residual_stage_demands':0,
              'residual_rows':0, 'surviving_rows':0}
    for s in demands(a, b, t):
        counts['charging_domain'] += 1
        lo, hi = bounds(s, b, t)
        rec = {'s':s, 'rmin':lo, 'rmax':hi}
        if lo > hi:
            rec['certificate'] = {'kind':'bounds'}
            counts['bound_rejections'] += 1
        else:
            cert = support_certificate(s, b, hi)
            if cert is not None:
                counts['support_rejections'] += 1
                rec['certificate'] = cert
            else:
                cert = dual_certificate(s, b, hi)
                if cert is not None:
                    counts['dual_rejections'] += 1
                    rec['certificate'] = cert
                else:
                    counts['residual_stage_demands'] += 1
                    rows = []
                    for r in range(lo, hi+1):
                        for rho in residual_profiles(a, b, r):
                            c = row_certificate(s, rho)
                            rows.append({'rho':list(rho), 'certificate':c})
                            counts['residual_rows'] += 1
                            counts['surviving_rows'] += c is None
                    rec['certificate'] = {'kind':'residual_rows', 'rows':rows}
        records.append(rec)
    return {'schema':'demand-support-v3.1', 'n':n, 'b':b, 'a':a, 'm':m, 't':t,
            'status':'CANDIDATE; arithmetic certificates only; external review OPEN',
            'counts':counts, 'records':records}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path(__file__).parent/'evidence')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    for n, b in [(28,16), (30,17), (33,19)]:
        data = run_scope(n, b)
        raw = (json.dumps(data, sort_keys=True, separators=(',', ':'))+'\n').encode()
        (args.output/f'n{n}_delta{b}.json.gz').write_bytes(gzip.compress(raw, mtime=0))
        print(json.dumps({'n':n, 'b':b, **data['counts']}, sort_keys=True))
if __name__ == '__main__':
    main()
