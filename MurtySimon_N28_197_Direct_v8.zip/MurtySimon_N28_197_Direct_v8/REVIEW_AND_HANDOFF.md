# Review and handoff — direct197 v8

## Completed mathematical and numerical scope

All newly generated t=2 states for n28/Delta15/m197 are excluded. The direct197 candidate has no surviving row and no unclosed integer branch. The final 1,584 certificates split into 787 shared-adjacency,790 source-degree-type and7 endpoint-type contradictions. Complete domain coverage begins at12,012 charging demand tuples and8,216,928 residual rows. It does not start from the old equality survivor file.

The separate checker reconstructs every tuple, row classification, projected partition, joint survivor domain and final named-variable model. Its verification imports no discovery or optimisation library. It requires Python and C++17/Boost for the inherited joint polynomial. Its13 deliberate damaged-evidence controls pass; the projected checker provides two additional controls. The failed first isolated-Python launch is preserved; its module-search-path fix preceded the successful arithmetic check and did not change evidence.

The exact Delta16 charging contradiction26<=176/7 and the ten Delta17..26 h-index comparisons, together with elementary degree-sum/star cases, close every possible maximum degree at197. Fan's externally cited strict197.2075 bound then gives the full upper-bound assembly. Fan's original proof has not been re-audited here.

The complete candidate equality characterization at196 is inherited from LocalIncidence v7 and its upstream chain, plus the separate Delta16 equality exclusion. This session rechecked all original v6 and LocalIncidence-v7 exact calculations in fresh copies and checked their archive hashes. It did not replay every old v3/v4/v5 equality-level computation. Their mathematical coverage remains an explicit dependency. The new197 computation, by contrast, has its own full fresh-domain replay in this package.

## Distinct other-chat route

The repository already contained a separate degree-load-v7 proof with a weak-core density reduction. It uses different final models and a173/215 partition, not the LocalIncidence22/19/347 partition. It claims an alternative complete order28 candidate. The direct197 route removes the need to use that density-scope theorem in this chat's assembly. Shared methods and authorship mean the routes are not independent expert endorsements.

The extra source-relative residual inequality used by the endpoint model needs quasi-edges for missing pairs inside A. Full criticality is available for the original197-edge graph. This package does not assert that this inequality transfers to every weaker active B-quasi-edge core.

## Regressions and trust boundary

The fresh old-archive checks reran the saved graph-to-model lifts, including fractional symmetry averages, hand arguments and damaged-evidence tests. Those actual-graph samples contain no positive-surplus graph. V8 introduces a new fixed-parameter application of previously derived models and a separate end-to-end checker; it does not claim a new positive-surplus actual-graph regression sample. The fixed t=2 coefficients are explicitly propagated through every adapted stage.

Exact integer certificates establish infeasibility of the constructed necessary-condition systems. They do not, by themselves, prove that every graph maps into those systems. The quasi-edge, activity, residual injection, source/supplement and symmetry-lift arguments must still withstand independent mathematical review. Both implementations were authored by the same assistant. No formal proof kernel, novelty assessment or independent expert reproduction is claimed.

## Preservation and publication

All data and source required for the *new direct197 check* are in this package. There are no binary library dependencies in the payload; the checker compiles its own small C++ programs in fresh temporary/output locations. Earlier proof texts are copied unchanged under references and original new-run certificates/timings are preserved. The twenty-row endpoint pilot overlaps production and is not counted twice.

The immutable original v6 and LocalIncidence-v7 archives remain separately downloadable. During repository intake the reported uploads were not visible on main or the listed alternate branch, and the v6 blob reference returned HTTP422. The documentation-only reconciliation was successfully committed and read back at0928816678af1d2628920a967129faa194603035. That completed documentation commit must not be described as completed binary-archive relocation. See reviews/INTAKE_PUBLICATION_RECEIPT.json and PUBLICATION_STATUS.json. Frozen n25/n27 proofs and the governed theorem ledger are unchanged.

## Next useful work

The next priority is independent scrutiny of the complete order28 candidate, particularly domain coverage, quasi-edge injections and graph-to-fractional-model lifting. The new direct197 route provides a density-scope alternative to the weak-core reduction. For further general-order research, extract reusable all-order consequences of the successful endpoint-type constraints rather than treating a finite order28 calculation as an all-order theorem. No order above28 is completed here.

## Final packaging note

The clean full check used the pre-seal manifest covering79 payloads and left them unchanged. Its report and logs, the additional fresh v3/Delta16 check report, and this final packaging note were then added without changing the checked mathematical code or certificate files. The final manifest covers all payloads, including those reports. The optional new-discovery orchestration was not run as one combined command in this session; all its discovery stages were executed separately before the clean full separate-check replay. Only `--check` is the tested complete wrapper invocation recorded here.
