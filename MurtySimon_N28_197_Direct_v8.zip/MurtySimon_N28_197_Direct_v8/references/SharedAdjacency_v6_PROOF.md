# Shared columns, degree-type transport and threshold activation — v6

7 September 2026. Directed by Paul Lenz; derivations, software and internal checking by ChatGPT/Geeps.

**Status: candidate mathematics; exact certificate arithmetic REPRODUCED; independent mathematical review OPEN.** This checkpoint rejects 6,530 of the 6,918 preserved v5 necessary-condition rows at (n, Delta, m)=(28,15,196), leaving 388 rows in 167 demand patterns. It does not complete order 28, cover higher edge counts, or improve the earlier uniform maximum-degree coefficient. A numerical row is not a graph. All implementations here are by the same assistant.

## 1. Baseline and the logical claim being checked

The durable baseline is paullenz/MurtySimon25 commit `00ad1a511971397fcd8a4341b021493c2383252e`, following the v5 publication commit `d346ec6d01c49de9a082866ceda6a65efe180b05`. The original v5 ZIP has SHA-256 `79bdbdf02b23b9eef38e964b54eb300921b24d539014f07b476655d1575e63b6`. Its 54 payload hashes were checked before this continuation. Its entire historical calculation was not rerun here.

`dependencies/v5_FINAL_SURVIVORS.json.gz` losslessly preserves the original v5 frontier, including each row's option domains, safe source caps and forced selections. `dependencies/n28_demands.json.gz` preserves the corresponding demand patterns. Their uncompressed hashes are pinned in `dependencies/SOURCES.json`. Both original row identifiers and positions in the 6,918-row input are retained; these are different indices.

The new finite claim is conditional in the usual necessary-condition sense: every graph that maps to an input row must map into the new relaxation. An exact contradiction for that relaxation rejects the entire row. Completeness of the prior reductions, including the v5 option domains, caps and forced sets, remains an inherited mathematical dependency. The v6 checker reconstructs the new model and its contradictions; it does not certify every historical graph lemma by reading a status label.

## 2. Notation and inherited selected-edge facts

Let G be a simple diameter-two edge-critical graph. Stars and complete bipartite graphs are handled separately. For the remaining case, the published complement correspondence gives a 3-total-domination-edge-critical graph H=complement(G) [1]. Choose v of minimum H-degree a, put A=N_H(v), B=V(H) minus N_H[v], and b=|B|=Delta(G); n=a+b+1. Let F be the complement of H[A], with degrees d_i.

For every missing unordered H[B]-pair, choose exactly one cross quasi-edge ui -> w, with u,w in B and i in A. The existing H-edge ui has open-neighbourhood union V(H) minus {w}. Its unique exception w is its supplement. Different missing pairs choose different edges; a source's selected labels and supplements are distinct. Other H[A,B]-edges are residual.

Write rho_u and R_i for residual degrees at B and A, respectively, r for their common total, q_u for selected outgoing degrees, p_u for incoming uses as a supplement, x_i for the selected degree of label i, and Q=sum q_u=sum p_u=sum x_i. Set

    t=m-b(n-b), ell=b-a-1=2b-n, s_i=max(0,d_i-R_i).

The earlier candidate arguments [2–4] supply

    sum R_i=sum rho_u=r,  sum d_i=2(r+t),  x_i>=s_i,
    q_u+rho_u<=a,  p_u<=rho_u+ell,  Q<=r+ell*b.

At positive t all rho_u>=1. For every selected ui -> w,

    d_i<=rho_u+R_i,
    d_i<=rho_u+rho_w,
    d_i<=rho_u+q_u-1,
    rho_w+q_w>=q_u-1,
    R_i+x_i>=q_u+p_u.                         (2.1)

The incoming bound follows directly from d_H(u)=b-1+rho_u-p_u>=a. The last bound in (2.1) follows because i must neighbour u and every missing-pair neighbour of u other than its own exception w. It uses total pair degree, not just outgoing degree.

For this finite run, a=12, b=15, t=1 and ell=2 throughout. Zero-demand labels remain allowed to have selected edges: replacing x_i by s_i would be invalid.

## 3. Shared-neighbourhood and selected-internal-edge lemmas

### 3.1 A union, not a maximum of separate bounds

Let S_u be the set of selected labels at u. If uj is absent in H, each quasi-edge ui with i in S_u must dominate j through ij. Thus ij belongs to H[A]. All sources missing j impose their requirements on the same graph H[A], giving

    d_j <= a-1 - | union_{u:uj absent} S_u |.   (3.1)

In particular, if u and w both miss j,

    d_j <= a-1-q_u-q_w+|S_u intersect S_w|.

There is no double-counting of shared selected labels: they occur once in the union. A five-label example illustrates the gain. Selected sets {0,1} and {1,3}, both at sources missing label 4, force three H[A]-neighbours of 4. Then d_4<=1, although each separate two-label bound permits d_4=2. This example is a local consistency example, not a critical graph.

The implemented relaxation has one common F-edge variable per label pair and the inequalities F_ij+S_ui<=S_uj+R_uj+1, in both directions. At an integral graph point these impose (3.1). Their fractional relaxation need not capture the full union cardinality; no stronger unimplemented union constraint is claimed in the scan.

### 3.2 Selected labels adjacent in F require residual column capacity

For every source u and selected label i,

    R_i >= |N_F(i) intersect S_u|.              (3.2)

For each j in this intersection, let w_j be the supplement of uj. It differs from the supplement of ui. The quasi-edge ui must dominate w_j, forcing iw_j, because uw_j is absent. The edge iw_j is residual: i and w_j both miss the A-vertex j, so iw_j cannot be selected with its only exception in B. Distinct j have distinct w_j, giving distinct residual edges at i.

For every actual selected ui -> w and every other selected label j at u, wj is present. If ij is an F-edge, wj is residual, since w and j both miss i. These implications also constrain the shared model.

## 4. The common fractional model and why symmetry is safe

The new model uses a single collection of column choices throughout all source constraints and one common F structure. It is still a **fractional relaxation**, not an assertion that a single integral column assignment or graph exists.

Partition A into classes with identical demand s_i, identical ordered option domains and identical forced-source masks. Partition B into classes with identical rho_u, cap c_u and forced-label membership vector. Let their sizes be N_g and M_k.

We do not assume that an unknown graph has automorphisms or constant entries within these classes. Instead, average its labelled indicator variables over all independent permutations within the classes. Every displayed constraint is linear and invariant under these permutations. Consequently the averaged point remains feasible. A non-symmetric graph therefore survives the symmetry reduction. This is the universal justification for compression; finite graph-lift tests are only regression tests of its implementation.

An option o at label class g is an inherited triple (d,R,z), with z=R+s-d. Define y_go as its probability, S_kgo and A_kgo as the selected and residual status probabilities conditional jointly on that option. Missing status is the remaining probability, not an extra edge. Define S_kg=sum_o S_kgo, A_kg=sum_o A_kgo, d_g=sum_o d(o)y_go, R_g=sum_o R(o)y_go.

All variables are nonnegative and at most one. The common marginal and ledger equations are

    sum_o y_go=1,
    sum_g N_g R_g=r,  sum_g N_g d_g=2(r+t),
    sum_g N_g A_kg=rho_k,
    q_k=sum_g N_g S_kg<=c_k,
    sum_k M_k A_kg=R_g,  x_g=sum_k M_k S_kg>=s_g.

For each source-label-option, S_kgo+A_kgo<=y_go; equality is required if missing status is not permitted. Forced selections give S_kg=1. Only safe possible statuses are retained. A selected status requires rho_k>=s_g, d(o)<=rho_k+c_k-1, space for residual and selected neighbours in the column, and at least one possible distinct supplement satisfying (2.1), including the exclusion of a supplement forced to select the same label. Residual status requires R(o)>=1 and is forbidden at a forced selection. Missing status requires d(o)+f_k<=a-1 and R(o)+s_g<=b-1, where f_k is the number of forced labels. These are necessary, not sufficient, status conditions.

There is a common F_gh for every possible unordered class pair, including g=h when N_g>=2. Its degree equation is

    sum_h (N_h-[g=h]) F_gh=d_g.

For every source class and F pair, the model imposes the averaged versions of the two implications in Section 3.1. In addition, a variable V_kgh represents F_ij*S_ui*S_uj at graph points, with

    V_kgh >= F_gh+S_kg+S_kh-2,
    sum_h (N_h-[g=h]) V_kgh <= R_g.           (4.1)

This is a relaxation of (3.2). It does not insist that V equal a product at arbitrary fractional points.

Two safe big-M inequalities retain the selected/missing source-degree tests:

    d_g-q_k+M*S_kg <= rho_k-1+M,
    d_g+q_k-M'*(S_kg+A_kg) <= a-1,

where M=max(0,dmax_g-rho_k+1), and M'=max(0,dmax_g+c_k-a+1). At integral indicators, these give the desired bound when selected or missing, respectively, and a safe redundant bound in the other case.

### 4.1 Shared source–supplement pairs

Let T_klg be the probability of the specific triple ui -> w, for distinct u in source class k, w in class l and i in label class g. A whole triple class is omitted only when the inherited bounds rule out every member. Its outgoing marginal is

    sum_l (M_l-[k=l]) T_klg=S_kg.

The incoming marginal p_k is obtained by summing over source classes and label multiplicities. It obeys p_k<=rho_k+ell. Each unordered B-pair can support at most one selected triple, giving

    sum_g N_g (T_klg+T_lkg)<=1,

with the two equal orientation terms both counted when k=l. Graph averaging over distinct ordered pairs justifies this factor of two; loops are never included.

The supplement must miss its triple's label:

    T_klg+S_lg+A_lg<=1.

For each other label j in class h, the model also imposes

    T_klg+S_kh-S_lh-A_lh<=1,
    T_klg+F_gh+S_kh-A_lh<=2.

For g=h the equations are used only when two distinct labels exist. Finally, (2.1) gives

    q_k+p_k+(b-1)S_kg-(R_g+x_g)<=b-1.

All these equations are necessary at an actual graph point and after averaging. An integral solution of the listed relaxation would still not enforce every original criticality condition.

## 5. Coupling integer degree types to the same marginals

The base relaxation is too permissive about a source's actual outgoing degree. The next extension keeps a distribution W_kq over each possible **integer** q, from f_k through c_k. This is a distribution across vertices and permutations, not the false assumption that the average q_k is an integer.

For each label, option and q, introduce selected, residual and missing event variables. Their sum over statuses and options is W_kq. Their sum over q and statuses equals the SAME y_go used by every source class. Selected and residual sums over q equal S_kgo and A_kgo. At fixed q, their weighted label counts are exactly

    sum_{g,o} N_g selected(k,g,o,q)=q W_kq,
    sum_{g,o} N_g residual(k,g,o,q)=rho_k W_kq.

A selected event at degree q is allowed only if q>=1, rho_k>=s_g, d(o)<=rho_k+q-1, a distinct permitted supplement exists, and the column has room. A missing event is allowed only if d(o)+q<=a-1 and R(o)+s_g<=b-1. Forced selections disallow residual or missing events. Thus it is no longer possible to average two source degrees while using the selected-status restrictions of a third degree.

To couple supplements as well, P_klqv represents a selected ordered pair with source degree q and supplement degree v, after summing out its label. It exists only if

    q>=1 and v+rho_l>=q-1.

It satisfies

    sum_{q,v} P_klqv=sum_g N_g T_klg,
    sum_{l,v}(M_l-[k=l]) P_klqv=q W_kq,
    sum_{l,v}(M_l-[k=l]) P_lkvq<=(rho_k+ell) W_kq.

The common column choices, selected/residual status, outgoing degree, pair use and incoming capacity are now linked. This remains an outer fractional relaxation. It is not a complete joint distribution of all edges or proof of graph realizability.

## 6. Exact arithmetic certificates, and safe bounded branching

Write each model as Ax<=b, Ex=f, x>=0. A certificate supplies integer lambda>=0 and signed integer mu such that

    A^T lambda+E^T mu>=0 componentwise,
    b^T lambda+f^T mu<0.                        (6.1)

Summing the constraints would make a nonnegative expression strictly negative. This proves a contradiction by exact integer arithmetic.

SciPy/HiGHS [5] proposes coefficients. The search rounds them at recorded integer scales and repairs any coefficient deficit using explicit x_j<=1 inequalities. Only a final exact verification of (6.1) accepts a rejection. Solver infeasibility messages, feasible fractional outputs, floating-point tolerances and timeouts are not certificates.

The separate standard-library checker reconstructs constraints using named variables and a different expression-building implementation. The exported certificates identify canonical constraint expressions by SHA-256. Before accepting each exported certificate, the two builders were compared on the entire variable set and constraint set, not just the rows receiving nonzero weights. Duplicate identical constraints are harmless and their weights are combined. `check_all.py` requires no SciPy or discovery-model import.

### 6.1 Integer graph counts, not binary symmetry averages

When a model survives, branching is permitted on quantities that are integral for every lifted actual graph:

- N_g*y_go: number of labels taking option o;
- N_g*N_h*F_gh, or choose(N_g,2)*F_gg: number of F edges in a class block;
- M_k*N_g*S_kg and M_k*N_g*A_kg: selected or residual incidence counts;
- M_k*W_kq: number of sources of degree q.

For such a count L, the children L<=h and L>=h+1 cover all graph possibilities for any integer h. The checker reconstructs the expression and insists on this complementary split. It never branches on a raw averaged probability as though it were a Boolean graph edge. Actual graph tests exhibit many fractional averages and guard this distinction.

A rejected root contains a complete binary proof tree whose every leaf has an exact certificate (6.1) in its path constraints. The search was bounded to depth six and 127 nodes per root. If either child remains unclosed, the whole root remains OPEN. Partial trees, depth limits and node limits are not rejections.

## 7. A general threshold-activation bound

There is also a short order-independent inequality explaining a subset of the exclusions. Let Z subset B have z sources, each forced to select a common block I of p>=1 labels. Put W=B minus Z and assume rho_w<=c on W, with C=c+ell>0.

Every selected triple with source in Z and label in I must end in W: a supplement must miss its label, but every Z vertex is forced to carry it. Write H_k=#{u in Z:q_u>=k}. The p H_k mandatory triples from these high-degree sources all have supplements with

    q_w >= k-1-rho_w >= k-1-c.

Each supplement receives at most C selected triples in total. Therefore, for every integer j>=1,

    #{w in W:q_w>=j} >= ceil(p H_{j+c+1}/C).  (7.1)

Let D_Z be any proved lower bound on sum_{u in Z}q_u, and h_k any proved lower bounds on H_k. Summing the degree layers gives the new bound

    Q >= D_Z + sum_{j>=1} ceil(p h_{j+c+1}/C). (7.2)

There is no repeated charging of the same outgoing selection. A vertex of outgoing degree q contributes once to each of q distinct degree layers, exactly reconstructing q. The bounds at different layers need not be simultaneously attained; they are individually necessary for any actual system, so their sum is valid.

The implementation obtains D_Z by summing, over labels, the maximum of the known forced count in Z and the demand not serviceable outside Z. For k>p it lower-bounds H_k using the total load and safe source caps. At k=p+1, the required number of Z sources carrying any additional non-block label is another lower bound. The separate checker enumerates high-source subsets to check the cap argument rather than repeating the discovery greedy algorithm.

### 7.1 A v5 survivor excluded by 65 > 57

Take the v5 row with original index 2 (position 0 here):

    s   = (0,0,0,1,1,3,4,4,4,4,4,4),
    rho = (1 repeated 11, 4 repeated 4).

Here r=27 and Q<=r+2b=57. Six demand-four labels are forced at all four rho=4 sources, accounting for 24 mandatory outgoing selections. The demand-three label needs at least three of those sources, since every other residual degree is one. Consequently their outgoing load is at least 27, and at least three have q>=7.

Every one of the 24 mandatory block triples ends among the eleven rho=1 vertices, each with incoming cap three. At least eight such vertices therefore have outgoing degree at least four. The 18 block triples from the three sources with q>=7 additionally require at least six vertices with outgoing degree at least five. Thus

    sum_{w outside Z}q_w >= 4*8+6=38,
    Q >= 27+38=65>57.

The earlier single-level calculation sees only 24+4*8=56<=57 and misses this contradiction. The new argument rejects every column refinement of the row. It is not the different 78>57 example in v5. Fourteen threshold certificates are preserved; all overlap base-model rejections and are NOT counted again.

### 7.2 An infinite above-target profile family

For every integer p>=18 define

    A_p = 4p+(p-2)ceil(4p/3),
    L = ceil((A_p-3p-24)/3),
    a=p+L+1, b=a+3, n=2a+4,
    m=(a+2)^2+1=floor(n^2/4)+1, t=2,
    rho=(1 repeated (p+L), 4 repeated 4),
    s=(0, 1 repeated (L-1), 3, 4 repeated p).

The residual total is r=p+L+16 and Q<=U=3p+3L+24. The old scalar forced-block lower bound is A_p, and the chosen ceiling gives A_p<=U<=A_p+2. Thus that particular old bound does not reject the pattern. We do not assert that it passes every previous project test.

All p demand-four labels are forced at the four high sources. The demand-three label needs at least three of those sources, increasing their load to at least 4p+3. Formula (7.2), with c=1 and C=3, gives

    Q >= 4p+3+(p-2)ceil(4p/3)+p
      = A_p+p+3 > U.

This symbolically excludes every member, including every compatible individual-column refinement. The first is n=294, Delta=148, m=21610, with the contradiction 477>456. These are families of excluded numerical profiles, not whole-order theorems.

The patterns are not merely inconsistent degree sums. Put K=L-2p+34. Assign the zero-demand label (d,R)=(0,3p-18); among the L-1 demand-one labels give K the option (2,1) and the remaining 2p-35 the option (1,0); give the extra label (3,0), and the p high-demand labels (4,0). Then sumR=r, sumd=2(r+2), and the demands are exact. The inequality L>=(4p^2-5p-72)/9>=3p-34 for p>=18 implies p<=K<=L-1.

An explicit F realization uses an outer cycle on the p degree-four labels, the K degree-two labels and the degree-three label, placing at least one degree-two label between successive high labels. Add a cycle on eighteen of the high labels. Attach two degree-one leaves to each remaining high label and one leaf to the degree-three label. The zero-demand label is isolated. No added high-high edge repeats an outer-cycle edge. A separate residual bipartite realization gives the four rho=4 sources sixteen distinct unit-residual labels, puts 3p-18 outside vertices at the zero label, and assigns each remaining outside vertex to one unused unit-residual label. These two constructions verify separate graphicality; they are NOT a simultaneous selected/residual critical graph. The contradiction rules out such a simultaneous realization.

## 8. Completed numerical scope

| Stage | Rows tested | Exact rejections | Rows remaining |
|---|---:|---:|---:|
| Common fractional columns, F and selected triples | 6,918 | 2,301 | 4,617 |
| Discrete source-degree types and typed pair transport | 4,617 | 4,138 | 479 |
| Complete proof trees found within depth-six/node-127 limits | 479 | 91 | 388 |

The 91 proof trees contain 572 checked leaves. All 388 unclosed roots stopped at the depth limit. They are not graph witnesses, integer-feasibility certificates or evidence that deeper branching will succeed. The final rows belong to 167 demand patterns. `check_all.py` verifies all 6,530 rejection dispositions and the exact, disjoint partition with 388 survivors. `FINAL_SURVIVORS.json.gz` stores their original state and demand; no fresh common graph is claimed.

This scope is m=196 only. The new exact column and degree-type conditions can change with t. There is no established monotonicity theorem extending these rejections to 197 edges or higher, and no assumption that edge deletion preserves criticality. No complete order above the earlier candidates is claimed.

## 9. Tests, negative controls and review limits

The independent named-constraint builder agreed with the discovery builder for every exported base and typed rejection. All exact certificates and branch trees passed a separate standard-library checker. Ten deliberate negative controls were rejected: zero weights, unknown constraint identity, wrong right-hand side, missing branch child, an unlicensed raw-average split, a noninteger split threshold, a forged leaf, reuse of a left proof in the right branch, an omitted input disposition and a duplicated input disposition.

The saved actual-graph input consists of 916 selected systems on 639 distinct labelled graphs of orders 5 through 22. Criticality is checked by actual edge deletion, and the minimum-complement-degree root and quasi-edge assignments are reconstructed. Both singleton option domains and broadened option domains are lifted into the models using exact fractions. The base tests check 300,567 constraint evaluations; the typed tests check 588,729 and explicitly encounter 22,547 fractional averaged-variable values. The union lemma has 413 nonempty tests, including 104 in which the union is larger than every individual selected set. The internal-F residual lemma has 107 nonzero tests. All pass.

No actual graph in this input has positive surplus. These tests nonvacuously exercise local lemmas and graph-to-model mappings, but do not establish the dense-case contradiction empirically. They are not a new exhaustive generation of all graphs up to order 22.

Separately, 7,817 accepted abstract arc systems from 12,000 seeded attempts exercise 66,103 degree-layer inequalities, including 7,409 positive-activation cases. They do not impose criticality or the density ledger. The new family's arithmetic was checked at 9,983 integer parameters; 133 explicit separate F/residual constructions were checked, with three complete examples preserved. Universal validity rests on Section 7's proof, not these finite checks.

The published correspondence statements were retrieved and inspected, not re-proved. Independent mathematical review, external researcher reproduction, formal-kernel verification and priority determination remain open. The uniform coefficient `(10-sqrt(2))/14` is unchanged. The next structural target is a common integral assignment and shared selected neighbourhoods for the 388 remaining rows, without treating fractional symmetry averages as graph edges.

## 10. References and attribution

[1] T. W. Haynes, M. A. Henning, L. C. van der Merwe and A. Yeo, *A maximum degree theorem for diameter-2-critical graphs*, Central European Journal of Mathematics 12(12) (2014), 1882–1889, DOI 10.2478/s11533-014-0449-3. Theorems 3.1–3.2 and Observation 3.4. Primary full text: https://d-nb.info/1372516379/34 .

[2] Project n=27 candidate, `project/reviews/n27/2026-09-07-candidate-v1/PROOF.md`, preserved in paullenz/MurtySimon25. Inherited residual ledger, activity and selected-edge arguments.

[3] Project general-order coupled-resource and pair-budgets v2 checkpoints, `project/research/general_n/2026-09-07-coupled-resource-v2/` and `2026-09-07-pair-budgets-v2/`. Inherited selected/supplement inequalities and pair-degree counting.

[4] Project v5 original ZIP and readable proof in `project/research/general_n/2026-09-07-column-propagation-v5/`, pinned above. Input necessary-condition domains, caps, forced selections and earlier scalar activation bound. No historical claim is silently promoted by this continuation.

[5] SciPy official `linprog(method='highs')` documentation: https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html . Numerical coefficient discovery only; environment versions are in `ENVIRONMENT.json`. The certificate checker does not import SciPy.

Paul Lenz directed the research. ChatGPT/Geeps developed both derivations and implementations. “New” denotes an advance within this workstream, not a verified novelty or priority claim.
