# Murty–Simon: general-order demand–support checkpoint v3

7 September 2026. Prepared by ChatGPT/Geeps for Paul Lenz.

**Candidate mathematics; exact arithmetic REPRODUCED; external review OPEN.**

The universal demand–support cut in `PROOF.md` gives three new candidate degree-case exclusions:

| n | Excluded maximum degree | Excluded edge counts | Remaining degrees after inherited reductions |
|---:|---:|---:|---|
| 28 | 16 | m ≥ 196 | 15 |
| 30 | 17 | m ≥ 225 | 16 |
| 33 | 19 | m ≥ 272 | 18 |

**None of these orders is completely resolved by this checkpoint.** This is not a proof through order 1,000. The previous all-order candidate coefficient (10−√2)/14 is unchanged. The frozen n=25 and n=27 candidates and governed ledger are unchanged.

## Read first

`PROOF.md` contains the full mathematical derivation, exact finite domains, monotonic higher-edge-count argument, test limits and citations. `REVIEW_AND_RECONCILIATION.md` records what was recovered from previous work and what was not independently re-audited. `PROVENANCE.json` pins the source checkpoint and distinguishes local artifact preservation from a GitHub commit.

## Verify the saved package

Use Python 3.10 or later. From this directory:

```sh
python3 -I -B verify_manifest.py
python3 -I -B check.py
python3 -I -B test_hand_endgame.py
```

The manifest checks exact file bytes. The arithmetic checker needs only the Python standard library. It imports neither `discover.py` nor SciPy. It directly checks complete demand coverage, residual-list domain sizes, source-cap refinement, exact dual inequalities and deliberate negative controls. The hand-endgame test checks the numerical identities in Section 8 of the proof.

The saved `CHECK_REPORT.json` records 1,824 complete charging-demand profiles and 14,149 residual-row profiles in the final stage, with zero survivors. All four deliberate damaged-evidence controls are rejected. The mathematical lemmas are not formally verified by these programs.

## Optional regeneration and falsification tests

Run tests in an extracted working copy: the graph and abstract-test scripts rewrite their own reports and evidence. Do not use Python's `-O` option, which disables their assertions.

```sh
python3 -I -B test_graphs.py
python3 -I -B test_abstract_support.py
```

Actual-graph tests check all labelled graphs of orders 3–6, and seeded constructions at orders 7–22. They contain **no positive-surplus instance and no nonempty high-demand support case**. The separate abstract test exercises 15,737 nonempty support thresholds, but its incidence systems are not claimed to be critical graphs. Neither finite test establishes a universal lemma.

To rediscover the arithmetic certificates, SciPy is required; the saved discovery used SciPy 1.17.0:

```sh
python3 -I -B discover.py --output /absolute/path/to/new-evidence
python3 -I -B check.py --evidence /absolute/path/to/new-evidence
```

A different numerical solver version may choose different dual weights. The acceptance criterion is exact verification, not equality of solver messages or byte-for-byte identity of newly discovered certificates. Solver status alone is never a proof. The verifier raises an error for any surviving row, invalid certificate, or incomplete numerical domain.

## Files and preservation

- `evidence/n*_delta*.json.gz`: complete numerical input domains and rejection certificates.
- `discover.py`, `check.py`: separate discovery and arithmetic-check implementations, both written by the same assistant.
- `test_graphs.py`, `test_abstract_support.py`, `test_hand_endgame.py`: finite regression/falsification tests with saved reports and inputs.
- `exploration/`: preserved development code and outputs, including incomplete n=28/Δ15 and n=29/Δ16 work. These are historical scratch files, not the portable replay entry point. Some retain session-local import/output paths. Their surviving patterns are not graphs or proofs of existence.
- `ENVIRONMENT.json`, `PROVENANCE.json`, `MANIFEST.json`: environment, source references and byte-integrity record.

All mathematical derivations, main executable code, final evidence, exploratory results and limitations are preserved in this package. Source documents read remotely are referenced by commit/path/blob; their original bytes are not falsely represented as bundled here.

**GitHub status:** this package has not been committed or uploaded to the repository in this session. The available connected GitHub actions were read/search actions; discovery did not expose a write action. Suggested new repository destination:

```text
project/research/general_n/2026-09-07-demand-support-v3/
```

Do not overwrite the frozen v1/v2 directories or earlier reviewer releases. Packaging alone does not promote the theorem ledger. No independent researcher has endorsed this checkpoint.
