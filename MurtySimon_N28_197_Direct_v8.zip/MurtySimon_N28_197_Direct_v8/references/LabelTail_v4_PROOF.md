# General-order label-tail charging: candidate continuation v4

7 September 2026. Paul Lenz directed this work; ChatGPT/Geeps developed the derivations and implementations. **Candidate mathematics; independent mathematical review OPEN.** No complete new order, improved global maximum-degree coefficient, novelty, or formal verification is claimed.

## 1. Baseline and scope

The repository baseline is `85e04173d5a2b29641bad1a71867cdf7fa15cfd6` of `paullenz/MurtySimon25`. This continuation combines the inherited residual/selected construction and demand charging with the individual-label pair-degree observation in `2026-09-07-pair-budgets-v2/README.md`, Sections 2–3. The overlapping demand-support-v3 and demand-stability-v3 degree exclusions are not counted twice. The original v3 archive was recovered from its actual bytes, SHA-256 `4d5e06a85f2e9112776205a632436a8e9224bc9f14055ceabf5a67dd83d89fd1`.

The principal new-to-this-checkpoint step is to bound the **total outgoing selected incidence at high-pair-degree sources**, using the same global label-excess budget. It yields a short hand contradiction for the retained `(n,Delta,m)=(64,33,1025)` profile and a symbolic infinite family of profile exclusions. Profiles are necessary-condition data, not actual graphs. Excluding a family does not exclude all graphs of its orders.

## 2. Inherited setup, made explicit

Let G be a simple diameter-two edge-critical graph. Stars and complete bipartite graphs are handled separately. For the remaining complement H, use the published 3-total-domination-edge-critical correspondence [1] as an input. Choose v of minimum H-degree a, set A=N_H(v), B=V(H)\N_H[v], and b=|B|=Delta(G), so n=a+b+1. Let F be the complement of H[A] on A and d_i=d_F(i).

For each missing unordered B-pair {u,w}, choose exactly one existing cross quasi-edge ui whose endpoints totally dominate H except for the unique vertex w (or the reverse orientation). Orient that missing pair u->w and label it i. Distinct unordered pairs choose distinct cross-edges. At a fixed source, labels and supplements are distinct. Every other existing A–B edge is residual.

Write rho_u and R_i for residual degrees, r=sum rho=sum R, q_u and p_u for outgoing and incoming selected-pair degrees, and sigma_u=q_u+p_u. Write x_i for the actual number of selected incidences with label i. Then

    Q=sum q=sum p=sum x,   e(F)=r+t,
    t=m-b(n-b),           sum d=2(r+t).

Minimum H-degree gives R_i+x_i>=d_i. Put

    s_i=max(0,d_i-R_i),     Q0=sum s_i,
    e_i=x_i-s_i>=0,         E=sum e_i=Q-Q0,
    D_i^0=R_i+s_i=max(R_i,d_i),
    D_i=R_i+x_i=D_i^0+e_i.

All actual selected incidences are retained, including extra incidences at zero-demand labels. In particular, x_i is not assumed to equal s_i.

The inherited local bounds for selected ui->w are

    d_i<=rho_u+R_i,
    d_i<=rho_u+rho_w,
    d_i<=rho_u+q_u-1,
    q_u+rho_u<=a,
    p_u<=rho_u+b-a-1.                                      (2.1)

The incoming bound follows from d_H(u)=b-1+rho_u-p_u>=a. For the selected quasi-edge, each F-neighbour of i must be adjacent to u. Charging its cross-edge at u, or the forced cross-edge at the selected supplement, yields the first two residual inequalities; distinct source supplements make these charges injective. These inherited injections remain mathematical review dependencies.

Crucially, for every selected incidence ui,

    D_i>=sigma_u.                                          (2.2)

Indeed, if ui->w, every vertex of N_P(u) other than w must be adjacent to i in H, where P is the simple graph of selected unordered B-pairs. In addition u is adjacent to i. These are sigma_u distinct B-neighbours of i. Thus (2.2) uses both incoming and outgoing pairs, not just q_u.

## 3. New global label-tail inequality

For an integer k define

    T_k=sum_{u:sigma_u>=k} q_u,
    c_i(k)=max(0,k-D_i^0),
    W_k(E)=max { sum_{i in I}s_i : I subset A,
                                  sum_{i in I}c_i(k)<=E }.

Then

    T_k <= E+W_k(E).                                       (3.1)

Proof: let I_k={i:D_i>=k}. Every outgoing incidence from a source counted by T_k has its label in I_k by (2.2). Hence T_k<=sum_{i in I_k}x_i. For every i in I_k, e_i>=c_i(k), so I_k is an admissible knapsack set: sum_{i in I_k}c_i(k)<=E. Finally,

    sum_{i in I_k}x_i = sum_{i in I_k}s_i + sum_{i in I_k}e_i
                      <=W_k(E)+E.

This does not charge E separately and then add independent per-source budgets. It bounds the common set of labels used by the entire tail. The bound may be applied at several thresholds and the resulting valid inequalities added with nonnegative weights. Each use still explicitly pays its own E term on the right.

The knapsack bound keeps individual D_i^0 and s_i. A weaker closed form is useful: if D_i^0<=D and s_i<=H0 for all labels and k>D, each label in I_k costs at least k-D units of excess. Therefore

    T_k <= E + H0*floor(E/(k-D))
        <= E*(1+H0/(k-D)).                                (3.2)

Neither inequality requires positive t or residual activity once the stated selected-system premises hold.

## 4. New source-floor charging inequality

Suppose all selected-pair endpoints lie in a set Z of z vertices. Suppose p_u<=P0 there, and each outgoing degree is either zero or at least L, where L is a positive integer. For any integer 1<=j<=L,

    (L+j)Q <= L*P0*z + sum_{k=L+P0-j+1}^{L+P0} T_k.        (4.1)

Proof: the following holds pointwise for integer q,p with p<=P0 and q=0 or q>=L:

    j*q+L*p <= L*P0 + q*#{k:L+P0-j+1<=k<=L+P0, q+p>=k}.

For q=0 it is immediate. Put d=L+P0-q-p. If d<=0 all j tail terms appear and the claim is Lp<=LP0. If d>=j, no tail term appears and p<=L+P0-j-q gives

    j*q+L*p-L*P0 <= (j-L)(q-L)<=0.

If 0<d<j, exactly j-d terms appear; the difference of the two sides reduces to (d-L)(q-L)<=0. Summing uses sum_Z q=sum_Z p=Q, proving (4.1).

Combining (3.2) and (4.1), when the smallest tail threshold exceeds D, gives

    (L+j)Q0 - L*P0*z
       <= E*( H0*sum_{k=L+P0-j+1}^{L+P0}1/(k-D) - L ).    (4.2)

Consequently a strictly positive left side and a nonpositive bracket exclude the entire profile **for every E>=0**, not only its minimum-selection case.

## 5. Hand exclusion of the retained n=64 stress-test profile

The inherited retained profile [2, Section 7] is

    n=64, a=30, b=33, t=2, m=1025,
    d=(15 repeated 4,16 repeated 26),
    R=(7 repeated 4,8 repeated 26),
    rho=(1 repeated 4,8 repeated 29).

Here r=236, every s_i=8, Q0=240, and D_i^0<=16.

No rho=1 vertex can be a source, because d_i<=rho_u+R_i would require 8<=1. It cannot be a supplement either: min d=15>8+1. Therefore every selected-pair endpoint belongs to the 29 rho=8 vertices. Their incoming degree is at most 8+(33-30-1)=10.

Every nonzero outgoing degree is at least 9. Degrees q<=7 have no eligible label under d_i<=8+q-1. At q=8 only the four degree-15 labels are eligible, which is fewer than the eight distinct labels required. Thus q=8 is also impossible.

Apply (4.1) with L=9,P0=10,z=29,j=2:

    11Q <= 2610+T_18+T_19.

Apply (3.2) with H0=8,D=16:

    T_18<=5E,       T_19<=11E/3.

Since Q=240+E, this would require

    2640+11E <= 2610+26E/3,
    30+7E/3 <= 0.                                         (5.1)

But E>=0. This is a contradiction. It excludes this whole residual profile with arbitrary extra selected incidences. It is not a proof at order 64. No numerical solver, enumeration of E, Fan bound, or edge-deletion argument is needed for (5.1).

## 6. An infinite family excluded symbolically

Let h and a be any integers satisfying

    h>=7,       2h+1<=a<=h^2-h-12.

Define

    n=2a+4, b=a+3, t=h-6,
    m=floor(n^2/4)+h-7,
    rho=(1 repeated 4,h repeated a-1),
    R=(h-1 repeated h-4,h repeated a-h+4),
    d=(2h-1 repeated 4,2h repeated a-4).

The R and d entries are paired in the displayed order. All multiplicities are nonnegative. The numerical ledger is

    r=h(a-1)+4,
    sum d=2ha-4=2(r+t),
    d_i>=R_i,
    Q0=sum(d_i-R_i)=ha+h-8,
    D_i^0<=2h,
    s_i<=h+1.

For h=7 one demand is h-1 and the rest are h; for h=8 all demands are h; for h>=9, h-8 demands are h+1 and the rest are h. In all cases every demand is greater than one.

The four rho=1 vertices are neither sources nor supplements, using the same local inequalities as above and 2h-1>h+1. Thus z=a-1. On the remaining vertices P0=h+2. Every positive source has q>=h+1: q<h cannot select any label, and q=h can select only the four lower-degree labels, fewer than h.

Use L=h+1, j=2, D=2h, H0=h+1. The two thresholds are 2h+2 and 2h+3. Formula (4.2) becomes

    2(h^2-h-11-a) <= -(h+1)E/6,

or

    2(h^2-h-11-a)+(h+1)E/6 <=0.                            (6.1)

The first term is at least 2 by the upper bound on a, and E>=0. Contradiction.

There are infinitely many parameter pairs (h,a), but these are infinitely many **excluded necessary-condition profiles**, not infinitely many completely solved orders. No claim is made that every such profile passes all older cuts or is otherwise graph-realizable. The retained n=64 profile is the member h=8,a=30; its sharper s_i<=8 bound gives (5.1).

## 7. General exact separator implementation

For a fixed numerical profile and trial total Q, E=Q-Q0. For each residual-degree class enumerate integer source types (q,p), with

    0<=q<=min(a-rho,b-1),
    0<=p<=min(rho+b-a-1,b-1),
    q+p<=b-1.

Zero source/supplement support is derived safely from the local inequalities. A selected source with degree q may use only labels satisfying s_i<=rho and d_i<=rho+q-1. It needs q distinct such labels. By (2.2), the sum of the q smallest activation costs max(0,q+p-D_i^0) among those eligible labels must be <=E. Types violating these necessary conditions are removed. This is a relaxation; simultaneous label assignment and adjacency are not inferred from surviving types.

The separator enforces one type per vertex, global sum q=sum p=Q, and all tail bounds (3.1). Optional floating-point linear programming proposes a weighted inequality. Certificates use exact integer weights: free coefficients alpha for residual classes and beta,gamma for the two degree totals, and nonnegative lambda_k for tail upper bounds. For every permitted type in class c, verify

    alpha_c+beta*q+gamma*p+sum_k lambda_k*q*1(q+p>=k)>=0.

Then any graph would require

    sum_c alpha_c*class_size_c+(beta+gamma)Q
       +sum_k lambda_k*(E+W_k(E))>=0.

A strict negative integer result is a rejection certificate. The checker reconstructs the type domains and knapsack bounds. Solver failure or a bare infeasible status is not a proof.

This implements individual-label **capacity compatibility**. It does not implement a complete shared-adjacency branch-and-bound model. That stronger model remains a next-stage task.

## 8. Order-28 numerical continuation and exact scope

The fixed target in this continuation is n=28,b=15,m=196,a=12,t=1. The v3 demand frontier contained 1,976 sorted demand patterns. The row expansion enumerates all positive sorted length-15 residual lists in their recorded residual-sum intervals. It applies the inherited source/supplement cap refinement and a low-k consequence, not the new label-tail separator (the latter needs individual d and R columns).

For this target L0=choose(12,2)-t=65. The inherited k=0 inequality would require b<=L0-choose(11,2)=10, contrary to b=15. Thus delta(H[A])>=1, so e(H[A])>=6 and r<=59. Equivalently all F-degrees are at most 10.

The complete specified row expansion checks 17,669,896 rows: 617,145 fail r<=59, 16,978,478 fail initial source capacities, 49,862 fail refined capacities, and 24,411 survive. These rows are numerical necessary-condition objects, not graphs. The initial demand-domain exclusions and the row replay have separate evidence.

Two additional projected tests do not need full (d,R) columns:

**Zero-demand slack.** Since s_i=(d_i-R_i)_+,

    sum s_i-r-2t = sum_{i:s_i=0}(R_i-d_i).

In particular, with no zero demand the left side must be zero. This rejects 10,796 of the 24,411 rows.

**Projected degree/pair thresholds.** At threshold j, let H be the unknown number of labels of F-degree at least j. Since all F-degrees are <=10 and their sum is 2r+2, retain only H with

    10H+(12-H)(j-1)>=2r+2,    jH<=2r+2.

Labels with s_i>=j must be among those H. A lower bound on selected incidences on the H labels is the sum of those forced demands plus the H-|forced| smallest optional demands. A second lower bound is

    max(jH,2r+2-(12-H)(j-1))-sum_u min(rho_u,H).

Each selected incidence on such labels uses a distinct unordered B-pair with residual-degree sum >=j. For each retained H compare the maximum of the two lower bounds with that pair count. If every H fails, the row is excluded. These projected cuts reject a further 419 rows.

The final retained list has **13,196 rows in 1,119 demand patterns**. It is preserved explicitly. This does not complete Delta=15 or n=28. No scan at m=197 or all higher m is claimed in this new continuation; higher-count coverage must be established before promoting an order-28 result.

## 9. Review limits and next obligation

The n64 hand proof and the family proof are algebraic conditional consequences of the stated graph-derived premises. Exact arithmetic and small-system tests are falsification/replay evidence, not independent mathematical approval. No complete adjacency-realizability search or formal-kernel proof is provided. Small actual critical graphs generally do not exercise positive-surplus dense profiles; tests must not be represented as empirical proof of their impossibility.

The next order-28 step is to lift the 13,196 rows to consistent individual (d_i,R_i), apply the new exact label-tail cuts together with the inherited pair/forced-label constraints, and retain shared adjacency where capacity information still loses essential correlations. Every undecided row remains OPEN.

## References

[1] Haynes, Henning, van der Merwe and Yeo, *A maximum degree theorem for diameter-2-critical graphs*, Central European Journal of Mathematics 12 (2014), 1882–1889, DOI 10.2478/s11533-014-0449-3. Complement and quasi-edge correspondence: published input, not re-proved in this checkpoint. https://dc.etsu.edu/etsu-works/15862/

[2] Project `project/research/general_n/2026-09-07-pair-budgets-v2/README.md`, pinned at commit `85e04173d5a2b29641bad1a71867cdf7fa15cfd6`, blob `ec269b6e8f6cdf9420611fe8c090bfa6b62f16fc`. Source of (2.2), incoming capacities, and the retained n64 profile.

[3] Project `project/research/general_n/2026-09-07-demand-support-v3/PROOF.md`, same pinned commit, blob `c4ab3493e0e03c58a3eabdf3f0de663fac89588a`. Source of demand charging and source-capacity refinement.

[4] Dailly, Foucaud and Hansberg, *Strengthening the Murty–Simon conjecture on diameter 2 critical graphs*, Discrete Mathematics 342 (2019), 3142–3159. https://arxiv.org/abs/1812.08420 . Inherited low-degree frontier dependency, not an input to the n64 profile contradiction.
