# Direct exclusion of the 197-edge case at order 28 — v8

7 September 2026. Directed by Paul Lenz; mathematical development, code and internal checking by ChatGPT/Geeps.

**Candidate mathematics; complete direct finite arithmetic reproduced by a separately implemented checker; independent mathematical review OPEN.** No novelty, independent endorsement, formal-kernel verification, improved uniform degree coefficient, or theorem-ledger promotion is claimed.

## 1. Result and exact scope

The new finite route excludes every numerical necessary-condition state for

\[
(n,\Delta,m)=(28,15,197),\qquad (a,b,t)=(12,15,2).
\]

The complete input is generated at **t=2**. It is not the old t=1 survivor list. The calculation needs no density-reduction theorem, preservation of criticality after edge deletion, or monotonicity assertion about the exact-column tests. No branch-and-bound tree is required: each final rejection is an exact linear contradiction.

Section 8 excludes every other possible maximum degree at 197 edges. Fan's published strict estimate, as reported by Wang [1], then rules out 198 or more edges. Together these yield the candidate upper bound **m<=196 for diameter-two edge-critical graphs of order 28**. The candidate equality characterization **G=K(14,14)** additionally uses the inherited complete 196-edge route, including LocalIncidence v7 and its upstream coverage. This package supplies a self-contained replay of the *new 197-edge arithmetic*, not a new full replay of every equality-level ancestor.

A separate repository workstream named **degree-load-v7** already proposes another full order-28 route, using a weak-core reduction and different final models. It is preserved unchanged. Its 173/215 split of the same equality frontier is not the LocalIncidence-v7 22/19/347 split. V8's direct density scope is useful corroboration, but shared lemmas, ancestors and authorship mean that these are not independent researcher proofs.

## 2. Structural reduction and residual identities

Let G be a simple diameter-two edge-critical graph. Put H=the complement of G. Choose v of minimum H-degree and set A=N_H(v), B=V(H) minus N_H[v], a=|A|, b=|B|=Delta(G). Write C=H[A], F=the complement of C on A, and d_i=d_F(i).

Here is a direct justification of the quasi-edge fact used throughout the route. A graph has diameter greater than two exactly when its complement has an adjacent pair that totally dominates all vertices: the endpoints are nonadjacent in the original graph and have no common neighbour. This includes disconnected pairs. Thus H has no such pair, while adding any missing H-edge creates one. If the endpoints u,w of that missing edge still fail to dominate a third vertex, the new total-dominating pair cannot be {u,w}; it must use an existing edge incident with one of them, say ui, and its only undominated vertex in H is w. Write ui -> w. The exception is unique and both uw and iw are absent.

Every missing unordered B-pair fails to dominate v. Its quasi-edge auxiliary lies in A to dominate v. Choose exactly one such cross edge for each missing B-pair, oriented from its B-source to its B-exception or supplement. Different pairs cannot choose the same cross edge because that edge's source and unique exception identify its pair. Selected labels and supplements at one source are distinct. All other existing A–B edges are **residual**.

Let rho_u and R_i be residual row and column degrees, q_u and p_u outgoing and incoming selected-pair degrees, and x_i the actual selected degree of label i. Put

\[
r=\sum_u\rho_u=\sum_iR_i,\quad Q=\sum q_u=\sum p_u=\sum x_i,\quad t=m-b(n-b),\quad \ell=b-a-1.
\]

Counting the selected cross edges and existing H[B]-edges as exactly binom(b,2) gives

\[
e(F)=r+t,\qquad e(C)+r=\binom a2-t,\qquad \sum_i d_i=2(r+t).
\]

Since v has minimum H-degree, d_H(i)=a-d_i+R_i+x_i>=a, and d_H(u)=b-1+rho_u-p_u>=a. Consequently

\[
x_i\ge s_i:=\max(0,d_i-R_i),\quad p_u\le\rho_u+\ell,\quad q_u+\rho_u\le a,\quad q_u+p_u\le b-1.
\]

For a selected ui -> w, the inherited charging arguments give

\[
d_i\le\rho_u+R_i,\qquad d_i\le\rho_u+\rho_w,\qquad d_i\le\rho_u+q_u-1,\qquad \rho_w+q_w\ge q_u-1.\tag{2.1}
\]

For clarity, each F-neighbour j of i must neighbour u. At most rho_u of these uj are residual. Every other uj is selected with a distinct supplement z. The selected ui must dominate z through iz; iz is residual since i and z both miss j. This proves the first inequality. For the second, selected uj must dominate w through jw; jw is residual because j and w both miss i. The remaining inequalities follow by counting, respectively, F-neighbours among u's A-neighbours and other selected labels that must neighbour w.

The actual neighbourhood of a selected label also satisfies

\[
\boxed{R_i+x_i\ge q_u+p_u.}\tag{2.2}
\]

Indeed i must neighbour u and every missing-B-pair neighbour of u except w. There are q_u+p_u such distinct B-neighbours of i. These arguments do not require diameter(H)=2.

## 3. Activity, the degree bound, and the fresh demand domain

### 3.1 Positive surplus forces every residual row to be active

Suppose rho_u=0. Put S=N_H(u) intersect A and T=A minus S. Every edge ui, i in S, is selected, so no F-edge joins S and T. For each F-edge ij inside S, the supplements w_i,w_j are distinct. The edges jw_i and iw_j are forced residual edges. Their A-endpoints and distinct supplement labels make all 2e_F(S) charges distinct.

For each F-edge pq inside T, the missing H-pair pq misses u. Its quasi-edge auxiliary cannot be v or u, and cannot lie in S: all S–T pairs are C-edges, which would dominate the alleged exception. It therefore lies in B and gives a residual cross edge with A-endpoint in T and exception in A. Distinct missing pairs give distinct such edges. These charges are disjoint from the S-endpoint charges. Thus r>=2e_F(S)+e_F(T)>=e(F)=r+t, contradicting t>0. Hence rho_u>=1 for all u and r>=b.

### 3.2 At (a,b,t)=(12,15,2), every F-degree is at most 10

If x is isolated in C, put X=A minus {x}. Every F-edge inside X misses x in H and has a quasi-edge with auxiliary in B. It gives a residual cross edge with A-endpoint in X. At each B-vertex z used by one of these edges, xz is also forced and residual; otherwise the selected edge xz would miss the A-exception of the original quasi-edge. These x-endpoint charges are disjoint from the first family. Each unused B-vertex supplies another residual edge by activity. Consequently e(C)+r>=binom(11,2)+15=70, whereas its ledger value is binom(12,2)-2=64. Contradiction.

Therefore delta(C)>=1, d_i<=10, and e(C)>=6 implies r<=58. The actual retained demand intervals below have maximum r=56, so no unsupported compiled-array bound is used.

### 3.3 Charging generates the entire t=2 demand domain

Let S=sum s_i. Then S>=r+2t. No positive demand s_i>=a is possible: its selected sources would require rho_u>=a and positive q_u, contradicting rho_u+q_u<=a. Define g(s)=(s-1)/(a-s) for positive s, and g(0)=0. At a source with rho_u<a, (2.1), monotonicity of g and q_u<=a-rho_u give sum of g(s_i) over its selected labels <=rho_u-1. At rho_u=a there are no selected edges and the inequality still holds. Sum over sources and use at least s_i actual selected incidences at each positive-demand label:

\[
r-b\ge\sum_i\frac{s_i(s_i-1)}{a-s_i}.
\]

Eliminating r gives the necessary condition

\[
\boxed{\sum_i\frac{s_i(a+1-2s_i)}{a-s_i}\ge b+2t.}\tag{3.1}
\]

For a=12,b=15,t=2, the right side is **19**. Enumerate every nondecreasing length-12 list s in {0,...,11} satisfying (3.1). There are exactly **12,012**. The independent checker directly enumerates the unpruned combinations, rather than trusting the discovery recursion. Each recorded tuple is valid and unique; equality with the independent count proves complete domain coverage.

For each tuple, all residual sums lie in

\[
r_{\min}=15+\left\lceil\sum_i\frac{s_i(s_i-1)}{12-s_i}\right\rceil,
\qquad r_{\max}=\min(S-4,64).
\]

The inherited demand-support and weighted source inequalities exclude 9,146 tuples by source counts, 67 by support, and 1,570 by exact integer duals, leaving **1,229**. Their full interval and tuple lists are checked independently. The equations and explicit support/dual necessity proofs are retained in `references/DemandSupport_v3_PROOF.md` and `references/LabelTail_v4_PROOF.md`; no fixed equality-density wrapper is used for t=2. In particular the original generic `verify_record` and `domain_count` are used, not the older `verify_scope`, which is intentionally equality-only.

## 4. Residual rows, projected slack, and joint columns

For each of the 1,229 intervals, enumerate every nondecreasing length-15 rho in {1,...,12} with sum r. The complete domain has **8,216,928** rows. Initial safe source caps are

\[
c_u=\min(12-\rho_u,14,\#\{i:s_i\le\rho_u\}).
\]

Each prefix of the descending demands must fit sum_u min(c_u, number of eligible prefix labels). Distinct supplements and rho_w+q_w>=q_u-1 allow monotone cap refinement. These tests reject 8,194,665 rows initially and 17,109 after refinement; **5,154** remain. The r<=58 cut rejects zero additional rows here. The separate C++ checker generates multisets by multiplicity rather than the discovery recursion, independently counts each length/sum domain by a generating-product DP, reconstructs every classification, and agrees on all survivor bytes, all per-demand counts and the full classification digest. The digest alone is not the coverage proof.

For actual columns introduce z_i=R_i+s_i-d_i>=0. Then

\[
\sum R_i=r,\quad \sum d_i=2r+4,\quad \sum z_i=S-r-4.
\]

Every positive-demand label has z_i=0. The corrected **t=2** slack identity rejects 2,033 rows. The inherited projected F-degree/selected-pair threshold bound rejects another 162, leaving **2,959 rows in 497 demand patterns**. This pass explicitly uses 2r+4 and S-r-4, not their t=1 versions. Its separate checker validates the complete disjoint partition and the pair tables.

V5's generic joint projection is next invoked with t=2 and dmax=10. It retains individual (d,R,z) choices, both exact global column sums, safe source/supplement matchings, forced labels and a source's selected/residual/missing status counts. A missing label j at a source with q selected labels must have d_j<=a-q-1. Each graph supplies a witness to every projection, so iterative pruning only removes impossible options. Different source projections can still be witnessed by different full assignments; this is a relaxation, not a graph constructor.

The new independent replay reconstructs every joint rejection and each survivor's complete domains, outgoing caps and forced-label masks. It excludes **1,375** rows and retains **1,584 rows in 359 demand patterns**. The discovery's breakdown is 7 label-domain, 735 source-matching, 80 source-Hall, 148 total-source, 29 pair-Hall and 376 joint-total-source rejections; the independent route verifies dispositions and all surviving state data rather than trusting those labels.

## 5. Shared adjacency, source degree types, and actual endpoint degrees

All models are explicitly built at t=2. Their source files are unchanged mathematical model implementations imported from the preserved v6/v7 packages; only the new fixed-scope drivers and the necessary t-dependent finite adapters are new. The dependency manifest records those origins and hashes.

An actual graph is averaged over permutations inside identical label classes (same demand, full column domain and forced mask) and identical source classes (same rho, cap and forced-label pattern). Model coordinates are averages of indicators, and legitimately lie in [0,1]. This does not assume the graph has those automorphisms or that the averaged coordinates are integers.

**Shared model.** The column marginals, one shared F-adjacency matrix, selected/residual cross-edge marginals and oriented missing-B-pair marginals obey the exact degree ledgers, pair uniqueness and forced-neighbourhood inequalities. This excludes **787** of the 1,584 rows.

**Source-degree-type model.** Record each actual integer q as a source type. Selected/residual/missing events and source-to-supplement pairs must consistently use those types, including rho_w+q_w>=q_u-1. The type probabilities themselves are still fractional. This excludes another **790** rows.

**Actual endpoint-type model.** For each column option record actual x_i, and for each source record actual (q_u,p_u). Selected-incidence events must use both endpoint types and satisfy R_i+x_i>=q_u+p_u. Global totals and source-local costs are conditioned on each q-type. This excludes the final **7** rows. No integrality branching, unclosed search tree or feasibility inference is needed.

The conditional source-local inequality used in this last model does require full criticality. To make that dependency explicit, fix u and partition A into selected S, residual T, and missing M, with |T|=rho_u and |S|=q_u. No F-edge joins S and M. Distinct supplements force 2e_F(S) residual edges with A-endpoints in S. Missing H-pairs in M miss u; their quasi-edge auxiliaries lie in T or B, and at most e_C(T,M) can use T. The others give distinct residual cross edges with A-endpoints in M. Together with u's rho_u residual edges ending in T, these are disjoint charges. Hence

\[
r\ge\rho_u+2e_F(S)+e_F(M)-e_C(T,M).
\]

Substituting e(F)=r+t and elementary pair bounds gives

\[
\sum_{i\in S}d_i\le\rho_u(2a-\rho_u-3+q_u)-2t,
\quad \sum_{i\in S}R_i\le r-\rho_u.\tag{5.1}
\]

Conditioning the actual fixed sums on the event q_u=q gives sum of column R =r times the type probability, and sum of column d =2(r+t) times that probability. These are valid for an actual graph and do not become invalid when averaged. `references/LocalIncidence_v7_PROOF.md` supplies the complete event derivation and all multiplicities; `references/SharedAdjacency_v6_PROOF.md` supplies the shared and degree-type models. The direct t=2 route applies them to the *original critical graph*, not to a weakened core. Thus it does not assume this extra local lemma survives a density reduction.

## 6. Exact certificates and independent coverage

For each final row, write its reconstructed constraints as A y<=b and E y=f with y>=0. The certificate stores nonnegative integer multipliers lambda on inequalities and signed integer multipliers mu on equalities. The checker proves

\[
\lambda A+\mu E\ge0\quad\text{coefficientwise},\qquad \lambda b+\mu f<0.
\]

An actual nonnegative y would then have a nonnegative left side bounded by a strictly negative right side, impossible. All coefficients, multipliers, accumulated coefficients and final right sides are checked as exact integers. Each constraint is canonically identified by its named-variable coefficient vector and right side. Unknown, duplicated or invalidly signed multipliers are rejected.

Optimisation proposes multipliers only. A floating-point solver's status is never a counted rejection. During discovery, every accepted certificate was checked against separately reconstructed named constraints, and the complete variable and constraint sets were compared. The production has **1,584 exact certificates**, split 787/790/7. Their negative right sides range from -1 to -1000. A pilot using the endpoint model on 20 rows is preserved as overlapping exploration, not 20 extra exclusions.

`src/check197.py` independently regenerates the 12,012-tuple domain, all 8,216,928 residual classifications, the projected partition, every joint projection and every retained domain, then reconstructs all final inequalities. All stage handoffs are exact and exhaustive. It rejects omitted and duplicated demand/LP records, a wrong scope, forged LP row/RHS, unknown constraints, negative inequality multipliers, duplicate multipliers and an empty alleged contradiction. The projected checker adds two controls of its own. No discovery model or optimisation library is imported by this checking route.

## 7. Completed counts

| Stage | Input | Rejected at this stage | Retained |
|---|---:|---:|---:|
| Fresh charging demand tuples | 12,012 | 10,783 | 1,229 |
| Complete residual expansion of retained demand intervals | 8,216,928 | 8,211,774 | 5,154 |
| Exact t=2 slack and projected pair tests | 5,154 | 2,195 | 2,959 |
| Joint columns and one-source constraints | 2,959 | 1,375 | 1,584 |
| Shared adjacency LP | 1,584 | 787 | 797 |
| Source-degree-type LP | 797 | 790 | 7 |
| Actual endpoint-type LP | 7 | 7 | **0** |

Demand tuples and residual rows are different units; their counts must not be added as graph counts. Every final certificate corresponds to a fresh t=2 input, not a reused t=1 disposition.

## 8. All maximum degrees at 197 edges and order-28 assembly

**Delta<=14:** degree sum gives m<=28*14/2=196, so cannot occur at 197.

**Delta=15:** excluded by the complete direct calculation above.

**Delta=16:** now a=11 and t=197-16*12=5. The charging inequality (3.1) requires a sum of 11 scores to be at least 26. Checking the 11 possible integer demands 0<=s<=10 shows

\[
\frac{s(12-2s)}{11-s}\le\frac{16}{7}.
\]

Equivalently, the score deficit is 2(s-4)(7s-22)/[7(11-s)], nonnegative for every integer 0<=s<=10. Consequently

\[
\boxed{26\le\frac{176}{7}<26,}
\]

a contradiction. This is a short direct arithmetic corollary of the existing general charging bound; no t=1 exclusion certificate is used for this degree case.

**17<=Delta<=26:** let h be the residual h-index, the largest integer h with at least h rows of degree >=h. Every s_i<=h because it needs s_i distinct selected sources with rho>=s_i. Therefore r+2t<=ah. Activity gives r>=b+h(h-1). Combining gives

\[
b+2t\le(a+1)h-h^2\le\left\lfloor\frac{(n-b)^2}{4}\right\rfloor.
\]

For m=197,n=28, every b=17,...,26 violates this inequality. At b=17 it already demands 37<=30. The complete exact ten-case table is in `evidence/ALL_DEGREES_AND_FAN.json`.

**Delta=27:** a universal vertex in a diameter-two-critical graph forces a star, since an edge among its other vertices would be redundant. A star has only 27 edges. Complete bipartite graphs also have at most196 edges by their part-size product.

Thus no maximum degree is possible at197. Fan's strict bound [1], for n>=25, is

\[
m<\frac{n^2}{4}+\frac{n^2-(81/5)n+56}{320}.
\]

At n=28 it is **78883/400 =197.2075**, so integrality gives m<=197. The direct exclusion gives the candidate upper bound m<=196. Fan's original proof has not been re-audited here; the cited primary author manuscript reports the theorem and is an explicit external input to the *full upper-bound assembly*, not to the fixed-197 calculation itself.

For the equality characterization, m=196 and Delta<=14 forces every degree to be14 (or contradicts the degree sum). Each nonadjacent pair then has at least two common neighbours: their two 14-element neighbour sets lie in the remaining26 vertices. A triangle edge could not be critical, since its endpoint pair still has a two-edge path, every nonadjacent pair retains at least one of its two common neighbours, and other adjacent pairs retain their edges. Hence the graph is triangle-free. Choose a vertex v: its 14 neighbours form an independent set and each has all14 vertices outside that set as neighbours. This is K(14,14). For Delta=15, use LocalIncidence v7 and its upstream 196-edge coverage; for Delta=16, the preserved demand-support v3 equality exclusion; Delta>=17 is excluded by the same h-index bound at196, with stars and complete bipartite cases separately handled. These equality-level inputs are unchanged, not rediscovered by the t=2 enumeration.

## 9. Review, provenance and limits

The original SharedAdjacency-v6 and LocalIncidence-v7 archives were verified in full against their manifests:88 and87 payloads respectively. Their complete separate checking routes were rerun in fresh copies in this session. V6 again leaves388 and LocalIncidence-v7 again excludes388. Their fresh review reports are stored under `reviews/`. V3/v4/v5 original archives also pass their payload hashes. The original v3 n28/Delta16 equality scope was additionally replayed:39 demand profiles and604 residual rows, all rejected. This session does not assert a fresh full replay of every old equality-level stage. The new197 checker does regenerate its own entire domain and handoffs.

Both implementations remain work by the same assistant. Old actual-graph lift tests were rerun with the original archives and include fractional symmetry averages, but contain no positive-surplus actual graph. No test nonvacuously samples a positive-surplus critical graph at197. Universal necessity is a mathematical obligation, not a consequence of the arithmetic checks.

A first launch of the new check driver failed to import a module under isolated Python. The explicit source search path was corrected before the successful complete check; no certificate or mathematical model was altered to obtain the result. The failed launch log is retained. Generic copied modules may retain historical t=1 command-line examples; use the v8 `replay.py` and fixed-scope drivers, which explicitly invoke t=2. Discovery-library versions may yield different new duals or timings; verification never substitutes them for the stored historical evidence.

The repository intake found a distinct readable degree-load-v7 candidate and no accessible V6/LocalIncidence-V7 ZIP objects. The README was reconciled and the exact failed archive-attachment response preserved separately. This v8 package does not claim that the old binary uploads were located or moved. File availability, branch attachment, mathematical validity, arithmetic reproduction and independent expert review remain separate questions.

## References

[1] Tao Wang, *On Murty-Simon Conjecture*, arXiv:1205.4397 (2012), page2, reporting Fan's strict bound. https://arxiv.org/pdf/1205.4397 . PDF text checked on7 September2026; the web screenshot renderer failed with a cache-miss error. No unsupported claim of visual or original-Fan-proof review is made.

[2] Project demand-support v3 and label-tail v4 proof notes; unchanged readable copies under `references/`. Their residual/quasi-edge framework traces to the frozen n27 project candidate and the published complement approach.

[3] Project ColumnPropagation v5, SharedAdjacency v6 and LocalIncidence v7 proofs; unchanged copies under `references/`, with byte-level source origins in `PROVENANCE.json`.

[4] Separate degree-load-v7 scope audit, repository baseline239eee18aa05a21e2265b8fcd34bd6553a38ef6a, `project/research/general_n/2026-09-07-degree-load-v7/CORE_SCOPE_AUDIT.md`. This alternative density-scope argument is **not** a dependency of the new direct197 exclusion.
